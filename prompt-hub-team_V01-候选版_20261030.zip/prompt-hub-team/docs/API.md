# 接口与交换契约

全部团队接口同源，使用数据库会话。先GET `/api/session/` 取得CSRF及operation_epoch，POST/PATCH/DELETE带 `X-CSRFToken`。成功与失败包含 `X-Request-ID`，API响应不缓存。正文、备注、密码及密钥不写入运行日志。

| 路径 | 方法与行为 |
| --- | --- |
| `/api/session/` | GET 当前成员、CSRF、运行epoch |
| `/api/login/`、`/api/logout/` | POST 登录、退出 |
| `/api/password/` | POST 修改口令并撤销旧会话 |
| `/api/entries/` | GET 服务端筛选分页；POST 分享条目 |
| `/api/entries/{id}/` | GET 详情；PATCH 修改内容；DELETE 移入回收站 |
| `/api/entries/{id}/note/` | PATCH 全员共同备注 |
| `/api/entries/{id}/history/`、`restore/` | GET 历史；POST 恢复指定域 |
| `/api/entries/{id}/undelete/` | POST 管理员恢复删除 |
| `/api/entries/{id}/favorite/` | POST 显式设置favorite布尔值 |
| `/api/entries/{id}/github/` | POST 仓库元数据刷新，不改人工介绍 |
| `/api/members/`、`/api/members/{id}/` | GET/POST 成员管理；PATCH 停用、角色或临时口令 |
| `/api/recycle/` | GET 管理员回收站 |
| `/api/exchange/preview/`、`commit/` | POST TXT验证预览、确认导入 |
| `/api/exchange/export/` | GET 生成TXT附件 |
| `/api/operations/{operation_id}/` | GET 当前成员私有写入回执 |

变更带 `operation_id` 和 `operation_epoch`。相同成员及ID、相同载荷重试得到原结果。不同载荷返回409。结果与业务在同一事务提交。回执24小时可查；到期拒绝旧ID，不重新执行。恢复数据库后更换epoch，旧意图不能自动换epoch重放。

内容PATCH带整数body_version；备注PATCH带整数note_version。先比较版本，再判断内容是否相同。普通无变化保存不增版本；历史恢复即使文字相同也生成新版本。删除同时检查两域版本。401需重新认证，403表示权限不足，409需重新读取并人工合并，422表示输入无效，503表示资源或数据库暂不可用。网络中断、非JSON响应或500不能先显示成功，应先查回执和条目。

列表要求 `kind=PROMPT|SKILL`。可附 `name`、逗号分隔 `tag_ids`、`owner_id`、`updated_from`、`updated_to`、`favorite=1`、`page` 和 `page_size`。组间AND，多个标签OR。日期按北京时间解释，止日包含当天。排序为更新时间、ID倒序。名称及标签按NFKC/casefold检索。

导出 `scope=filtered|kind|selected|all`。selected需明确ids，kind表示当前大类全部。整类导出不接受附带筛选；过滤导出复用查询但不截取浏览器当前页。`format=full|legacy|legacy_notes`。后两者仅限提示词。空结果、丢失ID及超限不静默漏项。

完整TXT是UTF-8、无BOM输出的JSON，协议2。单文件20MiB、最多2000条、站内总条目10000。标题120、正文50000、介绍5000、备注10000码点，最多10个标签，各30码点。JSON最大嵌套16层，拒绝重复键、NaN、Infinity、坏UTF-8及布尔值冒充整数。外层HTTP JSON可能再次转义TXT，所以请求上限42MiB，文件上限仍是20MiB。

预览凭据绑定原文件摘要、用户、认证版本、模式、运行epoch和操作ID，10分钟有效。文件、账号或实际标签归并映射变化后必须重新预览。导入只新建副本，本站分享人是实际导入账号。origin是来源声明，不授予身份。GitHub快照不进入可信仓库缓存。完整示例见 `examples/full-v2.txt`。

旧版可读TXT每条使用独立标题行 `1、名称：`，正文另起行，最后追加 `{备注：原备注}`，条目间空一行。空备注保留 `{备注：}`。不裁剪原正文和备注。旧版导入时备注成为正文，不能恢复为独立字段。旧格式最多1MiB、200条，未归属前言和超长标题明确拒绝。编号边界有歧义，需人工预览；完整格式用于保留独立字段。

GitHub只访问固定公开API，不跟随重定向，不下载代码，不执行Skills。仓库缓存24小时；全站每小时30次、每成员5次。Star为仓库指标，0与未知分开。源版本变化后丢弃旧绑定。连接/读取超时和分块预算控制请求；这不是可对恶意慢响应证明的绝对墙钟截止，目标环境仍须验证进程超时与故障出口。
