// Real Chromium + real Django/SQLite. No routes, mocks, spies, or patched business code.
const assert = require('node:assert/strict');
const { spawn, spawnSync } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');
const { createRequire } = require('node:module');
const requireRuntime = createRequire(path.join(process.env.PH_NODE_PACKAGES, 'package.json'));
const { chromium } = requireRuntime('playwright');
const root = path.resolve(__dirname, '..');
const runtime = path.resolve(process.env.PH_BROWSER_DATA);
assert(runtime && !runtime.startsWith(path.join(root, 'server', 'data')));
fs.mkdirSync(runtime, { recursive: true });
const env = { ...process.env, PH_DATA_DIR: runtime, PH_LOCAL_HTTP: '1', PH_PRODUCTION: '0' };
const python = process.env.PH_TEST_PYTHON;
assert(python && process.env.PH_BROWSER_PORT);
const base = `http://127.0.0.1:${process.env.PH_BROWSER_PORT}`;
const initial = 'Browser-Tracer-2026!';
function pythonRun(args) {
  const result = spawnSync(python, args, { cwd: path.join(root, 'server'), env, encoding: 'utf8' });
  assert.equal(result.status, 0, result.stdout + result.stderr);
}
async function main() {
  // Refuse to share an existing service. Each run owns its isolated port and directory.
  const net = require('node:net');
  await new Promise((resolve, reject) => { const probe = net.createServer(); probe.once('error', reject); probe.listen(Number(process.env.PH_BROWSER_PORT), '127.0.0.1', () => probe.close(resolve)); });
  pythonRun(['manage.py', 'migrate', '--noinput']);
  pythonRun(['manage.py', 'shell', '-c', `from hub.models import Member; [(Member.objects.create_user(username=n,password='${initial}',display_name=n,must_change_password=(n=='first'),is_superuser=(n=='alice'))) for n in ['first','alice','bob']]`]);
  const log = fs.openSync(path.join(runtime, 'server.log'), 'a');
  const child = spawn(python, ['manage.py', 'runserver', `127.0.0.1:${process.env.PH_BROWSER_PORT}`, '--noreload'], { cwd: path.join(root, 'server'), env, stdio: ['ignore', log, log] });
  let browser;
  const contexts = [];
  const results = [];
  try {
    for (let i = 0; i < 100; i++) { try { if ((await fetch(base + '/healthz/')).ok) break; } catch {} await new Promise(r => setTimeout(r, 100)); }
    browser = await chromium.launch({ executablePath: process.env.PH_CHROME, headless: true });
    async function logged(name = 'alice') {
      const context = await browser.newContext(); contexts.push(context);
      const page = await context.newPage(); page.setDefaultTimeout(5000);
      await page.goto(base + '/team/');
      await page.getByLabel('用户名', { exact: true }).fill(name);
      await page.getByLabel('密码', { exact: true }).fill(initial);
      await page.getByRole('button', { name: '登录', exact: true }).click();
      await page.getByRole('button', { name: '+ 分享提示词', exact: true }).waitFor();
      return { context, page };
    }
    async function api(context, method, endpoint, body) {
      const session = await (await context.request.get(base + '/api/session/')).json();
      const response = await context.request.fetch(base + '/api/' + endpoint, { method, headers: { 'X-CSRFToken': session.csrf_token }, data: { ...body, operation_id: body.operation_id || crypto.randomUUID(), operation_epoch: session.operation_epoch } });
      assert(response.ok(), `${method} ${endpoint}: ${response.status()} ${await response.text()}`);
      return response.json();
    }
    async function create(context, kind, title) {
      return (await api(context, 'POST', 'entries/', { kind, title, content: kind === 'PROMPT' ? '正文【目标】' : '', intro: kind === 'SKILL' ? 'Skill介绍' : '', tags: ['测试标签'] })).entry;
    }
    async function test(name, fn) {
      if (process.env.PH_BROWSER_CASE && !name.includes(process.env.PH_BROWSER_CASE)) return;
      if (process.env.PH_BROWSER_EXCLUDE && name.includes(process.env.PH_BROWSER_EXCLUDE)) return;
      try {
        // Independent cases share only this harness's disposable database.
        // Reset real login buckets between cases, not inside the behavior under test.
        pythonRun(['manage.py','shell','-c',"from hub.models import RateBucket; RateBucket.objects.filter(key__startswith='login-').delete()"]);
        await fn(); results.push({ name, status: 'passed' }); console.log('PASS', name);
      }
      catch (e) {
        results.push({ name, status: 'failed', error: e.message }); console.log('FAIL', name, e.message);
        for (const context of contexts) { if (context.pages().length) { const page = context.pages()[0]; await page.screenshot({ path: path.join(runtime, name + '-failure.png') }).catch(() => {}); } }
      }
    }
    await test('v11-import-preview-dialog-mobile-and-commit', async () => {
      const {context,page}=await logged();
      await page.setViewportSize({width:390,height:844});
      await page.getByRole('button',{name:'导入 TXT',exact:true}).click();
      await page.getByLabel('导入格式').selectOption('legacy');
      const input=page.getByLabel('文件内容 · 也可直接粘贴');
      const bad='1、'+'x'.repeat(121)+'：\n正文';
      await input.fill(bad);
      await page.getByRole('button',{name:'解析并预览',exact:true}).click();
      const dialog=page.getByRole('alertdialog',{name:'导入预览未完成'});
      await dialog.waitFor();
      assert.match(await dialog.innerText(),/第1行/);
      assert.match(await dialog.innerText(),/120/);
      // A modal makes the underlying form inert; inspect the real DOM value.
      assert.equal(await page.locator('textarea').inputValue(),bad);
      assert.equal(await page.getByRole('button',{name:'查询上次操作结果',exact:true}).count(),0);
      assert(await dialog.getByRole('button',{name:'知道了'}).evaluate(e=>e===document.activeElement));
      await page.keyboard.press('Escape');
      await dialog.waitFor({state:'hidden'});
      const good='1、V11真实浏览器导入：\n保留正文\n\n2、V11第二条：\n第二正文';
      await input.fill(good);
      await page.getByRole('button',{name:'解析并预览',exact:true}).click();
      await page.getByRole('heading',{name:'将新建 2 条',exact:true}).waitFor();
      await page.getByLabel('我已核对完整内容、共同备注和标签，确认只创建新副本').check();
      await page.getByRole('button',{name:'确认导入',exact:true}).click();
      await page.getByText('已新建 2 条，原内容未覆盖',{exact:true}).waitFor();
      const rows=await (await context.request.get(base+'/api/entries/?kind=PROMPT&name=V11真实浏览器导入')).json();
      assert.equal(rows.entries[0].content,'保留正文');
      await page.screenshot({path:path.join(runtime,'v11-mobile-success.png')});
      await context.close();
    });
    await test('v11-preview-retry-clears-stale-confirmation', async () => {
      const {context,page}=await logged();
      await page.getByRole('button',{name:'导入 TXT',exact:true}).click();
      await page.getByLabel('导入格式').selectOption('legacy');
      const input=page.getByLabel('文件内容 · 也可直接粘贴');
      await input.fill('1、V11不能重用旧预览：\n正文');
      await page.getByRole('button',{name:'解析并预览',exact:true}).click();
      await page.getByRole('heading',{name:'将新建 1 条',exact:true}).waitFor();
      await page.getByLabel('我已核对完整内容、共同备注和标签，确认只创建新副本').check();
      // Real DB capacity change makes an unchanged second preview fail; no interception.
      pythonRun(['manage.py','shell','-c',"from hub.models import Entry,Member; u=Member.objects.get(username='alice'); Entry.objects.bulk_create([Entry(kind='PROMPT',title='capacity-v11',content='body',owner=u) for _ in range(10001)])"]);
      try {
        await page.getByRole('button',{name:'解析并预览',exact:true}).click();
        await page.getByRole('alert').filter({hasText:/超过10000/}).waitFor();
        assert.equal(await page.getByRole('button',{name:'确认导入',exact:true}).count(),0,'Failed preview must invalidate old confirmation');
      } finally {
        pythonRun(['manage.py','shell','-c',"from hub.models import Entry; Entry.objects.filter(title='capacity-v11').delete()"]);
      }
      await context.close();
    });
    await test('v11-expired-preview-login-clears-old-dialog',async()=>{
      const {context,page}=await logged();
      await page.getByRole('button',{name:'导入 TXT',exact:true}).click();
      await page.getByLabel('导入格式').selectOption('legacy');
      await page.getByLabel('文件内容 · 也可直接粘贴').fill('1、重新登录后保留输入：\n正文');
      pythonRun(['manage.py','shell','-c',"from hub.models import Member; from django.db.models import F; Member.objects.filter(username='alice').update(auth_version=F('auth_version')+1)"]);
      await page.getByRole('button',{name:'解析并预览',exact:true}).click();
      await page.getByRole('alertdialog',{name:'导入预览未完成'}).getByRole('button',{name:'知道了'}).click();
      await page.getByRole('button',{name:'登录',exact:true}).waitFor();
      await page.getByLabel('用户名',{exact:true}).fill('alice');
      await page.getByLabel('密码',{exact:true}).fill(initial);
      const [response]=await Promise.all([page.waitForResponse(r=>r.url().endsWith('/api/login/')),page.getByRole('button',{name:'登录',exact:true}).click()]);
      assert.equal(response.status(),200);
      await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
      assert.equal(await page.getByRole('alertdialog').count(),0,'New login must not reopen old preview failure');
      assert.equal(await page.getByRole('button',{name:'确认导入',exact:true}).count(),0);
      await context.close();
    });
    await test('v11-full-preview-shows-known-entry-index',async()=>{
      const {context,page}=await logged();
      const entry=await create(context,'PROMPT','V11完整格式定位');
      const wire=await context.request.get(base+`/api/exchange/export/?scope=selected&ids=${entry.id}&kind=PROMPT&format=full`);
      assert.equal(wire.status(),200);
      const document=await wire.json(); document.entries[0].title='x'.repeat(121);
      await page.getByRole('button',{name:'导入 TXT',exact:true}).click();
      await page.getByLabel('导入格式').selectOption('full');
      await page.getByLabel('文件内容 · 也可直接粘贴').fill(JSON.stringify(document));
      await page.getByRole('button',{name:'解析并预览',exact:true}).click();
      const dialog=page.getByRole('alertdialog',{name:'导入预览未完成'});
      await dialog.waitFor();assert.match(await dialog.innerText(),/第1条/);
      await dialog.getByRole('button',{name:'知道了'}).click();
      await context.close();
    });
    async function skillForm(page, title) {
      await page.getByRole('button',{name:'Skills',exact:true}).click();
      await page.getByRole('button',{name:'+ 分享Skill',exact:true}).click();
      await page.getByLabel('名称',{exact:true}).fill(title);
      await page.getByLabel('Skill介绍',{exact:true}).fill('原始介绍必须保留');
    }
    await test('save-feedback-invalid-source-popup', async () => {
      const {context,page}=await logged();
      await page.setViewportSize({width:390,height:844});
      await skillForm(page,'失败保留输入');
      await page.getByLabel('GitHub仓库地址 · 可选',{exact:true}).fill('https://github.com.evil.test/owner/repo');
      await page.getByRole('button',{name:'保存内容',exact:true}).click();
      const popup=page.getByRole('alertdialog');await popup.waitFor();
      assert.match(await popup.innerText(),/GitHub/);
      const box=await popup.boundingBox();assert(box && box.x>=0 && box.x+box.width<=390);
      assert(Math.abs(box.x+box.width/2-195)<=2 && Math.abs(box.y+box.height/2-422)<=2,'modal must be centered in the mobile viewport');
      await page.screenshot({path:path.join(runtime,'save-error-mobile.png')});
      await popup.getByRole('button',{name:'知道了',exact:true}).click();
      assert.equal(await page.getByLabel('名称',{exact:true}).inputValue(),'失败保留输入');
      assert.equal(await page.locator('form.team-panel textarea').inputValue(),'原始介绍必须保留');
      assert.equal((await (await context.request.get(base+'/api/entries/?kind=SKILL')).json()).entries.some(x=>x.title==='失败保留输入'),false);
      await page.getByRole('button',{name:'保存内容',exact:true}).click();
      await popup.waitFor();await popup.getByRole('button',{name:'知道了',exact:true}).click();
      await context.close();
    });
    await test('save-feedback-required-field-popup', async () => {
      const {context,page}=await logged();
      await skillForm(page,'');
      await page.getByRole('button',{name:'保存内容',exact:true}).click();
      const popup=page.getByRole('alertdialog');await popup.waitFor();
      assert((await popup.innerText()).length>10);
      await page.keyboard.press('Escape');
      await popup.waitFor({state:'hidden'});
      assert.equal(await page.locator('form.team-panel textarea').inputValue(),'原始介绍必须保留');
      await context.close();
    });
    await test('save-feedback-nested-url-success-and-server-rejection', async () => {
      const {context,page}=await logged();
      await skillForm(page,'分支链接保存');
      await page.getByLabel('GitHub仓库地址 · 可选',{exact:true}).fill('https://github.com/wheresryan22/anatomy/tree/main?tab=readme#intro');
      await page.getByLabel('Skill在仓库中的路径 · 可选',{exact:true}).fill('../invalid');
      await page.getByRole('button',{name:'保存内容',exact:true}).click();
      const popup=page.getByRole('alertdialog');await popup.waitFor();
      assert.match(await popup.innerText(),/Skill路径无效/);
      assert.match(await popup.innerText(),/关联号/);
      await popup.getByRole('button',{name:'知道了',exact:true}).click();
      assert.equal(await page.getByLabel('名称',{exact:true}).inputValue(),'分支链接保存');
      await page.getByLabel('Skill在仓库中的路径 · 可选',{exact:true}).fill('');
      await page.getByRole('button',{name:'保存内容',exact:true}).click();
      await page.getByRole('status').filter({hasText:'内容已保存'}).waitFor();
      const entries=(await (await context.request.get(base+'/api/entries/?kind=SKILL')).json()).entries;
      const saved=entries.filter(x=>x.title==='分支链接保存');assert.equal(saved.length,1);
      assert.equal(saved[0].skill_source.source_url,'https://github.com/wheresryan22/anatomy/tree/main?tab=readme#intro');
      assert.equal(saved[0].intro,'原始介绍必须保留');
      await context.close();
    });
    await test('save-feedback-offline-popup', async () => {
      const {context,page}=await logged();
      await skillForm(page,'断网草稿');
      await context.setOffline(true);
      await page.getByRole('button',{name:'保存内容',exact:true}).click();
      const popup=page.getByRole('alertdialog');await popup.waitFor();
      assert.match(await popup.innerText(),/网络中断/);
      await popup.getByRole('button',{name:'知道了',exact:true}).click();
      assert.equal(await page.getByLabel('名称',{exact:true}).inputValue(),'断网草稿');
      await context.setOffline(false);
      const entries=(await (await context.request.get(base+'/api/entries/?kind=SKILL')).json()).entries;
      assert.equal(entries.some(x=>x.title==='断网草稿'),false);
      await context.close();
    });
    await test('save-feedback-expired-session-popup', async () => {
      const {context,page}=await logged();
      await skillForm(page,'会话过期保存');
      pythonRun(['manage.py','shell','-c',"from django.db.models import F; from hub.models import Member; Member.objects.filter(username='alice').update(auth_version=F('auth_version')+1)"]);
      await page.getByRole('button',{name:'保存内容',exact:true}).click();
      const popup=page.getByRole('alertdialog');await popup.waitFor();
      assert.match(await popup.innerText(),/登录|会话/);
      await popup.getByRole('button',{name:'知道了',exact:true}).click();
      await page.getByRole('button',{name:'登录',exact:true}).waitFor();
      await context.close();
    });
    await test('v5-optional-password-settings', async () => {
      const {context,page}=await logged('first');
      await page.getByRole('button',{name:'暂不修改',exact:true}).click();
      await page.getByRole('button',{name:'个人设置',exact:true}).click();
      await page.getByLabel('无操作超时分钟数',{exact:true}).fill('120');
      await page.getByRole('button',{name:'保存登录设置',exact:true}).click();
      await page.getByText('登录设置已保存').waitFor();
      await page.getByLabel('当前密码',{exact:true}).fill(initial);
      await page.getByLabel('新密码 · 至少8位',{exact:true}).fill('N8v4Q2x9');
      await page.getByLabel('确认新密码',{exact:true}).fill('different');
      await page.getByRole('button',{name:'更新密码',exact:true}).click();
      await page.getByText('两次新密码不一致',{exact:true}).waitFor();
      await context.close();
    });
    await test('v5-tag-recommendation-and-skill-roundtrip', async () => {
      const {context}=await logged();
      const skill=await create(context,'SKILL','V5真实Skill');
      const bob=await logged('bob');
      await bob.page.getByRole('button',{name:'Skills',exact:true}).click();
      await bob.page.getByText('V5真实Skill',{exact:true}).click();
      await bob.page.getByLabel('新增标签',{exact:true}).fill('协作');
      await bob.page.getByRole('button',{name:'添加标签',exact:true}).click();
      await bob.page.getByRole('region',{name:'条目详情'}).getByRole('button',{name:/团队推荐.*0/}).click();
      await bob.page.getByRole('region',{name:'条目详情'}).getByRole('button',{name:/取消推荐.*1/}).waitFor();
      let current=(await (await context.request.get(base+'/api/entries/'+skill.id+'/')).json()).entry;
      assert(current.tags.some(t=>t.name==='协作')); assert.equal(current.recommendation_count,1);
      await bob.page.getByRole('button',{name:'导出 TXT',exact:true}).click();
      assert.equal(await bob.page.getByLabel('导出格式').inputValue(),'skill_simple_v1');
      await bob.page.getByRole('button',{name:'生成导出预览',exact:true}).click();
      const text=await bob.page.getByLabel('文件内容预览').inputValue();
      assert(text.startsWith('Skill TXT v1')); assert(text.includes('团队推荐：1'));
      const downloadPromise=bob.page.waitForEvent('download');
      await bob.page.getByRole('button',{name:'普通下载 TXT',exact:true}).click();
      const download=await downloadPromise; const target=path.join(runtime,'actual-skill.txt');await download.saveAs(target);
      assert.equal(fs.readFileSync(target,'utf8'),text);
      await bob.page.getByRole('button',{name:'返回列表',exact:true}).click();
      await bob.page.getByRole('button',{name:'导入 TXT',exact:true}).click();
      await bob.page.getByLabel('文件内容 · 也可直接粘贴').fill(text);
      await bob.page.getByRole('button',{name:'解析并预览',exact:true}).click();
      await bob.page.getByRole('alert').filter({hasText:'Skill简洁'}).waitFor();
      assert.equal(await bob.page.getByLabel('导入格式').inputValue(),'full');
      await bob.page.getByLabel('导入格式').selectOption('skill_simple_v1');
      await bob.page.getByLabel('文件内容 · 也可直接粘贴').fill(text);
      await bob.page.getByRole('button',{name:'解析并预览',exact:true}).click();
      await bob.page.getByRole('checkbox').check();
      await bob.page.getByRole('button',{name:'确认导入',exact:true}).click();
      await bob.page.getByRole('status').filter({hasText:'已新建'}).waitFor();
      await bob.page.setViewportSize({width:390,height:844});
      assert.equal(await bob.page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);
      await bob.page.screenshot({path:path.join(runtime,'mobile.png')});
      await context.close();await bob.context.close();
    });
    await test('v5-card-vote-retains-note-and-expired-draft', async () => {
      const {context,page}=await logged();
      const e=await create(context,'PROMPT','V5草稿恢复');await page.reload();
      await page.getByText('V5草稿恢复',{exact:true}).click();
      await page.getByRole('button',{name:'编辑备注',exact:true}).click();
      await page.getByLabel('备注内容',{exact:true}).fill('V5未提交草稿');
      const card=page.locator('.team-entry-card').filter({hasText:'V5草稿恢复'});
      await card.getByRole('button',{name:/团队推荐.*0/}).click();
      await card.getByRole('button',{name:/取消推荐.*1/}).waitFor();
      assert.equal(await page.getByLabel('备注内容',{exact:true}).inputValue(),'V5未提交草稿');
      pythonRun(['manage.py','shell','-c',"from hub.models import SessionPolicy; from django.utils import timezone; from datetime import timedelta; SessionPolicy.objects.filter(actor__username='alice').update(last_active_at=timezone.now()-timedelta(hours=2))"]);
      await page.getByRole('button',{name:'刷新标签',exact:true}).click();
      await page.getByRole('button',{name:'登录',exact:true}).waitFor();
      await page.getByLabel('用户名',{exact:true}).fill('alice');
      await page.getByLabel('密码',{exact:true}).fill(initial);
      await page.getByRole('button',{name:'登录',exact:true}).click();
      await page.getByText('V5草稿恢复',{exact:true}).click();
      assert.equal(await page.getByLabel('备注内容',{exact:true}).inputValue(),'V5未提交草稿');
      assert.equal((await (await context.request.get(base+'/api/entries/'+e.id+'/')).json()).entry.shared_note,'');
      await context.close();
    });
    await test('v5-offline-import-reuses-original-intent', async () => {
      const {context,page}=await logged();
      const sample='Skill TXT v1\n导出时间：2026-10-18T23:30:00Z\n=== Skill ===\n名称：离线重试Skill\n介绍：\n| 内容\n=== 结束 ===\n';
      await page.getByRole('button',{name:'导入 TXT',exact:true}).click();
      await page.getByLabel('导入格式').selectOption('skill_simple_v1');
      await page.getByLabel('文件内容 · 也可直接粘贴').fill(sample);
      await page.getByRole('button',{name:'解析并预览',exact:true}).click();
      await page.getByRole('checkbox').check();
      await context.setOffline(true);
      await page.getByRole('button',{name:'确认导入',exact:true}).click();
      await page.getByRole('button',{name:'查询上次操作结果',exact:true}).waitFor();
      assert.equal(await page.getByLabel('文件内容 · 也可直接粘贴').isDisabled(),true,'Unknown import must freeze its original payload');
      await context.setOffline(false);
      await page.getByRole('button',{name:'查询上次操作结果',exact:true}).click();
      await page.getByRole('button',{name:'重试同一导入',exact:true}).click();
      await page.getByRole('status').filter({hasText:'已新建'}).waitFor();
      const rows=await (await context.request.get(base+'/api/entries/?kind=SKILL&name='+encodeURIComponent('离线重试Skill'))).json();
      assert.equal(rows.total,1);
      assert.equal(await page.getByLabel('文件内容 · 也可直接粘贴').inputValue(),'');
      await context.close();
    });
    await test('v5-cross-tab-session-writes-are-serialized', async () => {
      const {context,page}=await logged();const second=await context.newPage();
      await second.goto(base+'/team/');
      for(const p of [page,second])await p.getByRole('button',{name:'个人设置',exact:true}).click();
      await page.getByLabel('无操作超时分钟数').fill('120');await second.getByLabel('无操作超时分钟数').fill('30');
      let inflight=0,maximum=0;
      const relevant=r=>r.url().endsWith('/api/preferences/') && r.method()==='POST';
      context.on('request',r=>{if(relevant(r)){inflight++;maximum=Math.max(maximum,inflight);}});
      context.on('requestfinished',r=>{if(relevant(r))inflight--;});context.on('requestfailed',r=>{if(relevant(r))inflight--;});
      const locker=spawn(python,['-u','-c',"import sqlite3,time,sys;db=sqlite3.connect(sys.argv[1],timeout=10);db.execute('BEGIN IMMEDIATE');print('LOCKED',flush=True);time.sleep(2);db.rollback();db.close()",path.join(runtime,'hub.sqlite3')],{stdio:['ignore','pipe','pipe']});
      try {
        await new Promise((resolve,reject)=>{locker.stdout.once('data',resolve);locker.once('error',reject);});
        await Promise.all([page.getByRole('button',{name:'保存登录设置'}).click(),second.getByRole('button',{name:'保存登录设置'}).click()]);
        await Promise.all([page.getByText('登录设置已保存',{exact:true}).waitFor(),second.getByText('登录设置已保存',{exact:true}).waitFor()]);
        assert.equal(maximum,1,'One shared browser session must not emit overlapping cookie-changing writes');
      }finally{if(locker.exitCode===null)locker.kill();await context.close();}
    });
    await test('v5-export-requires-same-login-context', async () => {
      const {context,page}=await logged();await create(context,'SKILL','V5导出上下文');
      const listed=page.waitForResponse(r=>r.url().includes('/api/entries/') && r.url().includes('kind=SKILL'));
      await page.getByRole('button',{name:'Skills',exact:true}).click();
      await listed; // Settle the real initial read before deliberately changing login.
      await page.getByRole('button',{name:'导出 TXT',exact:true}).click();
      await page.getByRole('button',{name:'生成导出预览',exact:true}).click();
      await page.getByLabel('文件内容预览').waitFor();
      const session=await (await context.request.get(base+'/api/session/')).json();
      const again=await context.request.post(base+'/api/login/',{headers:{'X-CSRFToken':session.csrf_token},data:{username:'alice',password:initial}});assert.equal(again.status(),200);
      let downloads=0;page.on('download',()=>downloads++);
      await page.getByRole('button',{name:'普通下载 TXT',exact:true}).click();
      await page.getByRole('alert').filter({hasText:'重新生成'}).waitFor();
      assert.equal(downloads,0);
      await context.close();
    });
    await test('v5-rejected-tag-retains-input', async () => {
      const {context,page}=await logged();const e=await create(context,'PROMPT','V5标签上限');
      await api(context,'POST','entries/'+e.id+'/tags/',{add:Array.from({length:9},(_,i)=>'limit-'+i)});
      await page.reload();await page.getByText('V5标签上限',{exact:true}).click();
      await page.getByLabel('新增标签',{exact:true}).fill('第十一个');
      await page.getByRole('button',{name:'添加标签',exact:true}).click();
      await page.getByRole('alert').filter({hasText:'最多10个标签'}).waitFor();
      assert.equal(await page.getByLabel('新增标签',{exact:true}).inputValue(),'第十一个');
      await context.close();
    });
    await test('v5-session-account-switch-invalidates-old-page', async () => {
      const {context,page}=await logged();
      const settled=page.waitForResponse(r=>r.url().includes('/api/entries/') && r.url().includes('favorite=1')).catch(()=>null);
      await page.getByLabel('收藏').selectOption('1');assert(await settled,'Initial filtered request must settle before account switching');
      const session=await (await context.request.get(base+'/api/session/')).json();
      const changed=await context.request.post(base+'/api/login/',{headers:{'X-CSRFToken':session.csrf_token},data:{username:'bob',password:initial}});
      assert.equal(changed.status(),200);assert.equal((await changed.json()).user.username,'bob');
      await page.getByLabel('收藏').selectOption('');
      await page.getByRole('button',{name:'登录',exact:true}).waitFor();
      await context.close();
    });
    await test('v5-minimal-skill-empty-intro-can-edit', async () => {
      const {context,page}=await logged();
      const result=await api(context,'POST','entries/',{kind:'SKILL',title:'V5最简Skill',content:'',intro:'',tags:[]});
      await page.getByRole('button',{name:'Skills',exact:true}).click();
      await page.getByText('V5最简Skill',{exact:true}).click();
      await page.getByRole('button',{name:'编辑内容',exact:true}).click();
      await page.getByLabel('名称',{exact:true}).fill('V5最简Skill改名');
      await page.getByRole('button',{name:'保存内容',exact:true}).click();
      await page.getByRole('status').filter({hasText:'内容已保存'}).waitFor();
      const final=(await (await context.request.get(base+'/api/entries/'+result.entry.id+'/')).json()).entry;
      assert.equal(final.intro,'');assert.equal(final.title,'V5最简Skill改名');
      await context.close();
    });
    async function githubSkill(context,title) {
      return (await api(context,'POST','entries/',{kind:'SKILL',title,intro:'人工介绍不可覆盖',content:'',tags:[],skill_source:{provider:'github',owner:'django',repo:'django',skill_path:'',source_url:'https://github.com/django/django/tree/main'}})).entry;
    }
    await test('v6-github-cooldown-popup',async()=>{
      const {context,page}=await logged();const entry=await githubSkill(context,'V6冷却');
      pythonRun(['manage.py','shell','-c',"from django.utils import timezone; from datetime import timedelta; from hub.models import RepositoryCache; RepositoryCache.objects.update_or_create(key='django/django',defaults={'stars':0,'state':'stale','fetched_at':timezone.now()-timedelta(minutes=5),'retry_after':timezone.now()+timedelta(seconds=90)})"]);
      await page.getByRole('button',{name:'Skills',exact:true}).click();
      await page.getByRole('button',{name:entry.title,exact:true}).click();
      await page.waitForTimeout(2100);
      const cooldownResponse=page.waitForResponse(r=>r.url().endsWith(`/api/entries/${entry.id}/github/`));
      await page.getByRole('button',{name:'刷新仓库资料',exact:true}).click();
      const cooldownBody=await(await cooldownResponse).json();
      const popup=page.getByRole('alertdialog');await popup.waitFor();assert.match(await popup.innerText(),/冷却/);assert.match(await popup.innerText(),/关联号/);
      assert.match(await popup.innerText(),/保留.*Star/);
      await popup.getByRole('button',{name:'知道了',exact:true}).click();
      const detail=page.getByRole('region',{name:'条目详情'});assert.match(await detail.innerText(),/仓库 Star：0/);
      assert.equal(await detail.getByRole('button',{name:/后可刷新/}).isDisabled(),true);
      assert(parseInt(await detail.getByRole('button',{name:/后可刷新/}).innerText(),10)<=cooldownBody.retry_after_seconds,'countdown must not include the time spent before the refresh request');
      await context.close();
    });
    await test('v6-github-late-error-does-not-pollute-other-entry',async()=>{
      const {context,page}=await logged();const a=await githubSkill(context,'V6慢A');const b=await githubSkill(context,'V6新B');
      pythonRun(['manage.py','shell','-c',"from django.utils import timezone; from hub.models import RepositoryCache,RateBucket; RepositoryCache.objects.filter(key='django/django').delete(); RateBucket.objects.update_or_create(key='github-global',defaults={'count':30,'window_start':timezone.now()})"]);
      await page.getByRole('button',{name:'Skills',exact:true}).click();await page.getByRole('button',{name:a.title,exact:true}).click();
      const hold=spawn(python,['-c',"import sqlite3,time,os; c=sqlite3.connect(os.path.join(os.environ['PH_DATA_DIR'],'hub.sqlite3')); c.execute('BEGIN IMMEDIATE'); print('LOCKED',flush=True); time.sleep(2); c.rollback()"],{env,stdio:['ignore','pipe','pipe']});
      await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(new Error('database lock not ready')),5000);hold.stdout.once('data',()=>{clearTimeout(timer);resolve();});});
      try {
        const posted=page.waitForRequest(r=>r.url().endsWith(`/api/entries/${a.id}/github/`));
        await page.getByRole('button',{name:'刷新仓库资料',exact:true}).click();await posted;
        await page.getByRole('button',{name:b.title,exact:true}).click();
        await page.getByRole('region',{name:'条目详情'}).getByRole('heading',{name:b.title,exact:true}).waitFor();
        await new Promise(resolve=>hold.once('exit',resolve));
        await page.waitForTimeout(500);
        assert.equal(await page.getByRole('alertdialog').count(),0);
        assert.equal((await page.locator('body').innerText()).includes('仓库查询额度已用完'),false,'late error must not be attached to the newly selected entry');
        assert.equal(await page.getByRole('region',{name:'条目详情'}).getByRole('heading',{name:b.title,exact:true}).count(),1);
      } finally {if(hold.exitCode===null)hold.kill();await context.close();}
    });
    await test('v6-github-expired-session-popup',async()=>{
      const {context,page}=await logged();const entry=await githubSkill(context,'V6过期');
      await page.getByRole('button',{name:'Skills',exact:true}).click();await page.getByRole('button',{name:entry.title,exact:true}).click();
      pythonRun(['manage.py','shell','-c',"from django.db.models import F; from hub.models import Member; Member.objects.filter(username='alice').update(auth_version=F('auth_version')+1)"]);
      await page.getByRole('button',{name:'刷新仓库资料',exact:true}).click();
      const popup=page.getByRole('alertdialog');await popup.waitFor();assert.match(await popup.innerText(),/登录|会话/);
      await popup.getByRole('button',{name:'知道了',exact:true}).click();await page.getByRole('button',{name:'登录',exact:true}).waitFor();await context.close();
    });
    await test('v6-github-offline-is-unconfirmed-not-false-success',async()=>{
      const {context,page}=await logged();const entry=await githubSkill(context,'V6断网');
      pythonRun(['manage.py','shell','-c',"from django.utils import timezone; from hub.models import RepositoryCache; RepositoryCache.objects.update_or_create(key='django/django',defaults={'stars':0,'state':'verified','fetched_at':timezone.now(),'retry_after':None})"]);
      await page.getByRole('button',{name:'Skills',exact:true}).click();await page.getByRole('button',{name:entry.title,exact:true}).click();
      await context.setOffline(true);await page.getByRole('button',{name:'刷新仓库资料',exact:true}).click();
      const popup=page.getByRole('alertdialog');await popup.waitFor();assert.match(await popup.innerText(),/结果未确认/);
      await popup.getByRole('button',{name:'知道了',exact:true}).click();assert.match(await page.getByRole('region',{name:'条目详情'}).innerText(),/仓库 Star：0/);
      await context.setOffline(false);await context.close();
    });
    await test('v8-empty-description-cache-feedback',async()=>{
      const {context,page}=await logged();
      const entry=(await api(context,'POST','entries/',{kind:'SKILL',title:'无介绍缓存',intro:'人工介绍',content:'',tags:[],skill_source:{provider:'github',owner:'django',repo:'django',skill_path:'',source_url:'https://github.com/django/django/tree/main'}})).entry;
      // Real persisted cache input for the cache-hit branch, not a network response replacement.
      pythonRun(['manage.py','shell','-c',"from hub.models import RepositoryCache; from django.utils import timezone; RepositoryCache.objects.update_or_create(key='django/django',defaults={'stars':0,'description':'','state':'verified','fetched_at':timezone.now(),'retry_after':None})"]);
      await page.getByRole('button',{name:'Skills',exact:true}).click();await page.getByRole('button',{name:entry.title,exact:true}).click();
      const response=page.waitForResponse(r=>r.url().endsWith(`/api/entries/${entry.id}/github/`));
      await page.getByRole('button',{name:'刷新仓库资料',exact:true}).click();const wire=await response;const data=await wire.json();assert.equal(wire.status(),200);assert.equal(data.refresh.outcome,'cached');
      await page.getByRole('region',{name:'条目详情'}).getByText(/仓库暂无可追加的介绍/).waitFor();
      assert.equal(await page.getByRole('button',{name:'追加到原介绍后，核对保存',exact:true}).count(),0);
      assert.equal((await (await context.request.get(base+`/api/entries/${entry.id}/`)).json()).entry.intro,'人工介绍');await context.close();
    });
    if(process.env.PH_LIVE_GITHUB==='1')await test('v8-intro-real-github-append-save-repeat-and-full-link',async()=>{
      const {context,page}=await logged();
      pythonRun(['manage.py','shell','-c',"from hub.models import RepositoryCache; RepositoryCache.objects.filter(key='django/django').delete()"]);
      const url='https://github.com/django/django/tree/main/skills/example?tab=readme#usage';
      const original='人工介绍必须保留\n\n使用心得';
      const entry=(await api(context,'POST','entries/',{kind:'SKILL',title:'V8介绍追加',intro:original,content:'',tags:['原标签'],skill_source:{provider:'github',owner:'django',repo:'django',skill_path:'',source_url:url}})).entry;
      await page.getByRole('button',{name:'Skills',exact:true}).click();await page.getByRole('button',{name:entry.title,exact:true}).click();
      const response=page.waitForResponse(r=>r.url().endsWith(`/api/entries/${entry.id}/github/`),{timeout:30000});
      await page.getByRole('button',{name:'刷新仓库资料',exact:true}).click();const wire=await response;const data=await wire.json();assert.equal(wire.status(),200,JSON.stringify(data));
      assert(data.candidate_intro.trim());
      const before=(await (await context.request.get(base+`/api/entries/${entry.id}/`)).json()).entry;assert.equal(before.intro,original);
      await page.getByRole('button',{name:/带入编辑表单后核对保存|追加到原介绍后，核对保存/}).click();
      const expected=original+'\n\n'+data.candidate_intro.replace(/\r\n?/g,'\n').trim();
      assert.equal(await page.locator('form.team-panel textarea').inputValue(),expected);
      assert.equal(await page.getByLabel('GitHub仓库地址 · 可选',{exact:true}).inputValue(),url);
      assert.equal((await (await context.request.get(base+`/api/entries/${entry.id}/`)).json()).entry.intro,original);
      page.once('dialog',dialog=>dialog.dismiss());
      await page.locator('form.team-panel').getByRole('button',{name:'返回列表',exact:true}).click();
      assert.equal(await page.locator('form.team-panel textarea').inputValue(),expected);
      page.once('dialog',dialog=>dialog.accept());
      await page.locator('form.team-panel').getByRole('button',{name:'返回列表',exact:true}).click();
      assert.equal((await (await context.request.get(base+`/api/entries/${entry.id}/`)).json()).entry.intro,original);
      await page.getByRole('button',{name:'追加到原介绍后，核对保存',exact:true}).click();
      assert.equal(await page.locator('form.team-panel textarea').inputValue(),expected);
      await page.getByRole('button',{name:'保存内容',exact:true}).click();await page.getByRole('status').filter({hasText:'内容已保存'}).waitFor();
      const saved=(await (await context.request.get(base+`/api/entries/${entry.id}/`)).json()).entry;assert.equal(saved.intro,expected);assert.equal(saved.skill_source.source_url,url);
      for(const format of ['full','skill_simple_v1']){
        const exported=await context.request.get(base+`/api/exchange/export/?scope=selected&kind=SKILL&ids=${entry.id}&format=${format}`);assert(exported.ok());
        const text=await exported.text();
        const operation_id=crypto.randomUUID();
        const preview=await api(context,'POST','exchange/preview/',{mode:format,text,operation_id});
        assert.equal(preview.entries[0].intro,expected);assert.equal(preview.entries[0].skill_source.source_url,url);
        const result=await api(context,'POST','exchange/commit/',{mode:format,text,operation_id,preview_token:preview.preview_token,confirmed:true});
        const copy=(await (await context.request.get(base+`/api/entries/${result.ids[0]}/`)).json()).entry;
        assert.equal(copy.intro,expected);assert.equal(copy.skill_source.source_url,url);
      }
      const other=(await api(context,'POST','entries/',{kind:'SKILL',title:'同仓库另一Skill',intro:'另一个Skill',content:'',tags:[],skill_source:{...saved.skill_source,source_url:'https://github.com/django/django/blob/main/another.md'}})).entry;
      const cached=await api(context,'POST',`entries/${other.id}/github/`,{});
      assert.equal(cached.refresh.outcome,'cached');assert.equal(cached.entry.github_snapshot.stars,data.entry.github_snapshot.stars);assert.equal(cached.entry.skill_path_verified,false);
      assert.equal(cached.entry.skill_source.source_url,'https://github.com/django/django/blob/main/another.md');
      await page.getByRole('button',{name:'刷新仓库资料',exact:true}).click();
      await page.getByRole('button',{name:/追加到原介绍后，核对保存/}).click();
      const popup=page.getByRole('alertdialog');await popup.waitFor();assert.match(await popup.innerText(),/已包含/);await popup.getByRole('button',{name:'知道了',exact:true}).click();
      assert.equal((await (await context.request.get(base+`/api/entries/${entry.id}/`)).json()).entry.body_version,saved.body_version);
      await page.setViewportSize({width:390,height:844});
      const link=page.getByRole('region',{name:'条目详情'}).locator('a[href="'+url+'"]');assert.equal(await link.getAttribute('href'),url);
      assert(await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth));
      await page.screenshot({path:path.join(runtime,'v8-mobile-full-link-and-appended-intro.png')});
      await context.grantPermissions(['clipboard-read','clipboard-write']);
      await page.getByRole('button',{name:'复制资料',exact:true}).click();
      assert((await page.evaluate(()=>navigator.clipboard.readText())).includes(url));
      const long='😀'.repeat(4998);
      const expanded=(await api(context,'PATCH',`entries/${entry.id}/`,{title:entry.title,intro:long,content:'',body_version:saved.body_version,skill_source:saved.skill_source})).entry;
      const reread=page.waitForResponse(r=>r.url().endsWith(`/api/entries/${entry.id}/`) && r.request().method()==='GET');
      await page.getByRole('button',{name:'刷新标签',exact:true}).click();await reread;
      await page.getByRole('button',{name:'追加到原介绍后，核对保存',exact:true}).click();
      await popup.waitFor();assert.match(await popup.innerText(),/超出5000/);await popup.getByRole('button',{name:'知道了',exact:true}).click();
      assert.equal(await page.locator('form.team-panel').count(),0);
      assert.equal((await (await context.request.get(base+`/api/entries/${entry.id}/`)).json()).entry.intro,long);
      await api(context,'PATCH',`entries/${entry.id}/`,{title:entry.title,intro:original,content:'',body_version:expanded.body_version,skill_source:{...saved.skill_source,source_url:url+'-changed'}});
      const changed=page.waitForResponse(r=>r.url().endsWith(`/api/entries/${entry.id}/`) && r.request().method()==='GET');
      await page.getByRole('button',{name:'刷新标签',exact:true}).click();await changed;
      await page.getByRole('region',{name:'条目详情'}).locator('a[href="'+url+'-changed"]').waitFor();
      assert.equal(await page.getByRole('button',{name:'追加到原介绍后，核对保存',exact:true}).count(),0,'old source candidate must disappear');
      await context.close();
    });
    if(process.env.PH_LIVE_GITHUB==='1')await test('v6-github-real-http-browser-tracer',async()=>{
      const {context,page}=await logged();const entry=await githubSkill(context,'V6真实GitHub');
      pythonRun(['manage.py','shell','-c',"from hub.models import RepositoryCache,RateBucket; RepositoryCache.objects.filter(key='django/django').delete(); RateBucket.objects.filter(key__startswith='github-').delete()"]);
      await page.getByRole('button',{name:'Skills',exact:true}).click();await page.getByRole('button',{name:entry.title,exact:true}).click();
      const response=page.waitForResponse(r=>r.url().endsWith(`/api/entries/${entry.id}/github/`),{timeout:30000});
      await page.getByRole('button',{name:'刷新仓库资料',exact:true}).click();const wire=await response;const data=await wire.json();assert.equal(wire.status(),200,JSON.stringify(data));
      assert(['updated','not_modified'].includes(data.refresh.outcome));assert.equal(typeof data.entry.github_snapshot.stars,'number');
      await page.getByRole('status').filter({hasText:/仓库资料已/}).waitFor();
      const stored=(await (await context.request.get(base+`/api/entries/${entry.id}/`)).json()).entry;
      assert.equal(stored.github_snapshot.stars,data.entry.github_snapshot.stars);assert.equal(stored.intro,'人工介绍不可覆盖');
      assert.match(await page.getByRole('region',{name:'条目详情'}).innerText(),new RegExp('仓库 Star：'+stored.github_snapshot.stars));
      await page.screenshot({path:path.join(runtime,'github-real-success.png')});await context.close();
    });
    await test('v11-preview-real-network-failure',async()=>{
      const {context,page}=await logged();
      await page.getByRole('button',{name:'导入 TXT',exact:true}).click();
      await page.getByLabel('导入格式').selectOption('legacy');
      const text='1、网络中断不代表格式错误：\n保留输入';
      await page.getByLabel('文件内容 · 也可直接粘贴').fill(text);
      child.kill();
      await new Promise(resolve=>{if(child.exitCode!==null)resolve();else child.once('exit',resolve);});
      await page.getByRole('button',{name:'解析并预览',exact:true}).click();
      const dialog=page.getByRole('alertdialog',{name:'导入预览未完成'});
      await dialog.waitFor();assert.match(await dialog.innerText(),/预览未完成/);
      assert.doesNotMatch(await dialog.innerText(),/正则错误/);
      await dialog.getByRole('button',{name:'知道了'}).click();
      assert.equal(await page.getByLabel('文件内容 · 也可直接粘贴').inputValue(),text);
      assert.equal(await page.getByRole('button',{name:'查询上次操作结果',exact:true}).count(),0);
      await context.close();
    });
    fs.writeFileSync(path.join(runtime,'results.json'),JSON.stringify(results,null,2));
    assert(results.every(r=>r.status==='passed'),JSON.stringify(results));
  } finally {
    if(browser)await browser.close(); child.kill(); fs.closeSync(log);
  }
}
main().catch(e=>{console.error(e);process.exitCode=1;});
