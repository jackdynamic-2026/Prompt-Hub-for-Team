import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const txtPath = path.resolve(__dirname, '../../卡兹克常用提示词.txt');
const content = fs.readFileSync(txtPath, 'utf-8');

// Regex to match "1、Title：" or similar headers
const regex = /(\d+)、([^：\n]+)：/g;
let match;
const prompts = [];
let lastIndex = 0;
let lastMatch = null;

while ((match = regex.exec(content)) !== null) {
  if (lastMatch) {
    const body = content.substring(lastIndex, match.index).trim();
    prompts.push({
      id: lastMatch[1],
      title: lastMatch[2].trim(),
      content: body,
      tags: [],
      isFavorite: false,
    });
  }
  lastMatch = match;
  lastIndex = regex.lastIndex;
}

if (lastMatch) {
  const body = content.substring(lastIndex).trim();
  prompts.push({
    id: lastMatch[1],
    title: lastMatch[2].trim(),
    content: body,
    tags: [],
    isFavorite: false,
  });
}

const outputPath = path.resolve(__dirname, '../src/data/defaultPrompts.ts');
fs.mkdirSync(path.dirname(outputPath), { recursive: true });

const outputContent = `export interface Prompt {
  id: string;
  title: string;
  content: string;
  tags: string[];
  isFavorite: boolean;
}

export const defaultPrompts: Prompt[] = ${JSON.stringify(prompts, null, 2)};
`;

fs.writeFileSync(outputPath, outputContent, 'utf-8');
console.log('Successfully generated defaultPrompts.ts with', prompts.length, 'prompts.');
