"""Real local Windows HTTPS chain. No system trust installation, no public listener."""
import hashlib
import json
import os
from pathlib import Path
import secrets
import socket
import subprocess
import sys
import time
import requests

root = Path(__file__).resolve().parents[1]
runtime = Path(os.environ['PH_HTTPS_TEST_DATA']).resolve()
assert not runtime.exists(), 'Use a new isolated directory'
runtime.mkdir(parents=True)
caddy = Path(os.environ['PH_CADDY_EXE']).resolve()
for port in (19142, 19143):
    with socket.socket() as probe:
        probe.bind(('127.0.0.1', port))
env = {**os.environ, 'PH_DATA_DIR': str(runtime/'data'), 'PH_SECRET_KEY': secrets.token_urlsafe(60), 'PH_OPERATION_EPOCH': secrets.token_urlsafe(40), 'PH_ALLOWED_HOSTS': 'localhost,127.0.0.1', 'PH_PRODUCTION': '1', 'PH_LOCAL_HTTP': '0', 'PH_PROXY_MODE': 'waitress', 'PH_PORT': '19142', 'XDG_CONFIG_HOME': str(runtime/'caddy-config'), 'XDG_DATA_HOME':str(runtime/'caddy-home'), 'PYTHONIOENCODING': 'utf-8'}
server_dir = root/'server'


def run(*args):
    result = subprocess.run([sys.executable, 'manage.py', *args], cwd=server_dir, env=env, capture_output=True, text=True, encoding='utf-8')
    assert result.returncode == 0, result.stderr


run('migrate', '--noinput')
run('shell', '-c', "from hub.models import Member;Member.objects.create_user(username='https-test',display_name='HTTPS',password='HTTPS-Strong-2026!')")
config = runtime/'Caddyfile'
config.write_text('''{
    admin off
    auto_https disable_redirects
    skip_install_trust
    storage file_system {
        root "%s"
    }
}
https://localhost:19143 {
    bind 127.0.0.1
    tls internal
    request_body {
        max_size 44MiB
    }
    reverse_proxy 127.0.0.1:19142 {
        header_up X-Forwarded-For {http.request.remote.host}
        header_up X-Forwarded-Proto https
        header_up -X-Real-IP
        header_up -Forwarded
    }
}
''' % (runtime/'certs').as_posix(), encoding='utf-8')
checked = subprocess.run([str(caddy), 'validate', '--config', str(config), '--adapter', 'caddyfile'], capture_output=True)
assert checked.returncode == 0, checked.stderr.decode(errors='replace')
processes = []
files = []
try:
    for command, cwd, logname in (([sys.executable, '-m', 'config.windows_server'], server_dir, 'waitress.log'), ([str(caddy), 'run', '--config', str(config), '--adapter', 'caddyfile'], runtime, 'caddy.log')):
        output = (runtime/logname).open('wb'); files.append(output)
        processes.append(subprocess.Popen(command, cwd=cwd, env=env, stdin=subprocess.DEVNULL, stdout=output, stderr=output))
    ca = runtime/'certs/pki/authorities/local/root.crt'
    client = requests.Session()
    client.verify = str(ca)
    base = 'https://localhost:19143'
    for _ in range(150):
        if any(p.poll() is not None for p in processes):
            raise RuntimeError('Owned service exited; inspect isolated logs')
        try:
            if ca.is_file() and client.get(base+'/healthz/', timeout=1).status_code == 200:
                break
        except requests.RequestException:
            pass
        time.sleep(0.2)
    else:
        raise RuntimeError('HTTPS health check timed out')
    boot = client.get(base+'/api/session/', timeout=10)
    login = client.post(base+'/api/login/', json={'username': 'https-test', 'password': 'HTTPS-Strong-2026!'}, headers={'Origin': base, 'X-CSRFToken': boot.json()['csrf_token']}, timeout=10)
    assert login.status_code == 200, login.text
    assert client.cookies.get_dict().get('sessionid')
    assert next(c for c in client.cookies if c.name == 'sessionid').secure
    assert client.get(base+'/team/', timeout=10).status_code == 200
    boot = client.get(base+'/api/session/', timeout=10)
    activity = client.post(base+'/api/activity/', json={}, headers={'Origin': base, 'X-CSRFToken': boot.json()['csrf_token']}, timeout=10)
    assert activity.status_code == 200, activity.text
    attacker = requests.Session(); attacker.verify = str(ca)
    boot = attacker.get(base+'/api/session/', timeout=10)
    statuses = []
    for i in range(21):
        response = attacker.post(base+'/api/login/', json={'username': f'bad-{i}', 'password': 'incorrect'}, headers={'Origin': base, 'X-CSRFToken': boot.json()['csrf_token'], 'X-Forwarded-For': f'203.0.113.{i+1}', 'X-Real-IP': f'203.0.113.{i+1}'}, timeout=10)
        statuses.append(response.status_code)
    assert statuses[-1] == 429, statuses
    result = {'status': 'passed', 'chain': 'Caddy TLS -> Waitress -> Django -> real SQLite', 'certificate_verified': True, 'secure_cookie': True, 'activity': activity.status_code, 'spoofed_client_ip_still_limited': statuses[-1], 'public_network': 'not tested', 'windows_service': 'not installed', 'system_trust': 'unchanged'}
    (runtime/'result.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps(result))
    client.close(); attacker.close()
finally:
    for process in reversed(processes):
        if process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                process.kill(); process.wait(timeout=5)
    for output in files:
        output.close()
