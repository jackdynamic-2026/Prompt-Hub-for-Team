// Real Chromium + real Django/SQLite. No routes, mocks, spies, or patched business code.
const assert = require('node:assert/strict');
const { spawn, spawnSync } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');
const { createRequire } = require('node:module');
const requireRuntime = createRequire(path.join(process.env.PH_NODE_PACKAGES, 'package.json'));
const { chromium } = requireRuntime('playwright');
const root = path.resolve(__dirname, '..');
const runtime = path.resolve(process.env.PH_BROWSER_DATA);
assert(runtime && !runtime.startsWith(path.join(root, 'server', 'data')));
fs.mkdirSync(runtime, { recursive: true });
const env = { ...process.env, PH_DATA_DIR: runtime, PH_LOCAL_HTTP: '1', PH_PRODUCTION: '0' };
const python = process.env.PH_TEST_PYTHON;
assert(python && process.env.PH_BROWSER_PORT);
const base = `http://127.0.0.1:${process.env.PH_BROWSER_PORT}`;
const initial = 'Browser-Tracer-2026!';
function pythonRun(args) {
  const result = spawnSync(python, args, { cwd: path.join(root, 'server'), env, encoding: 'utf8' });
  assert.equal(result.status, 0, result.stdout + result.stderr);
}
async function main() {
  // Refuse to share an existing service. Each run owns its isolated port and directory.
  const net = require('node:net');
  await new Promise((resolve, reject) => { const probe = net.createServer(); probe.once('error', reject); probe.listen(Number(process.env.PH_BROWSER_PORT), '127.0.0.1', () => probe.close(resolve)); });
  pythonRun(['manage.py', 'migrate', '--noinput']);
  pythonRun(['manage.py', 'shell', '-c', `from hub.models import Member; [(Member.objects.create_user(username=n,password='${initial}',display_name=n,must_change_password=(n=='first'),is_superuser=(n=='alice'))) for n in ['first','alice','bob']]`]);
  const log = fs.openSync(path.join(runtime, 'server.log'), 'a');
  const child = spawn(python, ['manage.py', 'runserver', `127.0.0.1:${process.env.PH_BROWSER_PORT}`, '--noreload'], { cwd: path.join(root, 'server'), env, stdio: ['ignore', log, log] });
  let browser;
  const contexts = [];
  const results = [];
  try {
    for (let i = 0; i < 100; i++) { try { if ((await fetch(base + '/healthz/')).ok) break; } catch {} await new Promise(r => setTimeout(r, 100)); }
    browser = await chromium.launch({ executablePath: process.env.PH_CHROME, headless: true });
    async function logged(name = 'alice') {
      const context = await browser.newContext(); contexts.push(context);
      const page = await context.newPage(); page.setDefaultTimeout(5000);
      await page.goto(base + '/team/');
      await page.getByLabel('用户名', { exact: true }).fill(name);
      await page.getByLabel('密码', { exact: true }).fill(initial);
      await page.getByRole('button', { name: '登录', exact: true }).click();
      if (name === 'first') { await page.getByRole('button', {name:'现在修改密码',exact:true}).click(); await page.getByRole('heading', {name:'修改密码 · 可选'}).waitFor(); }
      else await page.getByRole('button', { name: '+ 分享提示词', exact: true }).waitFor();
      return { context, page };
    }
    async function api(context, method, endpoint, body) {
      const session = await (await context.request.get(base + '/api/session/')).json();
      const response = await context.request.fetch(base + '/api/' + endpoint, { method, headers: { 'X-CSRFToken': session.csrf_token }, data: { ...body, operation_id: crypto.randomUUID(), operation_epoch: session.operation_epoch } });
      assert(response.ok(), `${method} ${endpoint}: ${response.status()} ${await response.text()}`);
      return response.json();
    }
    async function create(context, kind, title) {
      return (await api(context, 'POST', 'entries/', { kind, title, content: kind === 'PROMPT' ? '正文【目标】' : '', intro: kind === 'SKILL' ? 'Skill介绍' : '', tags: ['测试标签'] })).entry;
    }
    async function test(name, fn) {
      if (process.env.PH_BROWSER_CASE && !name.includes(process.env.PH_BROWSER_CASE)) return;
      try { await fn(); results.push({ name, status: 'passed' }); console.log('PASS', name); }
      catch (e) {
        results.push({ name, status: 'failed', error: e.message }); console.log('FAIL', name, e.message);
        for (const context of contexts) { if (context.pages().length) { const page = context.pages()[0]; await page.screenshot({ path: path.join(runtime, name + '-failure.png') }).catch(() => {}); } }
      }
    }
    await test('personal-team-entry', async () => {
      const context = await browser.newContext(); contexts.push(context); const page = await context.newPage();
      await page.goto(base + '/');
      await page.getByRole('link', { name: '进入提示词与技能分享库', exact: true }).click();
      await page.getByRole('heading', { name: '提示词与技能分享库', exact: true }).waitFor();
      assert.equal(new URL(page.url()).pathname, '/team/'); await context.close();
    });
    await test('password-confirm-eight', async () => {
      const { context, page } = await logged('first');
      const confirm = page.getByLabel('确认新密码', { exact: true });
      assert.equal(await confirm.count(), 1, 'First change needs a second new-password input');
      await page.getByLabel('当前密码',{exact:true}).fill(initial);
      await page.getByLabel('新密码 · 至少8位', { exact: true }).fill('N8v4Q2x');
      await confirm.fill('N8v4Q2x');
      await page.getByRole('button', { name: '更新密码', exact: true }).click();
      await page.getByText('新密码至少8位', { exact: true }).waitFor();
      await page.getByLabel('新密码 · 至少8位', { exact: true }).fill('N8v4Q2x9');
      await confirm.fill('different');
      await page.getByRole('button', { name: '更新密码', exact: true }).click();
      await page.getByText('两次新密码不一致', { exact: true }).waitFor({ timeout: 2000 });
      const before = await (await context.request.get(base + '/api/session/')).json();
      assert.equal(before.user.must_change_password,false); assert.equal(before.user.password_change_suggested,true);
      await confirm.fill('N8v4Q2x9');
      await page.getByLabel('当前密码',{exact:true}).fill('wrong-current');
      await page.getByRole('button', { name: '更新密码', exact: true }).click();
      await page.getByRole('alert').filter({ hasText: '原密码错误' }).waitFor();
      assert.equal(await page.getByRole('heading', { name: '修改密码 · 可选' }).count(), 1, 'Wrong current password must keep the change form');
      await page.getByLabel('当前密码',{exact:true}).fill(initial);
      await page.getByRole('button', { name: '更新密码', exact: true }).click();
      await page.getByRole('button', { name: '+ 分享提示词' }).waitFor();
      await context.close();
    });
    await test('login-error-context', async () => {
      const context = await browser.newContext(); contexts.push(context); const page = await context.newPage();
      await page.goto(base + '/team/');
      await page.getByLabel('用户名', { exact: true }).fill('alice');
      await page.getByLabel('密码', { exact: true }).fill('wrong-password');
      await page.getByRole('button', { name: '登录', exact: true }).click();
      await page.getByRole('alert').filter({ hasText: '用户名或密码错误' }).waitFor();
      assert.equal(await page.getByRole('button', { name: '查询上次操作结果' }).count(), 0, 'Login rejection is not an uncertain write');
      await context.close();
    });
    await test('legacy-format-guidance', async () => {
      const { context, page } = await logged();
      await page.getByRole('button', { name: '导入 TXT', exact: true }).click();
      await page.getByLabel('文件内容 · 也可直接粘贴').fill('1、旧版测试：\n需要保留的正文');
      await page.getByRole('button', { name: '解析并预览', exact: true }).click();
      await page.getByRole('alert').waitFor();
      assert.match(await page.getByRole('alert').innerText(), /旧版.*TXT/, 'Wrong selected format needs actionable guidance');
      assert.equal(await page.getByRole('button', { name: '查询上次操作结果' }).count(), 0);
      assert.equal(await page.getByLabel('文件内容 · 也可直接粘贴').inputValue(), '1、旧版测试：\n需要保留的正文');
      await context.close();
    });
    await test('import-success-no-unsaved-dialog', async () => {
      const { context, page } = await logged();
      await page.getByRole('button', { name: '导入 TXT', exact: true }).click();
      await page.getByLabel('导入格式').selectOption('legacy');
      await page.getByLabel('文件内容 · 也可直接粘贴').fill(Array.from({ length: 17 }, (_, i) => `${i + 1}、导入条目${i + 1}：\n真实正文${i + 1}`).join('\n\n'));
      await page.getByRole('button', { name: '解析并预览', exact: true }).click();
      await page.getByLabel('我已核对完整内容、共同备注和标签，确认只创建新副本').check();
      const dialogs = []; page.on('dialog', async d => { dialogs.push(d.message()); await d.dismiss(); });
      await page.getByRole('button', { name: '确认导入', exact: true }).click();
      await page.getByRole('status').filter({ hasText: '已新建 17 条' }).waitFor();
      await page.getByRole('heading', { name: '导入 TXT', exact: true }).waitFor({ state: 'detached', timeout: 3000 });
      assert.equal(await page.getByRole('heading', { name: '导入 TXT', exact: true }).count(), 0, 'Confirmed success should return to list');
      assert.deepEqual(dialogs, [], 'No unsaved dialog after successful import');
      const result = await (await context.request.get(base + '/api/entries/?kind=PROMPT&page_size=100')).json();
      assert.equal(result.entries.filter(e => e.title.startsWith('导入条目')).length, 17);
      await context.close();
    });
    await test('whole-card-selection-and-same-card-draft', async () => {
      const { context, page } = await logged();
      const entry = await create(context, 'PROMPT', '整卡片目标'); await page.reload();
      const card = page.locator('article').filter({ has: page.getByRole('button', { name: '整卡片目标', exact: true }) });
      await card.locator('.team-summary').first().click();
      await page.getByRole('region', { name: '条目详情' }).waitFor({ timeout: 2500 });
      assert.equal(await page.getByRole('region', { name: '条目详情' }).getByRole('heading', { name: entry.title }).count(), 1);
      await page.getByRole('button', { name: '编辑备注', exact: true }).click();
      await page.getByLabel('备注内容', { exact: true }).fill('不能丢的草稿');
      await card.getByRole('button', { name: entry.title, exact: true }).click();
      assert.equal(await page.getByLabel('备注内容', { exact: true }).inputValue(), '不能丢的草稿');
      const reads = fs.readFileSync(path.join(runtime, 'runtime.jsonl'), 'utf8').trim().split('\n').map(JSON.parse).filter(r => r.event === 'entry_view' && r.result === 'completed' && r.target_id === entry.id);
      assert.equal(reads.length, 1, 'Same-card click must not refetch or duplicate title bubbling');
      await context.close();
    });
    await test('note-conflict-refresh-and-review', async () => {
      const { context, page } = await logged();
      const b = await logged('bob');
      const entry = await create(context, 'PROMPT', '共同备注冲突'); await page.reload();
      await page.getByRole('button', { name: entry.title, exact: true }).click();
      await page.getByRole('button', { name: '编辑备注', exact: true }).click();
      await page.getByLabel('备注内容', { exact: true }).fill('A原草稿');
      await api(b.context, 'PATCH', `entries/${entry.id}/note/`, { text: 'B先保存的内容', note_version: 1 });
      await page.getByRole('button', { name: '保存备注', exact: true }).click();
      await page.getByRole('alert').filter({ hasText: /备注已更新|其他成员/ }).first().waitFor();
      assert(await page.getByRole('button', { name: '保存备注', exact: true }).isDisabled(), 'Stale draft cannot be resubmitted');
      await page.getByRole('button', { name: '读取最新备注', exact: true }).click();
      await page.getByRole('button', { name: '基于最新备注继续编辑', exact: true }).click();
      assert.equal(await page.getByLabel('备注内容', { exact: true }).inputValue(), 'B先保存的内容');
      await page.getByLabel('备注内容', { exact: true }).fill('B先保存的内容\nA补充');
      await page.getByLabel('已核对最新备注及本次修改').check();
      await page.getByRole('button', { name: '保存备注', exact: true }).click();
      await page.getByRole('status').filter({ hasText: '共同备注已保存' }).waitFor();
      const final = await (await context.request.get(base + `/api/entries/${entry.id}/`)).json();
      assert.equal(final.entry.shared_note, 'B先保存的内容\nA补充'); assert.equal(final.entry.note_version, 3);
      // A third write after review must cause another conflict, not silently replace it.
      await page.getByRole('button', { name: '编辑备注', exact: true }).click();
      await page.getByLabel('备注内容', { exact: true }).fill('第二轮草稿');
      await api(b.context, 'PATCH', `entries/${entry.id}/note/`, { text: '第三方又修改', note_version: 3 });
      await page.getByRole('button', { name: '保存备注', exact: true }).click();
      await page.getByRole('button', { name: '读取最新备注', exact: true }).waitFor();
      assert(await page.getByRole('button', { name: '保存备注', exact: true }).isDisabled());
      assert.equal(await page.getByLabel('我的未提交草稿').inputValue(), '第二轮草稿');
      await context.close(); await b.context.close();
    });
    await test('skill-card-and-keyboard', async () => {
      const { context, page } = await logged();
      const entry = await create(context, 'SKILL', 'Skill整卡片');
      await page.getByRole('button', { name: 'Skills', exact: true }).click();
      const card = page.locator('article').filter({ has: page.getByRole('button', { name: entry.title, exact: true }) });
      await card.locator('small').click();
      const detail = page.getByRole('region', { name: '条目详情' });
      await detail.getByRole('heading', { name: entry.title }).waitFor();
      await page.getByRole('button', { name: '← 返回列表' }).click();
      await card.getByRole('button', { name: entry.title, exact: true }).focus();
      await page.keyboard.press('Enter');
      await detail.getByRole('heading', { name: entry.title }).waitFor();
      await context.close();
    });
    await test('unsaved-note-switch-cancel-and-text-selection', async () => {
      const { context, page } = await logged();
      const one = await create(context, 'PROMPT', '保留草稿甲');
      const two = await create(context, 'PROMPT', '切换目标乙'); await page.reload();
      const card = page.locator('article').filter({ has: page.getByRole('button', { name: two.title, exact: true }) });
      const box = await card.locator('.team-summary').first().boundingBox();
      await page.mouse.move(box.x + 2, box.y + box.height / 2); await page.mouse.down();
      await page.mouse.move(box.x + 70, box.y + box.height / 2, { steps: 8 }); await page.mouse.up();
      assert((await page.evaluate(() => window.getSelection().toString())).length > 0);
      assert.equal(await page.getByRole('region', { name: '条目详情' }).count(), 0, 'Selecting text must not open a card');
      await page.getByRole('button', { name: one.title, exact: true }).click();
      await page.getByRole('button', { name: '编辑备注', exact: true }).click();
      await page.getByLabel('备注内容', { exact: true }).fill('保留，不放弃');
      const dialog = page.waitForEvent('dialog');
      const click = card.locator('small').click(); const prompt = await dialog;
      assert.match(prompt.message(), /未保存/); await prompt.dismiss(); await click;
      assert.equal(await page.getByLabel('备注内容', { exact: true }).inputValue(), '保留，不放弃');
      assert.equal(await page.getByRole('region', { name: '条目详情' }).getByRole('heading', { name: one.title }).count(), 1);
      await context.close();
    });
    await test('pending-import-leave-protection', async () => {
      const { context, page } = await logged();
      await page.getByRole('button', { name: '导入 TXT', exact: true }).click();
      await page.getByLabel('文件内容 · 也可直接粘贴').fill('1、尚未导入：\n正文');
      const waiting = page.waitForEvent('dialog'); const click = page.getByRole('button', { name: '返回列表', exact: true }).click();
      const prompt = await waiting; assert.match(prompt.message(), /未保存/); await prompt.dismiss(); await click;
      assert.equal(await page.getByLabel('文件内容 · 也可直接粘贴').inputValue(), '1、尚未导入：\n正文');
      await context.close();
    });
    await test('mobile-card-and-password-layout', async () => {
      const { context, page } = await logged();
      const entry = await create(context, 'PROMPT', '手机点击区域'); await page.reload();
      for (const width of [320, 390]) {
        await page.setViewportSize({ width, height: 844 });
        assert(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth), 'No horizontal overflow');
        const card = page.locator('article').filter({ has: page.getByRole('button', { name: entry.title, exact: true }) });
        await card.locator('.team-summary').last().click();
        await page.getByRole('region', { name: '条目详情' }).getByRole('heading', { name: entry.title }).waitFor();
        await page.screenshot({ path: path.join(runtime, `mobile-${width}.png`) });
        await page.getByRole('button', { name: '← 返回列表' }).click();
      }
      await context.close();
    });
    fs.writeFileSync(path.join(runtime, 'browser-results.json'), JSON.stringify(results, null, 2));
    if (results.some(x => x.status === 'failed')) process.exitCode = 1;
  } finally {
    if (browser) await browser.close();
    child.kill();
    await new Promise(resolve => { if (child.exitCode !== null) resolve(); else child.once('exit', resolve); });
    fs.closeSync(log);
  }
}
main().catch(e => { console.error(e); process.exitCode = 1; });
