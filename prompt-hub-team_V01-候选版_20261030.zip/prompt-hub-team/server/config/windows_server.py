"""Windows-compatible WSGI entry. Public traffic must pass through the HTTPS proxy."""
import logging
import os


def build_server(port=None):
    from waitress import create_server
    from config.wsgi import application
    return create_server(application, host='127.0.0.1', port=int(os.environ.get('PH_PORT', '18891')) if port is None else port,
                         threads=4, connection_limit=64, channel_timeout=60, asyncore_loop_timeout=0.5,
                         max_request_body_size=42*1024*1024,
                         trusted_proxy='127.0.0.1', trusted_proxy_count=1,
                         trusted_proxy_headers={'x-forwarded-for', 'x-forwarded-proto'},
                         clear_untrusted_proxy_headers=True)


def close_server(server):
    server.task_dispatcher.shutdown(cancel_pending=False, timeout=30)
    server.asyncore.close_all(server._map)


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    server = build_server()
    try:
        server.run()
    finally:
        close_server(server)
