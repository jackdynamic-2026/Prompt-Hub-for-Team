import os
from django.core.exceptions import ImproperlyConfigured
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = Path(os.environ.get('PH_DATA_DIR', BASE_DIR / 'data'))
DATA_DIR.mkdir(parents=True, exist_ok=True)
DEBUG = os.environ.get('PH_DEBUG') == '1'
SECRET_KEY = os.environ.get('PH_SECRET_KEY', 'local-test-only-not-for-public-deployment')
ALLOWED_HOSTS = os.environ.get('PH_ALLOWED_HOSTS', 'localhost,127.0.0.1,testserver').split(',')
ROOT_URLCONF = 'config.urls'
STATIC_URL = '/static/'
INSTALLED_APPS = ['django.contrib.auth', 'django.contrib.contenttypes', 'django.contrib.sessions', 'hub']
MIDDLEWARE = ['hub.middleware.RequestContextMiddleware', 'django.middleware.security.SecurityMiddleware', 'hub.middleware.SafeSessionMiddleware', 'django.middleware.common.CommonMiddleware', 'django.middleware.csrf.CsrfViewMiddleware', 'django.contrib.auth.middleware.AuthenticationMiddleware', 'django.middleware.clickjacking.XFrameOptionsMiddleware']
CSRF_FAILURE_VIEW = 'hub.middleware.csrf_failure'
TRUSTED_PROXY_IPS = os.environ.get('PH_TRUSTED_PROXY_IPS', '').split(',')
DATABASES = {'default': {'ENGINE': 'django.db.backends.sqlite3', 'NAME': DATA_DIR / 'hub.sqlite3', 'OPTIONS': {'timeout': 5, 'transaction_mode': 'IMMEDIATE'}}}
if os.environ.get('PH_TEST_DB'):
    test_database = Path(os.environ['PH_TEST_DB']).resolve()
    if test_database == Path(DATABASES['default']['NAME']).resolve():
        raise ImproperlyConfigured('test_database_must_be_isolated')
    DATABASES['default']['TEST'] = {'NAME': str(test_database)}
AUTH_USER_MODEL = 'hub.Member'
PASSWORD_HASHERS = ['django.contrib.auth.hashers.Argon2PasswordHasher']
AUTH_PASSWORD_VALIDATORS = [{'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator', 'OPTIONS': {'min_length': 8}}, {'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator'}]
TIME_ZONE = 'Asia/Shanghai'
USE_TZ = True
DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'
SESSION_COOKIE_HTTPONLY = True
SESSION_COOKIE_SAMESITE = 'Lax'
SESSION_COOKIE_SECURE = os.environ.get('PH_LOCAL_HTTP') != '1'
CSRF_COOKIE_SECURE = SESSION_COOKIE_SECURE
SESSION_COOKIE_AGE = 12 * 3600
SESSION_ENGINE = 'hub.sessions'
DATA_UPLOAD_MAX_MEMORY_SIZE = 42 * 1024 * 1024  # Outer JSON can escape a legal 20MiB TXT a second time.
FILE_UPLOAD_MAX_MEMORY_SIZE = 1024 * 1024
OPERATION_EPOCH = os.environ.get('PH_OPERATION_EPOCH', 'local-development-epoch')
PRODUCTION = os.environ.get('PH_PRODUCTION') == '1'
if PRODUCTION:
    if len(SECRET_KEY) < 50 or SECRET_KEY.startswith(('local-', 'REPLACE')) or len(OPERATION_EPOCH) < 32 or OPERATION_EPOCH.startswith('REPLACE') or not os.environ.get('PH_ALLOWED_HOSTS') or DEBUG or not SESSION_COOKIE_SECURE:
        raise ImproperlyConfigured('production_configuration_required: configure unique secret, epoch, explicit hosts and HTTPS cookies; disable debug/local HTTP')
    if any(host in ('*', 'testserver', '') for host in ALLOWED_HOSTS):
        raise ImproperlyConfigured('production_configuration_required: wildcard hosts are forbidden')
SECURE_SSL_REDIRECT = PRODUCTION
SECURE_REDIRECT_EXEMPT = [r'^healthz/$']
# Only enable behind the documented loopback proxy, which overwrites this header.
PROXY_MODE = os.environ.get('PH_PROXY_MODE', 'legacy')
if PROXY_MODE not in ('legacy', 'waitress'):
    raise ImproperlyConfigured('unsupported_proxy_mode')
SECURE_PROXY_SSL_HEADER = ('HTTP_X_FORWARDED_PROTO', 'https') if PRODUCTION and PROXY_MODE == 'legacy' else None
SECURE_HSTS_SECONDS = 3600 if PRODUCTION else 0
SECURE_HSTS_INCLUDE_SUBDOMAINS = False
SECURE_HSTS_PRELOAD = False
DISK_STOP_PERCENT = 85 if PRODUCTION else 99
DISK_MIN_FREE_BYTES = 128 * 1024 * 1024
