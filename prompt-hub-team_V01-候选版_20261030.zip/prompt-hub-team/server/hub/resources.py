import os
import shutil
from django.conf import settings
from .errors import APIError
from .observability import event


def disk_state():
    usage = shutil.disk_usage(settings.DATA_DIR)
    percent = usage.used * 100 / usage.total
    free_inodes = None
    if hasattr(os, 'statvfs'):
        free_inodes = os.statvfs(settings.DATA_DIR).f_favail
    blocked = percent >= settings.DISK_STOP_PERCENT or usage.free < settings.DISK_MIN_FREE_BYTES or (free_inodes is not None and free_inodes < 1024)
    return {'used_percent': round(percent, 1), 'free_bytes': usage.free, 'free_inodes': free_inodes, 'writes_allowed': not blocked}


def guard_write(request):
    state = disk_state()
    if not state['writes_allowed']:
        event(request, 'disk_guard', 'rejected', error_code='disk_guard', **state)
        raise APIError('disk_guard', '存储空间不足，暂不接受业务写入；请联系管理员', 503)
