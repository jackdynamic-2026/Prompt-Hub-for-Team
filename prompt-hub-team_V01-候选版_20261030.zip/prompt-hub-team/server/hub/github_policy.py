"""GitHub cache fencing, rate reservations and response policy."""
import json
import math
from datetime import datetime, timedelta, timezone as dt_timezone
from email.utils import parsedate_to_datetime
from django.db import transaction
from django.utils import timezone
from .errors import APIError
from .models import ExternalLease, RateBucket, RepositoryCache


def wait_error(code, message, until, scope, cache=None, status=429):
    seconds = max(1, math.ceil((until-timezone.now()).total_seconds()))
    return APIError(code, message, status, scope=scope, retry_after_seconds=seconds,
                    retry_at=until.isoformat(), cached_data_available=bool(cache and cache.stars is not None))


@transaction.atomic
def reserve_attempt(actor_id):
    now, buckets = timezone.now(), []
    for key, maximum, scope in [('github-global', 30, 'global_budget'), (f'github-user-{actor_id}', 5, 'user_budget')]:
        bucket, _ = RateBucket.objects.get_or_create(key=key, defaults={'window_start': now})
        if bucket.blocked_until and bucket.blocked_until > now:
            raise wait_error('github_budget', '仓库查询额度暂不可用，请等待倒计时结束', bucket.blocked_until, scope)
        if now-bucket.window_start >= timedelta(hours=1) or bucket.blocked_until:
            bucket.window_start, bucket.count, bucket.blocked_until = now, 0, None
        if bucket.count >= maximum:
            raise wait_error('github_budget', '仓库查询额度已用完，请稍后再试', bucket.window_start+timedelta(hours=1), scope)
        buckets.append(bucket)
    for bucket in buckets:
        bucket.count += 1
        bucket.save()


def assert_lease(token):
    if not ExternalLease.objects.filter(key='github', token=token, expires_at__gt=timezone.now()).exists():
        raise APIError('github_lease_expired', '本次刷新已失去执行权限，旧结果未写入；请重新读取资料', 409)


@transaction.atomic
def commit_cache(token, key, values, provider_until=None, unreaped_pid=None):
    assert_lease(token)
    cache, _ = RepositoryCache.objects.update_or_create(key=key, defaults=values)
    if unreaped_pid:
        RateBucket.objects.update_or_create(key='github-worker-unreaped', defaults={'window_start': timezone.now(), 'count': unreaped_pid, 'blocked_until': datetime.max.replace(tzinfo=dt_timezone.utc)})
    if provider_until:
        state, _ = RateBucket.objects.get_or_create(key='github-provider-cooldown', defaults={'window_start': timezone.now()})
        state.blocked_until = max(state.blocked_until, provider_until) if state.blocked_until else provider_until
        state.save()
    return cache


def cooldown_until(headers, now):
    dates = [now+timedelta(seconds=60)]
    value = headers.get('retry-after', '')
    try:
        if value.isdecimal():
            dates.append(now+timedelta(seconds=int(value)))
        elif value:
            date = parsedate_to_datetime(value)
            dates.append(date.replace(tzinfo=dt_timezone.utc) if date.tzinfo is None else date)
    except (ValueError, TypeError, OverflowError):
        if value.isdecimal():
            dates.append(datetime.max.replace(tzinfo=dt_timezone.utc))
    if headers.get('x-ratelimit-remaining') == '0':
        try:
            dates.append(datetime.fromtimestamp(int(headers.get('x-ratelimit-reset', '')), dt_timezone.utc))
        except (ValueError, OverflowError, OSError):
            if headers.get('x-ratelimit-reset', '').isdecimal():
                dates.append(datetime.max.replace(tzinfo=dt_timezone.utc))
    return max(dates)


def classify_http(status, headers, body):
    if status in (200, 304):
        return None
    secondary = False
    if status == 403:
        try:
            value = json.loads(body)
            secondary = isinstance(value, dict) and 'secondary rate limit' in str(value.get('message', '')).lower()
        except (ValueError, UnicodeError):
            pass
    limited = status == 429 or (status == 403 and (headers.get('x-ratelimit-remaining') == '0' or 'retry-after' in headers or secondary))
    if limited:
        return {'error': 'github_rate_limited', 'retryable': False, 'provider': True}
    code = 'github_redirect_blocked' if 300 <= status < 400 else 'github_not_found' if status == 404 else 'github_access_denied' if status in (401, 403) else 'github_remote_error'
    return {'error': code, 'retryable': status in (500, 502, 503, 504)}


def check_cooldowns(cache):
    if RateBucket.objects.filter(key='github-worker-unreaped').exists():
        raise APIError('github_worker_unreaped', '网络工作进程未确认结束，已暂停仓库刷新；请联系管理员核验进程', 503, scope='provider_lifecycle', manual_intervention_required=True)
    state = RateBucket.objects.filter(key='github-provider-cooldown').first()
    now = timezone.now()
    if state and state.blocked_until and state.blocked_until > now:
        raise wait_error('github_provider_cooldown', 'GitHub查询正在整体冷却，请等待倒计时结束', state.blocked_until, 'provider', cache)
    if cache and cache.retry_after and cache.retry_after > now:
        raise wait_error('github_cooldown', '该仓库查询正在冷却，请等待倒计时结束', cache.retry_after, 'repository', cache)


def usable_cache(cache):
    return bool(cache and type(cache.stars) is int and cache.stars >= 0 and cache.fetched_at and cache.fetched_at <= timezone.now())


def retry_allowed(result, attempt, remaining_seconds):
    return bool(result.get('retryable') and attempt == 1 and remaining_seconds >= 0.7)


MESSAGES = {
    'github_timeout': '连接或读取GitHub超时，本次有限重试仍未成功',
    'github_connection_failed': '连接GitHub失败，请检查网络后重试',
    'github_network_forbidden': '运行服务的网络访问被系统禁止，请检查服务权限',
    'github_tls_failed': 'GitHub证书验证失败，请检查服务的证书与代理配置',
    'github_time_budget': '本次刷新已达到总时间预算，网络工作已停止',
    'github_not_found': 'GitHub API未找到该公开仓库，请核对地址和可见性',
    'github_redirect_blocked': '仓库可能已迁移或改名，请核对新的GitHub地址',
    'github_access_denied': 'GitHub拒绝访问该仓库，请核对可见性或访问权限',
    'github_rate_limited': 'GitHub暂时限制查询，请等待倒计时结束',
    'github_remote_error': 'GitHub返回服务错误，请稍后重试',
    'github_too_large': 'GitHub响应超过256KiB，旧资料已保留',
}
