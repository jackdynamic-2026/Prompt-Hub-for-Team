import json
from datetime import timedelta
import threading
import uuid
import sys
from django.conf import settings
from django.utils import timezone

lock = threading.Lock()
logging_degraded = False

def event(request, name, result, **fields):
    global logging_degraded
    # Do not resolve Django's lazy user here: logging must not trigger database I/O.
    actor = getattr(request, '_cached_user', None)
    record = {'time': timezone.now().isoformat(), 'level': 'ERROR' if result in ('failed', 'unknown') else 'WARN' if result == 'rejected' else 'INFO', 'build': 'team-v5', 'event': name, 'stage': getattr(request, 'stage', 'request'), 'result': result, 'request_id': request.request_id, 'operation_id': getattr(request, 'operation_id', ''), 'target_type': getattr(request, 'target_type', ''), 'target_id': getattr(request, 'target_id', None), 'actor_id': actor.pk if actor and actor.is_authenticated else None, **fields}
    if getattr(request, 'rate_limit_scope', None) in ('account', 'ip'):
        record['rate_limit_scope'] = request.rate_limit_scope
    line = json.dumps(record, ensure_ascii=False)
    # The file is outside business transactions; failed writes remain diagnosable.
    path = settings.DATA_DIR / 'runtime.jsonl'
    try:
        with lock:
            now = timezone.now().timestamp()
            if path.exists() and (path.stat().st_size > 5 * 1024 * 1024 or now - path.stat().st_mtime > 86400):
                path.replace(settings.DATA_DIR / f'runtime-{uuid.uuid4()}.jsonl')
            rotated = sorted(settings.DATA_DIR.glob('runtime-*.jsonl'), key=lambda p: p.stat().st_mtime, reverse=True)
            for index, old in enumerate(rotated):
                if index >= 18 or now - old.stat().st_mtime > timedelta(days=14).total_seconds():
                    old.unlink()
            with path.open('a', encoding='utf-8') as handle:
                handle.write(line + '\n')
        logging_degraded = False
    except OSError:
        logging_degraded = True
        try:
            sys.stderr.write(json.dumps({'event': 'logging_degraded', 'request_id': request.request_id}) + '\n' + line + '\n')
        except (OSError, ValueError):
            pass  # Health remains degraded when both diagnostic channels are unavailable.
