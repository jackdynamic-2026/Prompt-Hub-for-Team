import re
from urllib.parse import urlsplit, unquote
from .errors import APIError

def parse_source_url(url):
    """Preserve the locator; derive only the repository for fixed-host API I/O."""
    if not isinstance(url, str) or len(url) > 2048 or any(ord(c) < 32 or ord(c) == 127 for c in url) or '\\' in url:
        raise APIError('invalid_source', 'GitHub链接无效')
    clean = url.strip()
    try:
        clean.encode('utf-8', errors='strict')
        parsed = urlsplit(clean)
        decoded = unquote(parsed.path, errors='strict')
    except (ValueError, UnicodeError):
        raise APIError('invalid_source', 'GitHub链接无效')
    parts = parsed.path.split('/')
    if (parsed.scheme != 'https' or parsed.netloc.lower() != 'github.com' or len(parts) < 3
            or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9-]{0,38}', parts[1])
            or not re.fullmatch(r'[A-Za-z0-9_.-]{1,100}', parts[2]) or parts[2] in ('.', '..')):
        raise APIError('invalid_source', '请填写包含所有者和仓库名的GitHub HTTPS链接')
    if (re.search(r'%(?![0-9a-fA-F]{2})', clean) or any(ord(c) < 32 or ord(c) == 127 for c in decoded)
            or '\\' in decoded or any(p in ('.', '..') for p in decoded.split('/'))):
        raise APIError('invalid_source', 'GitHub链接路径无效')
    return parts[1], parts[2], clean


def repository_key(source):
    return f"{source['owner']}/{source['repo']}".lower() if source else None


def validate_source(value):
    if value is None:
        return None
    keys = {'provider', 'owner', 'repo', 'skill_path', 'source_url'}
    if not isinstance(value, dict) or set(value) != keys or value['provider'] != 'github':
        raise APIError('invalid_source', '仅接受公开GitHub标准仓库来源')
    owner, repo, path, url = (value[k] for k in ('owner', 'repo', 'skill_path', 'source_url'))
    if not all(isinstance(x, str) for x in (owner, repo, path, url)):
        raise APIError('invalid_source', '来源字段必须为文本')
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9-]{0,38}', owner) or not re.fullmatch(r'[A-Za-z0-9_.-]{1,100}', repo) or repo in ('.', '..'):
        raise APIError('invalid_source', '仓库名称无效')
    url_owner, url_repo, clean = parse_source_url(url)
    if f'{url_owner}/{url_repo}'.lower() != f'{owner}/{repo}'.lower():
        raise APIError('invalid_source', '请填写包含所有者和仓库名的GitHub HTTPS链接')
    if len(path) > 200 or path.startswith('/') or any(x in path for x in ('\\', '\x00', '?', '#', '%', ':')) or any(p in ('.', '..') for p in path.split('/')):
        raise APIError('invalid_source', 'Skill路径无效')
    return {**value, 'source_url': clean}
