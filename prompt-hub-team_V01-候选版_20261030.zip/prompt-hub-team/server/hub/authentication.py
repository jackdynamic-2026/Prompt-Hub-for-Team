from datetime import timedelta
from hashlib import sha256
from uuid import uuid4
from django.contrib.auth import logout
from django.db import transaction
from django.db.models import F
from django.utils import timezone
from .errors import APIError
from .models import Member, SessionPolicy
from .observability import event


def key_hash(key):
    return sha256((key or '').encode()).hexdigest()


def establish_policy(request):
    if not request.session.session_key:
        request.session.create()
    policy, _ = SessionPolicy.objects.update_or_create(key_hash=key_hash(request.session.session_key), defaults={'actor': request.user, 'auth_version': request.user.auth_version, 'idle_timeout_minutes': request.user.idle_timeout_minutes, 'last_active_at': timezone.now(), 'revoked': False})
    request.session['session_context'] = str(uuid4())
    request.session['auth_version'] = request.user.auth_version
    request.session.modified = True
    return policy


def check_session(request, required=True, touch=False):
    now = timezone.now()
    user = request.user
    policy = SessionPolicy.objects.filter(key_hash=key_hash(request.session.session_key)).first() if user.is_authenticated else None
    valid = bool(policy and user.is_active and not policy.revoked and policy.actor_id == user.pk and policy.auth_version == user.auth_version and request.session.get('auth_version') == user.auth_version and timedelta(0) <= now-policy.last_active_at < timedelta(minutes=policy.idle_timeout_minutes))
    if not valid:
        if user.is_authenticated:
            event(request, 'session.rejected', 'rejected', reason_code='expired_or_revoked')
            logout(request)
        if required:
            raise APIError('unauthenticated', '登录已过期或被撤销，请重新登录', 401)
        return False
    request.session_policy = policy
    if touch:
        with transaction.atomic():
            # Re-read only after acquiring SQLite's IMMEDIATE writer lock.
            check_session(request, touch=False)
            current = Member.objects.filter(pk=user.pk, is_active=True, auth_version=policy.auth_version).first()
            if not current:
                raise APIError('unauthenticated', '账号已撤销', 401)
            policy = request.session_policy
            elapsed = (now-policy.last_active_at).total_seconds()
            if elapsed >= 30:
                policy.last_active_at = max(now, policy.last_active_at)
                policy.save(update_fields=['last_active_at'])
                request.session.modified = True
                event(request, 'session.renewed', 'completed', idle_timeout_minutes=policy.idle_timeout_minutes)
            else:
                event(request, 'session.activity_throttled', 'unchanged', idle_timeout_minutes=policy.idle_timeout_minutes)
    return True


def check_writer(request):
    from .resources import guard_write
    guard_write(request)
    check_session(request, touch=False)
    current = Member.objects.filter(pk=request.user.pk, is_active=True, auth_version=request.session.get('auth_version')).first()
    if not current:
        raise APIError('unauthenticated', '账号权限已变化，请重新登录', 401)
    request.user = current
    check_session(request, touch=True)


def check_context(request):
    supplied = request.headers.get('X-Session-Context')
    if supplied and supplied != request.session.get('session_context'):
        event(request, 'session.context_changed', 'rejected', reason_code='context_mismatch')
        raise APIError('unauthenticated', '登录上下文已变化，请重新登录', 401)
