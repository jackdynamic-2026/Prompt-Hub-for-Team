"""Django DB sessions with expiry derived from the authoritative per-session lease."""
from datetime import timedelta
from math import ceil
from django.contrib.sessions.backends.db import SessionStore as DBStore
from django.contrib.sessions.backends.base import UpdateError
from django.db import transaction
from django.utils import timezone


class SessionStore(DBStore):
    def policy(self):
        from .authentication import key_hash
        from .models import SessionPolicy
        return SessionPolicy.objects.filter(key_hash=key_hash(self.session_key)).first() if self.session_key else None

    def get_expiry_date(self, **kwargs):
        policy = self.policy()
        if policy:
            return policy.last_active_at + timedelta(minutes=policy.idle_timeout_minutes)
        return super().get_expiry_date(**kwargs)

    def get_expiry_age(self, **kwargs):
        policy = self.policy()
        if policy:
            return max(0, ceil((self.get_expiry_date()-timezone.now()).total_seconds()))
        return super().get_expiry_age(**kwargs)

    def save(self, must_create=False):
        with transaction.atomic():
            policy = self.policy()
            if not must_create and self.get('_auth_user_id'):
                if not policy or policy.revoked or self.get_expiry_date() <= timezone.now():
                    raise UpdateError('session revoked or expired')
            return super().save(must_create)

    def delete(self, session_key=None):
        from .authentication import key_hash
        from .models import SessionPolicy
        SessionPolicy.objects.filter(key_hash=key_hash(session_key or self.session_key)).update(revoked=True)
        return super().delete(session_key)
