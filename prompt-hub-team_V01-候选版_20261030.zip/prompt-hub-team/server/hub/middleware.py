import uuid
from django.http import JsonResponse
from .observability import event
from django.contrib.sessions.middleware import SessionMiddleware
from django.contrib.sessions.exceptions import SessionInterrupted
from django.db import DatabaseError


class SafeSessionMiddleware(SessionMiddleware):
    def process_response(self, request, response):
        try:
            return super().process_response(request, response)
        except (DatabaseError, SessionInterrupted) as error:
            # Business may already be committed. Preserve the operation receipt and
            # report uncertainty instead of pretending that this late failure rolled it back.
            request.stage = 'session.persist'
            event(request, 'session.persist', 'failed', error_code='session_persist_unconfirmed', error_type=type(error).__name__)
            result = JsonResponse({'error': 'session_persist_unconfirmed', 'message': '登录状态保存未确认；业务可能已提交，请先查询原操作结果，勿重复新建。', 'request_id': request.request_id}, status=503)
            result['Retry-After'] = '2'
            return result

class RequestContextMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        request.request_id = str(uuid.uuid4())
        response = self.get_response(request)
        response['X-Request-ID'] = request.request_id
        response['Referrer-Policy'] = 'same-origin'
        response['X-Content-Type-Options'] = 'nosniff'
        response['X-Frame-Options'] = 'DENY'
        if request.path.startswith('/api/'):
            response['Cache-Control'] = 'no-store'
        return response

def csrf_failure(request, reason=''):
    event(request, 'csrf.rejected', 'rejected', error_code='csrf_rejected', status=403)
    return JsonResponse({'error': 'csrf_rejected', 'message': '请求验证已失效，请刷新后重新核对', 'request_id': request.request_id}, status=403)
