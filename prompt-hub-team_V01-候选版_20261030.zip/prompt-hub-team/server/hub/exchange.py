import hashlib
import json
import re
import uuid
from datetime import datetime
from django.conf import settings
from django.core import signing
from django.db import transaction
from django.utils import timezone
from .errors import APIError
from .models import Entry, Tag
from .operations import mutation
from .services import body_fields, create_entry, get_entry, audit, serialize, validate_kind, text_field, normalize
from .sources import validate_source
from .observability import event

ROOT_FIELDS = {'format', 'schema_version', 'export_id', 'source_system', 'exported_at', 'scope', 'entry_count', 'entries'}
ENTRY_FIELDS = {'kind', 'title', 'content', 'intro', 'shared_note', 'tags', 'skill_source', 'github_snapshot', 'origin'}
ORIGIN_FIELDS = {'source_entry_id', 'source_author', 'source_created_at', 'source_updated_at', 'source_note_editor', 'source_note_updated_at'}
MAX_BYTES = 20 * 1024 * 1024

def exact(value, keys, label):
    if not isinstance(value, dict) or set(value) != keys:
        raise APIError('invalid_fields', f'{label}缺少字段或包含未知字段')

def timestamp(value):
    text_field(value, '来源时间', 80, True)
    try:
        result = datetime.fromisoformat(value.replace('Z', '+00:00'))
        if result.utcoffset() is None:
            raise ValueError()
    except ValueError:
        raise APIError('invalid_timestamp', '来源时间必须包含时区')
    return value

def strict_json(text):
    try:
        if len(text.encode('utf-8', errors='strict')) > MAX_BYTES:
            raise APIError('too_large', '完整TXT超过20MiB', 413)
    except UnicodeError:
        raise APIError('invalid_unicode', 'TXT包含无效Unicode字符')
    depth, inside, escaped = 0, False, False
    for char in text:
        if inside:
            if escaped:
                escaped = False
            elif char == '\\':
                escaped = True
            elif char == '"':
                inside = False
        elif char == '"':
            inside = True
        elif char in '[{':
            depth += 1
            if depth > 16:
                raise APIError('too_deep', 'JSON嵌套深度超过16')
        elif char in ']}':
            depth -= 1
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise APIError('duplicate_key', 'JSON不允许重复键')
            result[key] = value
        return result
    def constant(value):
        raise APIError('invalid_number', 'JSON不允许NaN或Infinity')
    try:
        return json.loads(text.lstrip('\ufeff'), object_pairs_hook=pairs, parse_constant=constant)
    except (ValueError, RecursionError) as exc:
        raise APIError('invalid_json', 'JSON格式错误', line=getattr(exc, 'lineno', None), column=getattr(exc, 'colno', None))

def parse_full(text):
    document = strict_json(text)
    exact(document, ROOT_FIELDS, '文件')
    if document['format'] != 'prompt-hub-exchange' or type(document['schema_version']) is not int or document['schema_version'] not in (2, 3):
        raise APIError('unsupported_version', '只接受完整TXT协议2或3；其他格式请选择对应模式')
    text_field(document['export_id'], '导出ID', 80, True)
    text_field(document['source_system'], '来源系统', 120, True)
    timestamp(document['exported_at'])
    exact(document['scope'], {'kind', 'filters'}, '范围')
    if document['scope']['kind'] not in ('ALL', 'PROMPT', 'SKILL') or not isinstance(document['scope']['filters'], dict):
        raise APIError('invalid_scope', '文件范围无效')
    entries = document['entries']
    if type(document['entry_count']) is not int or not isinstance(entries, list) or document['entry_count'] != len(entries) or not entries or len(entries) > 2000:
        raise APIError('invalid_count', '条数不一致、为空或超过2000条')
    for index, entry in enumerate(entries):
        try:
            exact(entry, ENTRY_FIELDS | ({'recommendation_snapshot'} if document['schema_version'] == 3 else set()), '条目')
            if document['schema_version'] == 3:
                recommendation_snapshot(entry['recommendation_snapshot'], document['exported_at'])
            fields, tags = body_fields({k: entry[k] for k in ('kind', 'title', 'content', 'intro', 'tags')}, True)
            validate_kind(entry['kind'], fields)
            text_field(entry['shared_note'], '共同备注', 10000)
            exact(entry['origin'], ORIGIN_FIELDS, '来源声明')
            for key in ORIGIN_FIELDS:
                if key.endswith('_at'):
                    timestamp(entry['origin'][key])
                else:
                    text_field(entry['origin'][key], '来源声明', 200)
            entry['skill_source'] = validate_source(entry['skill_source'])
            snap = entry['github_snapshot']
            if snap is not None:
                exact(snap, {'stars', 'fetched_at', 'state'}, 'Star快照')
                if snap['stars'] is not None and (type(snap['stars']) is not int or snap['stars'] < 0):
                    raise APIError('invalid_stars', 'Star必须是非负整数或null')
                if snap['fetched_at'] is not None:
                    timestamp(snap['fetched_at'])
                if snap['state'] not in ('unverified', 'verified', 'stale', 'failed'):
                    raise APIError('invalid_snapshot', '快照状态无效')
            if entry['kind'] == 'PROMPT' and (entry['skill_source'] is not None or snap is not None):
                raise APIError('invalid_prompt', '提示词不应带Skill仓库资料')
            if document['scope']['kind'] != 'ALL' and entry['kind'] != document['scope']['kind']:
                raise APIError('scope_mismatch', '条目类型与文件范围不一致')
        except APIError as exc:
            exc.details['entry_index'] = index + 1
            raise
    return entries

def legacy_heading(line, compatibility):
    """Recognize one header in bounded passes; preserve re's Unicode Nd/space rules."""
    start = 0
    while start < len(line) and line[start].isspace():
        start += 1
    digit_start = start
    while start < len(line) and line[start].isdecimal():
        start += 1
    separators = '、.' if compatibility else '、'
    if start == digit_start or start == len(line) or line[start] not in separators:
        return None
    rest = line[start + 1:]
    if not rest:
        return None
    if compatibility:
        title = rest.strip()
        # The old optional-colon pattern must capture at least one character.
        return title[:-1].strip() if len(title) > 1 and title[-1] in '：:' else title
    rest = rest.rstrip()
    if len(rest) < 2 or rest[-1] not in '：:':
        return None
    return rest[:-1].strip()


def parse_legacy(text, compatibility=False):
    try:
        size = len(text.encode('utf-8', errors='strict'))
    except UnicodeError:
        raise APIError('invalid_unicode', '旧TXT包含无效Unicode字符')
    if size > 1024 * 1024:
        raise APIError('too_large', '旧TXT超过1MiB', 413)
    lines = text.lstrip('\ufeff').replace('\r\n', '\n').replace('\r', '\n').split('\n')
    headings = []
    for i, line in enumerate(lines):
        if i and lines[i - 1].strip():
            continue
        title = legacy_heading(line, compatibility)
        if title is not None:
            headings.append((i, title))
    if not headings or len(headings) > 200:
        raise APIError('legacy_boundaries', '未找到标准标题或超过200条。标准示例：1、标题：，标题须独占一行且前留空行（文件开头除外）')
    if any(line.strip() for line in lines[:headings[0][0]]):
        first = next(i + 1 for i, value in enumerate(lines[:headings[0][0]]) if value.strip())
        raise APIError('legacy_preamble', f'第{first}行：首条标题前有未归属文字，请先整理；不会自动丢弃这些内容', line=first)
    result = []
    for index, (line, title) in enumerate(headings):
        end = headings[index + 1][0] if index + 1 < len(headings) else len(lines)
        content = '\n'.join(lines[line + 1:end]).strip('\n')
        try:
            text_field(title, '旧TXT名称（1–120字符）', 120, True)
            text_field(content, '旧TXT正文（1–50000字符）', 50000, True)
        except APIError as exc:
            raise APIError(exc.code, f'第{line + 1}行（第{index + 1}条）：{exc.message}', exc.status, **{**exc.details, 'line': line + 1, 'entry_index': index + 1}) from exc
        result.append({'kind': 'PROMPT', 'title': title.strip(), 'content': content, 'intro': '', 'shared_note': '', 'tags': [], 'skill_source': None, 'github_snapshot': None, 'origin': {}})
    return result

def parsed(payload, request=None):
    text = payload.get('text')
    if not isinstance(text, str):
        raise APIError('missing_text', '请上传或粘贴TXT')
    mode = payload.get('mode', 'full')
    if mode not in ('full', 'legacy', 'legacy_compatibility', 'skill_simple_v1'):
        raise APIError('invalid_mode', '导入模式无效')
    from .skill_text import parse
    if mode != 'skill_simple_v1' and re.match(r'^Skill TXT v[0-9]+(?:\r?\n|$)', text.removeprefix('\ufeff')):
        raise APIError('format_mismatch', '当前内容是Skill简洁TXT，请选择Skill简洁TXT格式后重新预览')
    context = {'mode': mode, 'input_chars': len(text)}
    if request is not None:
        event(request, 'import.parse', 'started', **context)
    try:
        entries = parse(text) if mode == 'skill_simple_v1' else parse_full(text) if mode == 'full' else parse_legacy(text, mode == 'legacy_compatibility')
    except APIError as exc:
        if request is not None:
            event(request, 'import.parse', 'rejected', error_code=exc.code, **context)
        raise
    if request is not None:
        event(request, 'import.parse', 'completed', entry_count=len(entries), **context)
    return entries, hashlib.sha256((mode + '\0' + text).encode()).hexdigest()

def tag_mapping(entries):
    canonical, sources = {}, {}
    for entry in entries:
        for raw in entry['tags']:
            key = normalize(raw.strip())
            canonical.setdefault(key, (raw.strip(), None))
            sources.setdefault(raw, key)
    keys = list(canonical)
    for offset in range(0, len(keys), 900):
        for tag in Tag.objects.filter(normalized_name__in=keys[offset:offset + 900]):
            canonical[tag.normalized_name] = (tag.name, tag.pk)
    return [{'source': raw, 'target': canonical[key][0], 'existing_tag_id': canonical[key][1]} for raw, key in sources.items()]


def preview(request, payload):
    request.stage = 'import.parse'
    entries, digest = parsed(payload, request)
    request.stage = 'import.capacity_check'
    if Entry.objects.count() + len(entries) > 10000:
        raise APIError('capacity_exceeded', '导入后条目总量超过10000', 413)
    request.stage = 'import.tag_mapping'
    mapping = tag_mapping(entries)
    token = signing.dumps({'digest': digest, 'user': request.user.pk, 'auth_version': request.user.auth_version, 'epoch': settings.OPERATION_EPOCH, 'operation_id': payload.get('operation_id'), 'tag_mapping': mapping}, salt='txt-preview', compress=True)
    return {'preview_token': token, 'entries': entries, 'entry_count': len(entries), 'tag_mapping': mapping, 'warning': '只新建副本；等价标签按下列映射归并；来源不授予身份；Star未重新核验。旧格式请人工核对完整正文与标题边界。'}

def commit(request, payload):
    request.stage = 'import.parse'
    request.exchange_prepared = parsed(payload, request)
    return commit_prepared(request, payload)

@mutation('exchange.commit')
def commit_prepared(request, payload):
    request.stage = 'import.preview_check'
    if payload.get('confirmed') is not True:
        raise APIError('confirmation_required', '请先核对预览并确认')
    entries, digest = request.exchange_prepared
    try:
        value = signing.loads(payload.get('preview_token', ''), salt='txt-preview', max_age=600)
    except signing.BadSignature:
        raise APIError('preview_invalid', '预览已过期或无效，请重新预览', 409)
    expected = {'digest': digest, 'user': request.user.pk, 'auth_version': request.user.auth_version, 'epoch': settings.OPERATION_EPOCH, 'operation_id': payload['operation_id'], 'tag_mapping': tag_mapping(entries)}
    if value != expected:
        raise APIError('preview_changed', '文件、账号或标签映射已变化，请重新预览', 409)
    if Entry.objects.count() + len(entries) > 10000:
        raise APIError('capacity_exceeded', '条目总量超过10000', 413)
    ids = []
    request.stage = 'import.persist'
    for value in entries:
        entry = create_entry.__wrapped__(request, {k: value[k] for k in ('kind', 'title', 'content', 'intro', 'tags')})
        obj = get_entry(entry['id'])
        obj.skill_source = validate_source(value['skill_source'])
        obj.github_snapshot = value['github_snapshot']
        obj.origin = value['origin']
        obj.source_recommendation_snapshot = value.get('recommendation_snapshot')
        obj.save(update_fields=['skill_source', 'github_snapshot', 'origin', 'source_recommendation_snapshot'])
        obj.note.text = value['shared_note']; obj.note.save(update_fields=['text'])
        ids.append(obj.pk)
    audit(request, 'import.committed', obj, entry_count=len(ids))
    return {'entry_count': len(ids), 'ids': ids}

def recommendation_snapshot(value, exported_at):
    exact(value, {'count', 'captured_at'}, '推荐快照')
    if type(value['count']) is not int or not 0 <= value['count'] <= 2147483647:
        raise APIError('invalid_recommendation', '推荐快照须为非负整数')
    timestamp(value['captured_at'])
    if value['captured_at'] != exported_at:
        raise APIError('invalid_snapshot', '推荐快照时间应与导出时间一致')

def portable(entry):
    data = serialize(entry)
    return {'kind': entry.kind, 'title': entry.title, 'content': entry.content, 'intro': entry.intro, 'shared_note': data['shared_note'], 'tags': [t['name'] for t in data['tags']], 'skill_source': entry.skill_source, 'github_snapshot': data['github_snapshot'], 'origin': {'source_entry_id': str(entry.pk), 'source_author': entry.owner.username, 'source_created_at': entry.created_at.isoformat(), 'source_updated_at': entry.updated_at.isoformat(), 'source_note_editor': entry.note.updated_by.username, 'source_note_updated_at': entry.note.updated_at.isoformat()}}

def export(request):
    from .query import query_entries
    params = request.GET.copy(); scope = params.pop('scope', ['filtered'])[-1]; mode = params.pop('format', ['full'])[-1]
    if scope not in ('all', 'kind', 'filtered', 'selected') or mode not in ('full', 'full_v3', 'legacy', 'legacy_notes', 'legacy_recommendations', 'skill_simple_v1'):
        raise APIError('invalid_export', '导出范围或格式无效')
    ids = params.pop('ids', [''])[-1]
    if scope == 'kind' and set(params) - {'kind', 'page', 'page_size'}:
        raise APIError('invalid_export', '整类导出不接受筛选条件')
    with transaction.atomic():
        qs = query_entries(params, require_kind=scope != 'all')
        if params.get('favorite'):
            if params['favorite'] != '1':
                raise APIError('invalid_favorite', '收藏筛选无效')
            qs = qs.filter(favorite__actor=request.user)
        if scope == 'selected':
            from .query import parse_int
            selected = {parse_int(x, '条目ID') for x in ids.split(',')}
            qs = qs.filter(pk__in=selected)
            if qs.count() != len(selected):
                raise APIError('missing_selection', '选中条目不存在或已删除', 404)
        if not qs.exists() or qs.count() > 2000:
            raise APIError('export_limit', '导出结果为空或超过2000条，请缩小范围')
        exported_at = timezone.now().isoformat()
        entries = []
        for entry in qs:
            value = portable(entry)
            if mode in ('full_v3', 'skill_simple_v1', 'legacy_recommendations'):
                value['recommendation_snapshot'] = {'count': serialize(entry)['recommendation_count'], 'captured_at': exported_at}
            entries.append(value)
    if mode == 'skill_simple_v1':
        from .skill_text import render
        text = render(entries, exported_at)
    elif mode in ('legacy', 'legacy_notes', 'legacy_recommendations'):
        if any(e['kind'] != 'PROMPT' for e in entries):
            raise APIError('legacy_skill', '旧格式不能导出Skills')
        text = '\n\n'.join(f"{i+1}、{e['title']}：\n{e['content']}" + (f"\n{{备注：{e['shared_note']}}}" if mode in ('legacy_notes', 'legacy_recommendations') else '') + (f"\n{{团队推荐数：{e['recommendation_snapshot']['count']}；快照时间：{exported_at}；仅供参考}}" if mode == 'legacy_recommendations' else '') for i, e in enumerate(entries))
    else:
        text = json.dumps({'format': 'prompt-hub-exchange', 'schema_version': 3 if mode == 'full_v3' else 2, 'export_id': str(uuid.uuid4()), 'source_system': 'prompt-hub-team', 'exported_at': exported_at, 'scope': {'kind': 'ALL' if scope == 'all' else params.get('kind'), 'filters': dict(params)}, 'entry_count': len(entries), 'entries': entries}, ensure_ascii=False, indent=2)
    data = text.encode('utf-8')
    if len(data) > MAX_BYTES:
        raise APIError('export_too_large', '导出超过20MiB，请缩小范围', 413)
    from .observability import event
    event(request, 'export_ready', 'completed', entry_count=len(entries), byte_count=len(data), export_scope=scope, export_format=mode, transport_state='unknown')
    return data
