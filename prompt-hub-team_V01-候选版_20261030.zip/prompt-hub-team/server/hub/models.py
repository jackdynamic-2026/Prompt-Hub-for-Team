from django.contrib.auth.models import AbstractUser
from django.db import models

class Member(AbstractUser):
    REQUIRED_FIELDS = ['display_name']
    display_name = models.CharField(max_length=80)
    auth_version = models.PositiveIntegerField(default=1)
    must_change_password = models.BooleanField(default=False)  # Legacy gate remains off.
    password_change_suggested = models.BooleanField(default=True, db_default=True)
    idle_timeout_minutes = models.PositiveIntegerField(default=60, db_default=60)

    @classmethod
    def normalize_username(cls, username):
        import unicodedata
        return unicodedata.normalize('NFKC', username).casefold()

    def save(self, *args, **kwargs):
        self.username = self.normalize_username(self.username)
        return super().save(*args, **kwargs)

class Tag(models.Model):
    name = models.CharField(max_length=30)
    normalized_name = models.CharField(max_length=120, unique=True)

class Entry(models.Model):
    kind = models.CharField(max_length=6, choices=[('PROMPT', 'PROMPT'), ('SKILL', 'SKILL')])
    title = models.CharField(max_length=120)
    normalized_title = models.TextField()
    content = models.TextField(blank=True)
    intro = models.TextField(blank=True)
    owner = models.ForeignKey(Member, on_delete=models.PROTECT)
    tags = models.ManyToManyField(Tag)
    tag_version = models.PositiveIntegerField(default=1, db_default=1)
    source_recommendation_snapshot = models.JSONField(null=True, default=None)
    body_version = models.PositiveIntegerField(default=1)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now_add=True)
    deleted_at = models.DateTimeField(null=True)
    skill_source = models.JSONField(null=True, default=None)
    github_snapshot = models.JSONField(null=True, default=None)
    origin = models.JSONField(default=dict)
    source_version = models.PositiveIntegerField(default=1)

class SharedNote(models.Model):
    entry = models.OneToOneField(Entry, on_delete=models.CASCADE, related_name='note')
    text = models.TextField(blank=True)
    note_version = models.PositiveIntegerField(default=1)
    updated_by = models.ForeignKey(Member, on_delete=models.PROTECT)
    updated_at = models.DateTimeField(auto_now_add=True)

class AuditEvent(models.Model):
    actor = models.ForeignKey(Member, on_delete=models.PROTECT)
    action = models.CharField(max_length=40)
    target_id = models.PositiveBigIntegerField(null=True)
    request_id = models.CharField(max_length=36)
    operation_id = models.CharField(max_length=80, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    metadata = models.JSONField(default=dict)

class Revision(models.Model):
    entry = models.ForeignKey(Entry, on_delete=models.CASCADE)
    domain = models.CharField(max_length=4)
    version = models.PositiveIntegerField()
    snapshot = models.JSONField()
    actor = models.ForeignKey(Member, on_delete=models.PROTECT)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        constraints = [models.UniqueConstraint(fields=['entry', 'domain', 'version'], name='unique_revision_version')]

class OperationReceipt(models.Model):
    actor = models.ForeignKey(Member, on_delete=models.PROTECT)
    operation_id = models.CharField(max_length=80)
    digest = models.CharField(max_length=64)
    result = models.JSONField()
    expires_at = models.DateTimeField()

    class Meta:
        constraints = [models.UniqueConstraint(fields=['actor', 'operation_id'], name='unique_actor_operation')]

class Favorite(models.Model):
    actor = models.ForeignKey(Member, on_delete=models.CASCADE)
    entry = models.ForeignKey(Entry, on_delete=models.CASCADE)

    class Meta:
        constraints = [models.UniqueConstraint(fields=['actor', 'entry'], name='unique_favorite')]

class RateBucket(models.Model):
    key = models.CharField(max_length=100, unique=True)
    count = models.PositiveIntegerField(default=0)
    window_start = models.DateTimeField()
    blocked_until = models.DateTimeField(null=True)

class RepositoryCache(models.Model):
    key = models.CharField(max_length=150, unique=True)
    stars = models.PositiveBigIntegerField(null=True)
    fetched_at = models.DateTimeField(null=True)
    state = models.CharField(max_length=20, default='unverified')
    etag = models.CharField(max_length=250, blank=True)
    description = models.TextField(blank=True)
    retry_after = models.DateTimeField(null=True)

class ExternalLease(models.Model):
    key = models.CharField(max_length=40, unique=True)
    token = models.CharField(max_length=36)
    expires_at = models.DateTimeField()

class Recommendation(models.Model):
    actor = models.ForeignKey(Member, on_delete=models.CASCADE)
    entry = models.ForeignKey(Entry, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        constraints = [models.UniqueConstraint(fields=['actor', 'entry'], name='unique_recommendation')]

class SessionPolicy(models.Model):
    # A lease for the existing Django session, not a separate authentication system.
    key_hash = models.CharField(max_length=64, primary_key=True)
    actor = models.ForeignKey(Member, on_delete=models.CASCADE)
    auth_version = models.PositiveIntegerField()
    idle_timeout_minutes = models.PositiveIntegerField(default=60)
    last_active_at = models.DateTimeField()
    policy_version = models.PositiveIntegerField(default=1)
    created_at = models.DateTimeField(auto_now_add=True)
    revoked = models.BooleanField(default=False)
