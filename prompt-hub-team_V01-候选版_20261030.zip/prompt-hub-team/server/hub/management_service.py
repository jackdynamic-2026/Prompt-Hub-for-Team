import re
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError
from django.db import IntegrityError
from .errors import APIError
from .models import Member, AuditEvent
from .operations import mutation
from .services import text_field

def require_admin(request):
    if not request.user.is_superuser:
        raise APIError('forbidden', '仅管理员可执行此操作', 403)

def member_json(member):
    return {'id': member.pk, 'username': member.username, 'display_name': member.display_name, 'is_admin': member.is_superuser, 'is_active': member.is_active, 'must_change_password': False, 'password_change_suggested': member.password_change_suggested or member.must_change_password, 'idle_timeout_minutes': member.idle_timeout_minutes}

def password(value, member=None):
    if not isinstance(value, str) or len(value) > 1024:
        raise APIError('invalid_password', '口令格式无效')
    try:
        validate_password(value, member)
    except ValidationError:
        raise APIError('weak_password', '临时口令至少8位，且不能使用常见密码')
    return value

def account_audit(request, action, target):
    request.target_id = target.pk
    request.target_type = 'member'
    AuditEvent.objects.create(actor=request.user, action=action, target_id=target.pk, request_id=request.request_id, operation_id=request.operation_id, metadata={'target_type': 'member'})

@mutation('member.create')
def create_member(request, payload):
    require_admin(request)
    if set(payload) - {'username', 'display_name', 'temporary_password', 'is_admin', 'operation_id', 'operation_epoch'}:
        raise APIError('unknown_field', '未知成员字段')
    username = Member.normalize_username(text_field(payload.get('username'), '用户名', 150, True).strip())
    display = text_field(payload.get('display_name'), '显示名', 80, True).strip()
    if not re.fullmatch(r'[\w.@+-]{1,150}', username) or type(payload.get('is_admin', False)) is not bool:
        raise APIError('invalid_member', '用户名或管理员标志无效')
    if Member.objects.filter(username=username).exists():
        raise APIError('username_exists', '用户名已存在', 409)
    member = Member.objects.create_user(username=username, display_name=display, password=password(payload.get('temporary_password')), is_superuser=payload.get('is_admin', False), must_change_password=False, password_change_suggested=True)
    account_audit(request, 'account.created', member)
    return member_json(member)

@mutation('member.update')
def update_member(request, member_id, payload):
    require_admin(request)
    if set(payload) - {'display_name', 'temporary_password', 'is_admin', 'is_active', 'operation_id', 'operation_epoch'}:
        raise APIError('unknown_field', '未知成员字段')
    member = Member.objects.filter(pk=member_id).first()
    if not member:
        raise APIError('not_found', '成员不存在', 404)
    active = payload.get('is_active', member.is_active); admin = payload.get('is_admin', member.is_superuser)
    if type(active) is not bool or type(admin) is not bool:
        raise APIError('invalid_member', '成员状态必须为布尔值')
    if member.pk == request.user.pk and not active:
        raise APIError('self_disable', '不能通过网页停用当前账号')
    if member.is_active and member.is_superuser and (not active or not admin) and Member.objects.filter(is_active=True, is_superuser=True).count() <= 1:
        raise APIError('last_admin', '必须保留一个有效管理员')
    security_changed = active != member.is_active or admin != member.is_superuser or 'temporary_password' in payload
    member.is_active, member.is_superuser = active, admin
    if 'display_name' in payload:
        member.display_name = text_field(payload['display_name'], '显示名', 80, True).strip()
    if 'temporary_password' in payload:
        member.set_password(password(payload['temporary_password'], member)); member.must_change_password = False; member.password_change_suggested = True
    if security_changed:
        member.auth_version += 1
    member.save()
    account_audit(request, 'account.updated', member)
    return member_json(member)
