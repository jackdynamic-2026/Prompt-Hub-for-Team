import hashlib
import hmac
import ipaddress
from datetime import timedelta
from django.conf import settings
from django.db import transaction
from django.utils import timezone
from .errors import APIError
from .models import RateBucket

def private_key(prefix, value):
    return prefix + ':' + hmac.new(settings.SECRET_KEY.encode(), str(value).encode(), hashlib.sha256).hexdigest()

def remote_ip(request):
    remote = request.META.get('REMOTE_ADDR', '')
    if remote in settings.TRUSTED_PROXY_IPS and settings.PROXY_MODE != 'waitress':
        remote = request.META.get('HTTP_X_REAL_IP', remote)
    try:
        return str(ipaddress.ip_address(remote))
    except ValueError:
        return 'unknown'

@transaction.atomic
def consume(key, maximum, window_seconds, cooldown_seconds=None):
    now = timezone.now()
    value, _ = RateBucket.objects.get_or_create(key=key, defaults={'window_start': now})
    if value.blocked_until and value.blocked_until > now:
        return False
    if (now - value.window_start).total_seconds() >= window_seconds or value.blocked_until:
        value.count, value.window_start, value.blocked_until = 0, now, None
    value.count += 1
    allowed = value.count <= maximum
    if not allowed:
        value.blocked_until = now + timedelta(seconds=cooldown_seconds or window_seconds)
    value.save()
    return allowed

def login_guard(request, username):
    if not consume(private_key('login-ip', remote_ip(request)), 20, 60):
        request.rate_limit_scope = 'ip'
        raise APIError('login_limited', '登录暂受限制，请稍后重试', 429)
    key = private_key('login-account', username)
    value = RateBucket.objects.filter(key=key).first()
    if value and value.blocked_until and value.blocked_until > timezone.now():
        request.rate_limit_scope = 'account'
        raise APIError('login_limited', '登录暂受限制，请稍后重试', 429)
    return key

def failed_login(key):
    # Five failures suspend the next attempt, independent of browser session.
    consume(key, 4, 900, 900)
