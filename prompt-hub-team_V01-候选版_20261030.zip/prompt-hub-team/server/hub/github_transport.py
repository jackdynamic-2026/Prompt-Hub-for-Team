"""Bounded, disposable GitHub I/O. No Django, database or application secrets."""
import base64
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import threading
import time
import requests

MAX_BODY = 256 * 1024
MAX_REPLY = 384 * 1024
NETWORK_ENV = {'SYSTEMROOT', 'WINDIR', 'TEMP', 'TMP', 'PATH', 'LANG', 'LC_ALL',
               'HTTP_PROXY', 'HTTPS_PROXY', 'ALL_PROXY', 'NO_PROXY',
               'REQUESTS_CA_BUNDLE', 'CURL_CA_BUNDLE', 'SSL_CERT_FILE', 'SSL_CERT_DIR'}


def watch_parent():
    # Only the parent owns the write end. EOF is an OS-level parent-lifetime
    # signal, including abrupt parent termination, on both Windows and Linux.
    def monitor():
        os.read(sys.stdin.fileno(), 1)
        os._exit(70)
    threading.Thread(target=monitor, daemon=True).start()


def classify_exception(error):
    pending, seen, codes = [error], set(), []
    while pending:
        item = pending.pop()
        if id(item) in seen:
            continue
        seen.add(id(item))
        codes.append((getattr(item, 'errno', None), getattr(item, 'winerror', None)))
        pending.extend(value for value in [item.__cause__, item.__context__, getattr(item, 'reason', None), *item.args] if isinstance(value, BaseException))
    system = next(((errno, winerror) for errno, winerror in codes if errno is not None or winerror is not None), (None, None))
    if any(errno in (1, 13) or winerror in (5, 10013) for errno, winerror in codes):
        code, retry = 'github_network_forbidden', False
    elif isinstance(error, requests.exceptions.SSLError):
        code, retry = 'github_tls_failed', False
    elif isinstance(error, requests.exceptions.Timeout):
        code, retry = 'github_timeout', True
    else:
        code, retry = 'github_connection_failed', True
    return {'error': code, 'retryable': retry, 'exception_type': type(error).__name__, 'os_errno': system[0], 'winerror': system[1]}


def run_process(command, deadline, on_event=None, cwd=None):
    def emit(name, **fields):
        if on_event:
            on_event(name, **fields)
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        return {'error': 'github_time_budget', 'retryable': False}
    env = {key: value for key, value in os.environ.items() if key.upper() in NETWORK_ENV}
    env.update(PYTHONDONTWRITEBYTECODE='1', PYTHONIOENCODING='utf-8', PYTHONUNBUFFERED='1')
    try:
        child = subprocess.Popen(command, cwd=cwd, env=env, stdin=subprocess.PIPE,
                                 stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                 creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
    except OSError as exc:
        emit('worker_failed', error_code='github_worker_start_failed', exception_type=type(exc).__name__)
        return {'error': 'github_worker_start_failed', 'retryable': False}
    emit('worker_started', worker_pid=child.pid)
    output = []

    def read_output():
        try:
            data = child.stdout.read(MAX_REPLY + 1)
            output.append(data)
            if len(data) > MAX_REPLY:
                child.kill()
        except OSError:
            output.append(b'')
    reader = threading.Thread(target=read_output, daemon=True)
    reader.start()
    timed_out = False
    try:
        child.wait(timeout=max(0.001, deadline-time.monotonic()))
    except subprocess.TimeoutExpired:
        timed_out = True
        emit('worker_terminated', worker_pid=child.pid, error_code='github_time_budget')
        try:
            child.kill()
        except OSError:
            if child.poll() is None:
                emit('worker_failed', worker_pid=child.pid, error_code='github_worker_unreaped')
                return {'error': 'github_worker_unreaped', 'retryable': False, 'worker_pid': child.pid}
        try:
            child.wait(timeout=2)
        except subprocess.TimeoutExpired:
            emit('worker_failed', worker_pid=child.pid, error_code='github_worker_unreaped')
            return {'error': 'github_worker_unreaped', 'retryable': False, 'worker_pid': child.pid}
    finally:
        child.stdin.close()
        reader.join(timeout=1)
        if not reader.is_alive():
            child.stdout.close()
    if child.poll() is not None:
        emit('worker_reaped', worker_pid=child.pid, exit_code=child.returncode)
    if timed_out:
        return {'error': 'github_time_budget', 'retryable': False}
    if child.returncode != 0 or not output or len(output[0]) > MAX_REPLY:
        return {'error': 'github_worker_failed', 'retryable': False}
    try:
        result = json.loads(output[0])
    except (ValueError, UnicodeError):
        return {'error': 'github_worker_invalid_output', 'retryable': False}
    return result if isinstance(result, dict) else {'error': 'github_worker_invalid_output', 'retryable': False}


def fetch_once(owner, repo, etag, deadline, on_event=None):
    data = json.dumps({'owner': owner, 'repo': repo, 'etag': etag, 'deadline': deadline})
    return run_process([sys.executable, '-m', 'hub.github_transport', data], deadline,
                       on_event, str(Path(__file__).resolve().parent.parent))


def worker(data):
    watch_parent()
    owner, repo = data['owner'], data['repo']
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9-]{0,38}', owner) or not re.fullmatch(r'[A-Za-z0-9_.-]{1,100}', repo) or repo in ('.', '..'):
        return {'error': 'github_invalid_source', 'retryable': False}
    remaining = data['deadline']-time.monotonic()
    if remaining <= 0:
        return {'error': 'github_time_budget', 'retryable': False}
    headers = {'Accept': 'application/vnd.github+json', 'User-Agent': 'PromptHub-Team/1.0', 'X-GitHub-Api-Version': '2022-11-28'}
    if data['etag']:
        headers['If-None-Match'] = data['etag']
    try:
        with requests.get(f'https://api.github.com/repos/{owner}/{repo}', headers=headers,
                          timeout=(min(3, remaining), min(5, remaining)), allow_redirects=False, stream=True) as response:
            selected = {key.lower(): response.headers[key][:250] for key in ('ETag', 'Retry-After', 'X-RateLimit-Remaining', 'X-RateLimit-Reset') if key in response.headers}
            body = bytearray()
            for chunk in response.iter_content(8192):
                body.extend(chunk)
                if len(body) > MAX_BODY:
                    return {'error': 'github_too_large', 'retryable': False}
                if time.monotonic() >= data['deadline']:
                    return {'error': 'github_time_budget', 'retryable': False}
            return {'status': response.status_code, 'headers': selected, 'body': base64.b64encode(body).decode('ascii'), 'bytes_read': len(body)}
    except requests.RequestException as exc:
        return classify_exception(exc)


if __name__ == '__main__':
    print(json.dumps(worker(json.loads(sys.argv[1]))), flush=True)
