from datetime import date, datetime, time, timedelta
from zoneinfo import ZoneInfo
from django.db.models import Q, Count
from .errors import APIError
from .models import Entry, Member, Tag
from .services import normalize

def parse_int(value, name, minimum=1, maximum=2**63-1):
    if not isinstance(value, str) or not value.isascii() or not value.isdecimal() or not minimum <= int(value) <= maximum:
        raise APIError('invalid_query', f'{name}无效')
    return int(value)

def query_entries(params, require_kind=True):
    allowed = {'kind', 'name', 'tag_ids', 'owner_id', 'updated_from', 'updated_to', 'page', 'page_size', 'favorite'}
    if set(params) - allowed:
        raise APIError('unknown_query', '未知查询条件')
    kind = params.get('kind')
    if kind not in ('PROMPT', 'SKILL') and (require_kind or kind):
        raise APIError('invalid_kind', '请选择提示词或Skills')
    qs = Entry.objects.filter(deleted_at__isnull=True).select_related('owner', 'note__updated_by').prefetch_related('tags').annotate(recommendation_total=Count('recommendation', filter=Q(recommendation__actor__is_active=True), distinct=True))
    if kind:
        qs = qs.filter(kind=kind)
    name = params.get('name', '')
    if len(name) > 120:
        raise APIError('invalid_query', '名称过长')
    if name:
        qs = qs.filter(normalized_title__contains=normalize(name))
    raw = params.get('tag_ids', '')
    if raw:
        ids = {parse_int(x, '标签') for x in raw.split(',')}
        if len(ids) > 10 or Tag.objects.filter(pk__in=ids).count() != len(ids):
            raise APIError('invalid_tags', '标签不存在或超过10个')
        qs = qs.filter(tags__id__in=ids).distinct()
    owner = params.get('owner_id')
    if owner:
        owner_id = parse_int(owner, '分享人')
        if not Member.objects.filter(pk=owner_id).exists():
            raise APIError('invalid_owner', '分享人不存在')
        qs = qs.filter(owner_id=owner_id)
    try:
        start = date.fromisoformat(params['updated_from']) if params.get('updated_from') else None
        end = date.fromisoformat(params['updated_to']) if params.get('updated_to') else None
        if start and end and start > end:
            raise ValueError()
        zone = ZoneInfo('Asia/Shanghai')
        if start:
            qs = qs.filter(updated_at__gte=datetime.combine(start, time.min, zone))
        if end:
            qs = qs.filter(updated_at__lt=datetime.combine(end + timedelta(days=1), time.min, zone))
    except (ValueError, OverflowError):
        raise APIError('invalid_date', '日期范围无效')
    return qs.order_by('-updated_at', '-id')
