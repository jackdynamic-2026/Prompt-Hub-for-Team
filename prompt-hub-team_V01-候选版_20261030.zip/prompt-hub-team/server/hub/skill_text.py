"""Readable Skill TXT v1. Structure never depends on natural-language numbering."""
import re
from datetime import datetime
from .errors import APIError
from .services import body_fields, text_field
from .sources import validate_source, parse_source_url

HEADER = 'Skill TXT v1'
START, END = '=== Skill ===', '=== 结束 ==='
BLOCKS = {'介绍', '备注', '标签'}
FIELDS = BLOCKS | {'名称', 'GitHub', '仓库路径', '分享人', 'GitHub Star', '团队推荐'}


def date(value):
    if not re.fullmatch(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?(?:Z|[+-]\d{2}:\d{2})', value):
        raise APIError('invalid_timestamp', '时间必须包含日期、秒和时区')
    try:
        datetime.fromisoformat(value.replace('Z', '+00:00'))
    except ValueError:
        raise APIError('invalid_timestamp', '日期或时间无效')
    return value


def number(value):
    if not re.fullmatch(r'0|[1-9][0-9]{0,9}', value) or int(value) > 2147483647:
        raise APIError('invalid_number', '星数须为0至2147483647的十进制整数')
    return int(value)


def allowed_text(text):
    if len(text.encode('utf-8', errors='strict')) > 20 * 1024 * 1024:
        raise APIError('too_large', 'Skill TXT超过20MiB', 413)
    text = text.removeprefix('\ufeff').replace('\r\n', '\n')
    for index, line in enumerate(text.split('\n'), 1):
        if any((ord(c) < 32 and c != '\t') or ord(c) == 127 for c in line):
            raise APIError('invalid_text', '文件含不允许的控制字符或裸CR', line=index)
        if len(line.encode('utf-8')) > 65536:
            raise APIError('line_too_long', '单行超过65536字节', line=index)
    return text


def convert(values, exported_at):
    source = None
    url = values.get('GitHub', '')
    if url:
        try:
            owner, repo, clean = parse_source_url(url)
        except APIError as exc:
            exc.details['field'] = 'GitHub'; raise
        source = {'provider': 'github', 'owner': owner, 'repo': repo, 'skill_path': values.get('仓库路径', ''), 'source_url': clean}
    elif values.get('仓库路径') or 'GitHub Star' in values:
        raise APIError('invalid_source', '路径和Star快照需要GitHub来源', field='仓库路径' if values.get('仓库路径') else 'GitHub Star')
    if source:
        try:
            validate_source({**source, 'skill_path': ''})
        except APIError as exc:
            exc.details['field'] = 'GitHub'; raise
        try:
            validate_source(source)
        except APIError as exc:
            exc.details['field'] = '仓库路径'; raise
    data = {'kind': 'SKILL', 'title': values.get('名称', ''), 'content': '', 'intro': '\n'.join(values.get('介绍', [])), 'tags': values.get('标签', []), 'skill_source': source}
    fields, tags = body_fields(data, True)
    for key in ('title',):
        if any(ord(c) < 32 for c in fields[key]):
            raise APIError('invalid_field', '名称必须是单行文本', field='名称')
    snap = None
    star = values.get('GitHub Star', '未知')
    try:
        if star != '未知':
            parts = star.split('；采集时间：')
            if len(parts) != 2:
                raise APIError('invalid_stars', 'Star需要明确采集时间或未知声明')
            snap = {'stars': number(parts[0]), 'fetched_at': None if parts[1] == '未知' else date(parts[1]), 'state': 'unverified'}
    except APIError as exc:
        exc.details['field'] = 'GitHub Star'; raise
    recommendation = None
    if '团队推荐' in values:
        try:
            recommendation = {'count': number(values['团队推荐']), 'captured_at': exported_at}
        except APIError as exc:
            exc.details['field'] = '团队推荐'; raise
    return {'kind': 'SKILL', 'title': fields['title'], 'content': '', 'intro': fields['intro'], 'tags': list(tags.values()), 'skill_source': fields['skill_source'], 'shared_note': text_field('\n'.join(values.get('备注', [])), '备注', 10000), 'github_snapshot': snap, 'origin': {'source_author': text_field(values.get('分享人', ''), '分享人', 200)}, 'recommendation_snapshot': recommendation}


def parse(text):
    try:
        lines = allowed_text(text).split('\n')
    except UnicodeError:
        raise APIError('invalid_unicode', '文件不是有效Unicode')
    if not lines or lines[0] != HEADER:
        raise APIError('unsupported_skill_version', '首行应为Skill TXT v1；请核对格式', line=1)
    if len(lines) < 2 or not lines[1].startswith('导出时间：'):
        raise APIError('missing_export_time', '第二行需要导出时间', line=2)
    try:
        exported_at = date(lines[1].split('：', 1)[1].strip())
    except APIError as exc:
        exc.details.update(line=2,field='导出时间'); raise
    entries, current, block, field = [], None, None, ''
    field_lines = {}
    for lineno, line in enumerate(lines[2:], 3):
        try:
            if not line.strip():
                continue
            if line == START:
                if current is not None:
                    raise APIError('skill_boundary', '上一条Skill缺少结束标记')
                if len(entries) >= 2000:
                    raise APIError('invalid_count', '最多2000条Skill')
                current, block = {}, None
                field_lines = {}
            elif line == END:
                if current is None:
                    raise APIError('skill_boundary', '缺少Skill开始标记')
                entries.append(convert(current, exported_at))
                current, block = None, None
            elif current is None:
                raise APIError('skill_boundary', '条目外出现未知文字或标记')
            elif line == '|' or line.startswith('| '):
                if block is None:
                    raise APIError('invalid_block', '多行内容缺少字段头')
                current[block].append('' if line == '|' else line[2:])
            else:
                key, sep, value = line.partition('：')
                field = key if key in FIELDS else ''
                if not sep or key not in FIELDS:
                    raise APIError('unknown_field', '未知字段或内容行缺少“| ”前缀')
                field_lines[key] = lineno
                if key in current:
                    raise APIError('duplicate_field', '不允许重复字段')
                if key in BLOCKS:
                    if value:
                        raise APIError('invalid_block', '多行字段头须独占一行')
                    current[key], block = [], key
                else:
                    current[key], block = value.strip(), None
        except APIError as exc:
            actual_field = exc.details.get('field', field)
            exc.details.update(line=field_lines.get(actual_field, lineno), entry_index=len(entries)+1, field=actual_field)
            raise
    if current is not None or not entries:
        raise APIError('skill_boundary', '文件为空或最后一条缺少结束标记', line=len(lines))
    return entries


def block(name, value):
    return [name+'：'] + [('| '+line if line else '|') for line in value.split('\n')] if value else [name+'：']


def render(entries, exported_at):
    result = [HEADER, '导出时间：'+date(exported_at), '']
    for entry in entries:
        if entry['kind'] != 'SKILL':
            raise APIError('skill_only', 'Skill简洁TXT不能包含提示词')
        for scalar in (entry['title'], entry.get('origin', {}).get('source_author', '')):
            if any(ord(c) < 32 or ord(c) == 127 for c in scalar):
                raise APIError('invalid_field', '名称或分享人不能包含控制字符')
        result += [START, '名称：'+entry['title']]
        source = entry['skill_source']
        if source:
            result += ['GitHub：'+source['source_url']]
            if source['skill_path']:
                result += ['仓库路径：'+source['skill_path']]
        result += ['标签：'] + ['| '+t for t in entry['tags']]
        author = entry.get('origin', {}).get('source_author', '')
        if author:
            result += ['分享人：'+author]
        if source:
            snap = entry['github_snapshot']
            if snap and snap['stars'] is not None:
                number(str(snap['stars']))
                result += [f"GitHub Star：{snap['stars']}；采集时间：{date(snap['fetched_at']) if snap['fetched_at'] else '未知'}"]
            else:
                result += ['GitHub Star：未知']
        result += ['团队推荐：'+str(entry['recommendation_snapshot']['count'])]
        result += block('介绍', entry['intro']) + block('备注', entry['shared_note']) + [END, '']
    text = '\n'.join(result)
    allowed_text(text)
    return text
