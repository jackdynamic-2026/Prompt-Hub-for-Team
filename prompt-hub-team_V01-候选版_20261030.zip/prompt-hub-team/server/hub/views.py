import json
import time
import uuid
from functools import wraps
from django.contrib.auth import authenticate, login, logout
from django.http import FileResponse, JsonResponse, HttpResponse
from django.conf import settings
from django.middleware.csrf import get_token
from django.utils import timezone
from django.views.decorators.csrf import ensure_csrf_cookie
from .errors import APIError
from .observability import event
from . import services
from .models import Entry
from .authentication import check_session, establish_policy, check_context
from django.db import OperationalError
from .models import Member, OperationReceipt, AuditEvent, RateBucket, Favorite, Tag

def endpoint(methods, authenticated=True, allow_password_change=False):
    def decorate(fn):
        @wraps(fn)
        def wrapper(request, *args, **kwargs):
            request.request_id = getattr(request, 'request_id', str(uuid.uuid4()))
            request.stage = fn.__name__
            request.target_type = 'entry' if 'entry_id' in kwargs else 'member' if 'member_id' in kwargs else ''
            request.target_id = kwargs.get('entry_id', kwargs.get('member_id'))
            start = time.monotonic()
            event(request, fn.__name__, 'started')
            try:
                if request.method not in methods:
                    raise APIError('method_not_allowed', '请求方法不允许', 405)
                if authenticated:
                    check_session(request)
                    check_context(request)
                response = fn(request, *args, **kwargs)
                event(request, fn.__name__, 'completed', status=response.status_code, duration_ms=round((time.monotonic() - start) * 1000))
            except APIError as exc:
                event(request, fn.__name__, 'rejected', status=exc.status, error_code=exc.code, duration_ms=round((time.monotonic() - start) * 1000))
                response = JsonResponse({'error': exc.code, 'message': exc.message, 'request_id': request.request_id, **exc.details}, status=exc.status)
                if 'retry_after_seconds' in exc.details:
                    response['Retry-After'] = str(exc.details['retry_after_seconds'])
            except OperationalError:
                event(request, fn.__name__, 'failed', error_code='database_unavailable')
                response = JsonResponse({'error': 'database_unavailable', 'message': '数据库暂不可用，请保留输入并核对操作结果', 'request_id': request.request_id}, status=503)
                response['Retry-After'] = '2'
            except Exception as exc:
                import traceback
                from pathlib import Path
                location = [f'{Path(frame.filename).name}:{frame.lineno}:{frame.name}' for frame in traceback.extract_tb(exc.__traceback__)[-3:]]
                event(request, fn.__name__, 'failed', error_code='internal_error', error_type=type(exc).__name__, error_location=location)
                response = JsonResponse({'error': 'internal_error', 'message': '操作异常，请保留输入并凭关联号联系管理员；写入结果请先核对', 'request_id': request.request_id}, status=500)
            response['X-Request-ID'] = request.request_id
            response['Cache-Control'] = 'no-store'
            return response
        return wrapper
    return decorate

def payload(request):
    try:
        value = json.loads(request.body)
        if not isinstance(value, dict):
            raise ValueError()
        return value
    except (ValueError, UnicodeError):
        raise APIError('invalid_json', '请求必须为JSON对象')

def user_json(user):
    return {'id': user.pk, 'username': user.username, 'display_name': user.display_name, 'is_admin': user.is_superuser, 'must_change_password': False, 'password_change_suggested': user.password_change_suggested or user.must_change_password, 'idle_timeout_minutes': user.idle_timeout_minutes}


@endpoint(['GET'], authenticated=False)
def health_view(request):
    from django.db import connection
    from .resources import disk_state
    with connection.cursor() as cursor:
        cursor.execute('SELECT 1'); cursor.fetchone()
    Member.objects.values_list('pk', flat=True).first()
    from . import observability
    good = disk_state()['writes_allowed'] and not observability.logging_degraded
    return JsonResponse({'status': 'ok' if good else 'degraded'}, status=200 if good else 503)

@ensure_csrf_cookie
@endpoint(['GET'], authenticated=False)
def session_view(request):
    check_session(request, required=False, touch=False)
    return JsonResponse({'user': user_json(request.user) if request.user.is_authenticated else None, 'csrf_token': get_token(request), 'operation_epoch': settings.OPERATION_EPOCH, 'session_context': request.session.get('session_context') if request.user.is_authenticated else None})

@endpoint(['POST'], authenticated=False)
def login_view(request):
    data = payload(request)
    from .rate_limits import login_guard, failed_login
    name = data.get('username', '')
    if not isinstance(name, str) or len(name) > 150 or not isinstance(data.get('password'), str) or len(data['password']) > 1024:
        raise APIError('invalid_credentials', '用户名或密码错误', 401)
    name = Member.normalize_username(name)
    key = login_guard(request, name)
    user = authenticate(request, username=name, password=data.get('password', ''))
    if not user:
        failed_login(key)
        raise APIError('invalid_credentials', '用户名或密码错误', 401)
    RateBucket.objects.filter(key=key).delete()
    login(request, user)
    request.session['auth_version'] = user.auth_version
    request.session['started_at'] = timezone.now().timestamp()
    request.session['last_active_at'] = timezone.now().timestamp()
    establish_policy(request)
    return JsonResponse({'user': user_json(user), 'session_context': request.session.get('session_context')})

@endpoint(['POST'], authenticated=False)
def logout_view(request):
    if request.user.is_authenticated:
        check_context(request)
    logout(request)
    return JsonResponse({'ok': True, 'session_context': None})

@endpoint(['GET', 'POST'])
def entries_view(request):
    if request.method == 'POST':
        return JsonResponse({'entry': services.create_entry(request, payload(request))}, status=201)
    from .query import parse_int, query_entries
    qs = query_entries(request.GET)
    if request.GET.get('favorite'):
        if request.GET['favorite'] != '1':
            raise APIError('invalid_favorite', '收藏筛选无效')
        qs = qs.filter(favorite__actor=request.user)
    page = parse_int(request.GET.get('page', '1'), '页码')
    size = parse_int(request.GET.get('page_size', '20'), '每页条数', maximum=100)
    total = qs.count()
    kind = request.GET.get('kind')
    base = Entry.objects.filter(kind=kind, deleted_at__isnull=True)
    owners = Member.objects.filter(entry__in=base).distinct().order_by('id')
    tags = Tag.objects.filter(entry__in=base).distinct().order_by('normalized_name')
    facets = {'owners': [{'id': u.pk, 'username': u.username, 'display_name': u.display_name} for u in owners], 'tags': list(tags.values('id', 'name'))}
    recommended_ids = set(services.Recommendation.objects.filter(actor=request.user).values_list('entry_id', flat=True))
    favorite_ids = set(Favorite.objects.filter(actor=request.user).values_list('entry_id', flat=True))
    return JsonResponse({'entries': [{**services.serialize(e), 'is_favorite': e.pk in favorite_ids, 'is_recommended': e.pk in recommended_ids} for e in qs[(page-1)*size:page*size]], 'total': total, 'page': page, 'page_size': size, 'facets': facets})

@endpoint(['GET', 'PATCH', 'DELETE'])
def entry_view(request, entry_id):
    if request.method == 'DELETE':
        return JsonResponse(services.delete_entry(request, entry_id, payload(request)))
    value = services.serialize(services.get_entry(entry_id)) if request.method == 'GET' else services.update_body(request, entry_id, payload(request))
    value['is_recommended'] = services.Recommendation.objects.filter(actor=request.user, entry_id=entry_id).exists()
    value['is_favorite'] = Favorite.objects.filter(actor=request.user, entry_id=entry_id).exists()
    return JsonResponse({'entry': value})

@endpoint(['PATCH'])
def note_view(request, entry_id):
    return JsonResponse({'entry': services.update_note(request, entry_id, payload(request))})

@endpoint(['GET'])
def history_view(request, entry_id):
    return JsonResponse(services.revisions(entry_id))

@endpoint(['POST'])
def restore_view(request, entry_id):
    return JsonResponse({'entry': services.restore(request, entry_id, payload(request))})

@endpoint(['POST'])
def undelete_view(request, entry_id):
    return JsonResponse({'entry': services.undelete(request, entry_id, payload(request))})

def exchange_payload(request):
    if request.FILES:
        file = request.FILES.get('file')
        if not file or file.size > 20 * 1024 * 1024:
            raise APIError('too_large', '文件超过20MiB', 413)
        try:
            text = file.read(20 * 1024 * 1024 + 1).decode('utf-8-sig', errors='strict')
        except UnicodeError:
            raise APIError('invalid_utf8', '文件不是有效UTF-8')
        return {**request.POST.dict(), 'text': text}
    return payload(request)

@endpoint(['POST'])
def preview_view(request):
    from .exchange import preview
    value = preview(request, exchange_payload(request))
    event(request, 'import.preview_ready', 'completed', entry_count=value['entry_count'])
    return JsonResponse(value)

@endpoint(['POST'])
def commit_view(request):
    from .exchange import commit
    return JsonResponse(commit(request, exchange_payload(request)), status=201)

@endpoint(['GET'])
def export_view(request):
    from .exchange import export
    response = HttpResponse(export(request), content_type='text/plain; charset=utf-8')
    response['Content-Disposition'] = 'attachment; filename="prompt-hub-export.txt"'
    return response

@endpoint(['POST'])
def github_view(request, entry_id):
    from .github import refresh
    return JsonResponse(refresh(request, entry_id))

@endpoint(['POST'])
def favorite_view(request, entry_id):
    from django.db import transaction
    data = payload(request)
    if set(data) != {'favorite'} or type(data['favorite']) is not bool:
        raise APIError('invalid_favorite', '请明确设置收藏或取消收藏')
    with transaction.atomic():
        from .authentication import check_writer
        check_writer(request)
        entry = services.get_entry(entry_id)
        if data['favorite']:
            Favorite.objects.get_or_create(actor=request.user, entry=entry)
        else:
            Favorite.objects.filter(actor=request.user, entry=entry).delete()
        services.audit(request, 'favorite.set', entry, favorite=data['favorite'])
    return JsonResponse({'favorite': data['favorite']})

@endpoint(['GET', 'POST'])
def members_view(request):
    from .management_service import require_admin, create_member, member_json
    require_admin(request)
    if request.method == 'POST':
        return JsonResponse({'member': create_member(request, payload(request))}, status=201)
    return JsonResponse({'members': [member_json(member) for member in Member.objects.order_by('id')]})

@endpoint(['PATCH'])
def member_view(request, member_id):
    from .management_service import update_member
    return JsonResponse({'member': update_member(request, member_id, payload(request))})

@endpoint(['GET'])
def recycle_view(request):
    from .management_service import require_admin
    require_admin(request)
    rows = Entry.objects.filter(deleted_at__isnull=False).order_by('-deleted_at')[:100]
    return JsonResponse({'entries': [{'id': entry.pk, 'kind': entry.kind, 'title': entry.title, 'owner_id': entry.owner_id, 'deleted_at': entry.deleted_at.isoformat()} for entry in rows]})

@endpoint(['POST'], allow_password_change=True)
def password_view(request):
    from django.contrib.auth import update_session_auth_hash
    from django.contrib.auth.password_validation import validate_password
    from django.core.exceptions import ValidationError
    from .operations import mutation
    @mutation('account.password')
    def change(request, data):
        if set(data) - {'old_password', 'new_password', 'operation_id', 'operation_epoch'}:
            raise APIError('unknown_field', '未知改密字段')
        old, new = data.get('old_password'), data.get('new_password')
        if not isinstance(old, str) or not request.user.check_password(old):
            raise APIError('invalid_credentials', '原密码错误', 401)
        if not isinstance(new, str) or len(new) > 1024:
            raise APIError('invalid_password', '密码格式无效')
        try:
            validate_password(new, request.user)
        except ValidationError:
            raise APIError('weak_password', '新密码至少8位，且不能使用常见密码')
        request.user.set_password(new); request.user.must_change_password = False; request.user.password_change_suggested = False; request.user.auth_version += 1
        request.user.save(update_fields=['password', 'must_change_password', 'password_change_suggested', 'auth_version'])
        request.target_id=request.user.pk; request.target_type='member'
        AuditEvent.objects.create(actor=request.user, action='account.password_changed', target_id=request.user.pk, request_id=request.request_id, operation_id=data['operation_id'])
        return {'user': user_json(request.user)}
    value = change(request, payload(request))
    update_session_auth_hash(request, request.user)
    request.session['auth_version'] = request.user.auth_version
    establish_policy(request)
    return JsonResponse({**value, 'user': user_json(request.user), 'session_context': request.session.get('session_context')})

@endpoint(['GET'])
def operation_view(request, operation_id):
    receipt = OperationReceipt.objects.filter(actor=request.user, operation_id=operation_id).first()
    if not receipt:
        raise APIError('receipt_unknown', '结果尚未确认，请稍后查询或核对当前内容', 404)
    if receipt.expires_at <= timezone.now():
        raise APIError('receipt_expired', '回执已过期，请核对当前内容', 409)
    return JsonResponse({'result': receipt.result, 'expires_at': receipt.expires_at.isoformat()})

@endpoint(['GET', 'POST', 'PATCH', 'DELETE'], authenticated=False)
def unknown_api(request):
    raise APIError('not_found', '接口不存在', 404)

def frontend_view(request):
    path = settings.BASE_DIR.parent / 'dist' / 'index.html'
    if not path.is_file():
        return JsonResponse({'error': 'build_required', 'message': '请先构建前端'}, status=503)
    response = FileResponse(path.open('rb'), content_type='text/html; charset=utf-8')
    response['Cache-Control'] = 'no-store'
    import re, hashlib, base64
    scripts = re.findall(rb'<script[^>]*>(.*?)</script>', path.read_bytes(), re.S)
    hashes = ' '.join("'sha256-" + base64.b64encode(hashlib.sha256(script).digest()).decode() + "'" for script in scripts)
    response['Content-Security-Policy'] = f"default-src 'self'; script-src 'self' {hashes}; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'"
    return response


@endpoint(['POST'])
def tags_view(request, entry_id):
    return JsonResponse(services.update_tags(request, entry_id, payload(request)))

@endpoint(['POST'])
def recommendation_view(request, entry_id):
    return JsonResponse(services.set_recommendation(request, entry_id, payload(request)))

@endpoint(['POST'])
def preferences_view(request):
    from .operations import mutation
    @mutation('account.preferences')
    def save(request, data):
        if set(data) - {'idle_timeout_minutes', 'dismiss_password_suggestion', 'operation_id', 'operation_epoch'}:
            raise APIError('unknown_field', '未知个人设置字段')
        if 'idle_timeout_minutes' in data:
            value = data['idle_timeout_minutes']
            if type(value) is not int or not 5 <= value <= 10080:
                raise APIError('invalid_idle_timeout', '无操作时长须为5至10080的整数分钟')
            request.user.idle_timeout_minutes = value
        if 'dismiss_password_suggestion' in data:
            if data['dismiss_password_suggestion'] is not True:
                raise APIError('invalid_suggestion', '请选择暂不修改')
            request.user.must_change_password = False
            request.user.password_change_suggested = False
        request.user.save(update_fields=['idle_timeout_minutes', 'must_change_password', 'password_change_suggested'])
        from .models import SessionPolicy
        if 'idle_timeout_minutes' in data:
            SessionPolicy.objects.filter(pk=request.session_policy.pk, revoked=False).update(idle_timeout_minutes=data['idle_timeout_minutes'], policy_version=services.F('policy_version')+1)
            request.session.modified = True
        request.target_id=request.user.pk; request.target_type='member'
        AuditEvent.objects.create(actor=request.user, action='account.suggestion_skipped' if data.get('dismiss_password_suggestion') else 'account.preferences', target_id=request.user.pk, request_id=request.request_id, operation_id=data['operation_id'], metadata={'idle_timeout_minutes':request.user.idle_timeout_minutes})
        return {'user': user_json(request.user)}
    return JsonResponse(save(request, payload(request)))


@endpoint(['POST'])
def activity_view(request):
    if payload(request):
        raise APIError('unknown_field', '活动请求不接受身份或时间字段')
    check_session(request, touch=True)
    from datetime import timedelta
    policy = request.session_policy
    return JsonResponse({'expires_at': (policy.last_active_at+timedelta(minutes=policy.idle_timeout_minutes)).isoformat(), 'idle_timeout_minutes': policy.idle_timeout_minutes})
