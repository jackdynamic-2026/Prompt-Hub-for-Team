import unicodedata
from django.db import transaction
from django.db.models import F
from django.utils import timezone
from .errors import APIError
from .models import AuditEvent, Entry, SharedNote, Tag, Revision, Favorite, RepositoryCache, Recommendation
from .operations import mutation
from .sources import validate_source, repository_key
from .github_policy import usable_cache

def normalize(text):
    return unicodedata.normalize('NFKC', text).casefold()

def text_field(value, name, limit, required=False):
    if not isinstance(value, str) or len(value) > limit or (required and not value.strip()):
        raise APIError('invalid_field', f'{name}格式或长度无效', field=name)
    try:
        value.encode('utf-8', errors='strict')
    except UnicodeError:
        raise APIError('invalid_unicode', f'{name}包含无效字符', field=name)
    return value

def body_fields(payload, creating=False):
    allowed = {'title', 'content', 'intro', 'tags', 'skill_source', 'operation_id', 'operation_epoch'} | ({'kind'} if creating else {'body_version', 'tag_version'})
    if set(payload) - allowed:
        raise APIError('unknown_field', '请求包含不允许修改的字段')
    kind = payload.get('kind') if creating else None
    if creating and kind not in ('PROMPT', 'SKILL'):
        raise APIError('invalid_kind', '内容类型无效')
    title = text_field(payload.get('title'), '名称', 120, True).strip()
    content = text_field(payload.get('content', ''), '正文', 50000)
    intro = text_field(payload.get('intro', ''), '介绍', 5000)
    tags = payload.get('tags', [])
    if not isinstance(tags, list) or len(tags) > 10:
        raise APIError('invalid_tags', '最多10个标签')
    clean = {}
    for raw in tags:
        tag = text_field(raw, '标签', 30, True).strip()
        if any(unicodedata.category(c).startswith('C') for c in tag):
            raise APIError('invalid_tag', '标签不能包含控制字符')
        clean.setdefault(normalize(tag), tag)
    return {'title': title, 'normalized_title': normalize(title), 'content': content, 'intro': intro, 'skill_source': validate_source(payload.get('skill_source'))}, clean

def serialize(entry):
    note = entry.note
    cache = RepositoryCache.objects.filter(key=(entry.skill_source['owner'] + '/' + entry.skill_source['repo']).lower()).first() if entry.skill_source else None
    snapshot = {'stars': cache.stars, 'fetched_at': cache.fetched_at.isoformat() if cache.fetched_at else None, 'state': cache.state} if cache else entry.github_snapshot
    if cache and cache.stars is None and isinstance(entry.github_snapshot, dict) and type(entry.github_snapshot.get('stars')) is int and entry.github_snapshot['stars'] >= 0:
        snapshot = {**entry.github_snapshot, 'state': 'stale'}
    return {'tag_version': entry.tag_version, 'source_recommendation_snapshot': entry.source_recommendation_snapshot, 'recommendation_count': (entry.recommendation_total if hasattr(entry, 'recommendation_total') else Recommendation.objects.filter(entry=entry, actor__is_active=True).count()), 'is_recommended': False, 'id': entry.pk, 'kind': entry.kind, 'title': entry.title, 'content': entry.content, 'intro': entry.intro, 'tags': [{'id': t.pk, 'name': t.name} for t in sorted(entry.tags.all(), key=lambda t: t.normalized_name)], 'owner': {'id': entry.owner_id, 'username': entry.owner.username, 'display_name': entry.owner.display_name}, 'body_version': entry.body_version, 'shared_note': note.text, 'note_version': note.note_version, 'note_updated_by': note.updated_by.display_name, 'note_updated_at': note.updated_at.isoformat(), 'created_at': entry.created_at.isoformat(), 'updated_at': entry.updated_at.isoformat(), 'skill_source': entry.skill_source, 'github_snapshot': snapshot, 'source_version': entry.source_version, 'origin': entry.origin, 'repository_verified': bool(cache and cache.state == 'verified' and usable_cache(cache)), 'skill_path_verified': False}

def get_entry(entry_id):
    try:
        return Entry.objects.select_related('owner', 'note__updated_by').get(pk=entry_id, deleted_at__isnull=True)
    except Entry.DoesNotExist:
        raise APIError('not_found', '条目不存在或已删除', 404)

def audit(request, action, entry, **metadata):
    request.target_id = entry.pk
    request.target_type = entry._meta.model_name
    AuditEvent.objects.create(actor=request.user, action=action, target_id=entry.pk, request_id=request.request_id, operation_id=getattr(request, 'operation_id', ''), metadata=metadata)

def history(request, entry, domain, snapshot, version):
    Revision.objects.create(entry=entry, domain=domain, version=version, snapshot=snapshot, actor=request.user)
    old = Revision.objects.filter(entry=entry, domain=domain).order_by('-version').values_list('pk', flat=True)[10:]
    Revision.objects.filter(pk__in=list(old)).delete()

def validate_kind(kind, fields):
    if kind == 'PROMPT' and (not fields['content'].strip() or fields['intro']):
        raise APIError('invalid_prompt', '提示词需要正文且介绍应为空')
    if kind == 'SKILL' and fields['content']:
        raise APIError('invalid_skill', 'Skill不保存代码或正文')
    if kind == 'PROMPT' and fields.get('skill_source') is not None:
        raise APIError('invalid_prompt', '提示词不接受Skill来源')

def set_tags(entry, tags):
    values = [Tag.objects.get_or_create(normalized_name=key, defaults={'name': value})[0] for key, value in tags.items()]
    entry.tags.set(values)

@mutation('entry.create')
def create_entry(request, payload):
    fields, tags = body_fields(payload, True)
    kind = payload['kind']
    validate_kind(kind, fields)
    if Entry.objects.count() >= 10000:
        raise APIError('capacity_exceeded', '条目总量已达上限', 413)
    entry = Entry.objects.create(kind=kind, owner=request.user, **fields)
    SharedNote.objects.create(entry=entry, text='', updated_by=request.user)
    set_tags(entry, tags)
    audit(request, 'entry.created', entry)
    return serialize(get_entry(entry.pk))

@mutation('entry.update')
def update_body(request, entry_id, payload, *, force_version=False):
    entry = get_entry(entry_id)
    if entry.owner_id != request.user.pk and not request.user.is_superuser:
        raise APIError('forbidden', '仅分享人或管理员可修改内容', 403)
    fields, tags = body_fields(payload)
    if 'skill_source' not in payload:
        fields['skill_source'] = entry.skill_source
    if type(payload.get('body_version')) is not int or payload['body_version'] != entry.body_version:
        raise APIError('conflict', '内容已更新，请重新核对', 409, current=serialize(entry))
    validate_kind(entry.kind, fields)
    before = {'title': entry.title, 'content': entry.content, 'intro': entry.intro, 'tags': list(entry.tags.values_list('name', flat=True)), 'skill_source': entry.skill_source}
    additions = {k: v for k, v in tags.items() if k not in set(entry.tags.values_list('normalized_name', flat=True))}
    if additions:
        if type(payload.get('tag_version')) is not int or payload['tag_version'] != entry.tag_version:
            raise APIError('tag_conflict', '标签已变化，请刷新并使用添加标签操作', 409, current=serialize(entry))
        append_tags(entry, additions)
    if not force_version and all(getattr(entry, key) == value for key, value in fields.items()):
        return serialize(entry)
    now = timezone.now()
    source_changed = fields['skill_source'] != entry.skill_source
    repository_changed = repository_key(fields['skill_source']) != repository_key(entry.skill_source)
    if repository_changed:
        fields['github_snapshot'] = None
    changed = Entry.objects.filter(pk=entry.pk, body_version=payload['body_version'], deleted_at__isnull=True).update(**fields, body_version=F('body_version') + 1, source_version=F('source_version') + (1 if fields['skill_source'] != entry.skill_source else 0), updated_at=now)
    if not changed:
        raise APIError('conflict', '内容已更新，请重新核对', 409)
    history(request, entry, 'body', before, entry.body_version)
    audit(request, 'entry.updated', entry, before_version=entry.body_version, after_version=entry.body_version + 1)
    if source_changed:
        from .observability import event
        change_kind = 'added' if not entry.skill_source else 'removed' if not fields['skill_source'] else 'repository' if repository_changed else 'locator'
        event(request, 'entry.source_changed', 'completed', source_change_kind=change_kind,
              source_version=entry.source_version + 1, repository_key=repository_key(fields['skill_source']), snapshot_cleared=repository_changed)
    return serialize(get_entry(entry.pk))

@mutation('note.update')
def update_note(request, entry_id, payload, *, force_version=False):
    if set(payload) - {'text', 'note_version', 'operation_id', 'operation_epoch'}:
        raise APIError('unknown_field', '备注接口不接受其他字段')
    value = text_field(payload.get('text'), '备注', 10000)
    entry = get_entry(entry_id)
    version = payload.get('note_version')
    if type(version) is not int or version != entry.note.note_version:
        raise APIError('conflict', '备注已更新，请重新核对', 409, current=serialize(entry))
    if not force_version and value == entry.note.text:
        return serialize(entry)
    now = timezone.now()
    changed = SharedNote.objects.filter(entry=entry, note_version=version, entry__deleted_at__isnull=True).update(text=value, note_version=F('note_version') + 1, updated_by=request.user, updated_at=now)
    if not changed:
        raise APIError('conflict', '备注已更新，请重新核对', 409)
    Entry.objects.filter(pk=entry.pk).update(updated_at=now)
    history(request, entry, 'note', entry.note.text, version)
    audit(request, 'note.updated', entry, before_version=version, after_version=version + 1)
    return serialize(get_entry(entry.pk))

def revisions(entry_id):
    get_entry(entry_id)
    rows = list(Revision.objects.filter(entry_id=entry_id).order_by('-version').values('id', 'domain', 'version', 'snapshot', 'created_at', 'actor_id'))
    return {'notes': [r for r in rows if r['domain'] == 'note'], 'bodies': [r for r in rows if r['domain'] == 'body']}

@mutation('revision.restore')
def restore(request, entry_id, payload):
    if set(payload) - {'domain', 'revision_id', 'version', 'operation_id', 'operation_epoch'}:
        raise APIError('unknown_field', '未知恢复字段')
    entry = get_entry(entry_id)
    domain = payload.get('domain')
    if domain not in ('body', 'note'):
        raise APIError('invalid_domain', '版本类型无效')
    if not request.user.is_superuser and (domain == 'note' or entry.owner_id != request.user.pk):
        raise APIError('forbidden', '无权恢复该版本', 403)
    revision = Revision.objects.filter(pk=payload.get('revision_id'), entry=entry, domain=domain).first()
    if not revision:
        raise APIError('revision_missing', '历史快照已不可用', 404)
    # Execute the same domain transition inside the enclosing transaction, without a second receipt.
    common = {'operation_id': payload['operation_id'], 'operation_epoch': payload['operation_epoch']}
    if domain == 'note':
        value = update_note.__wrapped__(request, entry_id, {**common, 'text': revision.snapshot, 'note_version': payload.get('version')}, force_version=True)
    else:
        value = update_body.__wrapped__(request, entry_id, {**common, **{k: v for k, v in revision.snapshot.items() if k != 'tags'}, 'body_version': payload.get('version')}, force_version=True)
    audit(request, 'revision.restored', entry, revision_id=revision.pk, domain=domain)
    return value

@mutation('entry.delete')
def delete_entry(request, entry_id, payload):
    if set(payload) - {'body_version', 'note_version', 'operation_id', 'operation_epoch'}:
        raise APIError('unknown_field', '未知删除字段')
    entry = get_entry(entry_id)
    if entry.owner_id != request.user.pk and not request.user.is_superuser:
        raise APIError('forbidden', '无权删除', 403)
    if type(payload.get('body_version')) is not int or type(payload.get('note_version')) is not int or payload['body_version'] != entry.body_version or payload['note_version'] != entry.note.note_version:
        raise APIError('conflict', '内容或备注已变化，请重新核对删除', 409, current=serialize(entry))
    Entry.objects.filter(pk=entry.pk, body_version=entry.body_version, deleted_at__isnull=True).update(deleted_at=timezone.now(), body_version=F('body_version') + 1, updated_at=timezone.now())
    SharedNote.objects.filter(entry=entry).update(note_version=F('note_version') + 1)
    Favorite.objects.filter(entry=entry).delete()
    audit(request, 'entry.deleted', entry)
    return {'id': entry.pk, 'deleted': True}

@mutation('entry.undelete')
def undelete(request, entry_id, payload):
    from datetime import timedelta
    if not request.user.is_superuser:
        raise APIError('forbidden', '仅管理员可以恢复删除的条目', 403)
    entry = Entry.objects.filter(pk=entry_id, deleted_at__gte=timezone.now() - timedelta(days=30)).first()
    if not entry:
        raise APIError('not_found', '条目不存在或已超过恢复期限', 404)
    Entry.objects.filter(pk=entry.pk).update(deleted_at=None, body_version=F('body_version') + 1, updated_at=timezone.now())
    SharedNote.objects.filter(entry=entry).update(note_version=F('note_version') + 1)
    audit(request, 'entry.undeleted', entry)
    return serialize(get_entry(entry.pk))


def append_tags(entry, clean):
    current = set(entry.tags.values_list('normalized_name', flat=True))
    new = {k: v for k, v in clean.items() if k not in current}
    if len(current | set(new)) > 10:
        raise APIError('invalid_tags', '最多10个标签')
    if new:
        entry.tags.add(*[Tag.objects.get_or_create(normalized_name=k, defaults={'name': v})[0] for k, v in new.items()])
        Entry.objects.filter(pk=entry.pk).update(tag_version=F('tag_version') + 1, updated_at=timezone.now())
        entry.refresh_from_db()
    return bool(new)


@mutation('tags.update')
def update_tags(request, entry_id, payload):
    entry = get_entry(entry_id)
    if set(payload) - {'add', 'remove_ids', 'tag_version', 'operation_id', 'operation_epoch'} or ('add' in payload) == ('remove_ids' in payload):
        raise APIError('invalid_tags', '请明确选择追加或删除标签')
    before = entry.tag_version
    if 'add' in payload:
        raw = payload['add']
        if not isinstance(raw, list) or len(raw) > 2000:
            raise APIError('invalid_tags', '单次追加输入最多2000项；每条仍最多10个不同标签')
        tags = {}
        for name in raw:
            _, one = body_fields({'title': entry.title, 'tags': [name]})
            tags.update(one)
        changed = append_tags(entry, tags)
    else:
        if entry.owner_id != request.user.pk and not request.user.is_superuser:
            raise APIError('forbidden', '仅分享人或管理员可删除标签', 403)
        if type(payload.get('tag_version')) is not int or payload['tag_version'] != entry.tag_version:
            raise APIError('tag_conflict', '标签已更新，请重新读取并确认删除', 409, current=serialize(entry))
        ids = payload['remove_ids']
        if not isinstance(ids, list) or not ids or len(ids) > 10 or any(type(x) is not int or x < 1 for x in ids):
            raise APIError('invalid_tags', '删除目标必须是标签ID列表')
        present = set(entry.tags.values_list('pk', flat=True))
        if not set(ids) <= present:
            raise APIError('tag_conflict', '标签已变化，请重新核对', 409)
        entry.tags.remove(*ids)
        Entry.objects.filter(pk=entry.pk).update(tag_version=F('tag_version') + 1, updated_at=timezone.now())
        changed = True
    if changed:
        audit(request, 'tags.appended' if 'add' in payload else 'tags.removed', entry, before_version=before, after_version=before+1)
    else:
        from .observability import event
        event(request, 'tags.unchanged', 'unchanged', entry_id=entry.pk, tag_version=before)
    return {'entry': serialize(get_entry(entry.pk))}


@mutation('recommendation.set')
def set_recommendation(request, entry_id, payload):
    if set(payload) != {'recommended', 'operation_id', 'operation_epoch'} or type(payload['recommended']) is not bool:
        raise APIError('invalid_recommendation', '请明确设置本人推荐状态')
    entry = get_entry(entry_id)
    if payload['recommended']:
        _, changed = Recommendation.objects.get_or_create(actor=request.user, entry=entry)
    else:
        changed, _ = Recommendation.objects.filter(actor=request.user, entry=entry).delete()
    if changed:
        audit(request, 'recommendation.set', entry, recommended=payload['recommended'])
    return {'recommended': payload['recommended'], 'recommendation_count': Recommendation.objects.filter(entry=entry, actor__is_active=True).count()}
