import io
import os
from pathlib import Path
import sqlite3
import tempfile
from contextlib import closing
from django.core.management import call_command, CommandError
from django.test import TransactionTestCase
from hub.models import Member, Entry, SharedNote, OperationReceipt, ExternalLease, SessionPolicy, Recommendation
from django.contrib.sessions.models import Session
from django.utils import timezone


class BackupContractTests(TransactionTestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.folder = Path(self.temp.name)
        self.key = self.folder / 'key'; self.key.write_bytes(os.urandom(32))
        self.backup = self.folder / 'snapshot.phbk'
        actor = Member.objects.create_user(username='backup-member', password='Backup-Strong-2026!', display_name='备份验收')
        entry = Entry.objects.create(kind='PROMPT', title='备份条目', normalized_title='备份条目', content='正文', owner=actor)
        SharedNote.objects.create(entry=entry, text='独立备注', updated_by=actor)
        Session.objects.create(session_key='old-session', session_data='old', expire_date=timezone.now())
        OperationReceipt.objects.create(actor=actor, operation_id='old-op', digest='a'*64, result={}, expires_at=timezone.now())
        ExternalLease.objects.create(key='github', token='old', expires_at=timezone.now())
        SessionPolicy.objects.create(key_hash='a'*64,actor=actor,auth_version=1,last_active_at=timezone.now())
        Recommendation.objects.create(actor=actor,entry=entry)
        Entry.objects.filter(pk=entry.pk).update(tag_version=3,source_recommendation_snapshot={'count':2,'captured_at':'2026-10-18T00:00:00Z'})

    def make_backup(self):
        call_command('hub_backup', output=str(self.backup), key_file=str(self.key), stdout=io.StringIO())

    def test_encrypted_snapshot_restores_into_new_directory_and_revokes_ephemeral_state(self):
        self.make_backup()
        self.assertNotIn('独立备注'.encode(), self.backup.read_bytes())
        destination = self.folder / 'recovered'
        call_command('hub_restore', input=str(self.backup), key_file=str(self.key), destination=str(destination), stdout=io.StringIO())
        with closing(sqlite3.connect(destination / 'hub.sqlite3')) as db:
            self.assertEqual(db.execute('PRAGMA integrity_check').fetchone()[0], 'ok')
            self.assertEqual(db.execute('SELECT text FROM hub_sharednote').fetchone()[0], '独立备注')
            self.assertEqual(db.execute('SELECT auth_version FROM hub_member').fetchone()[0], 2)
            for table in ('django_session', 'hub_operationreceipt', 'hub_externallease', 'hub_sessionpolicy'):
                self.assertEqual(db.execute(f'SELECT COUNT(*) FROM {table}').fetchone()[0], 0)
            self.assertEqual(db.execute('SELECT COUNT(*) FROM hub_recommendation').fetchone()[0],1)
            self.assertEqual(db.execute('SELECT tag_version FROM hub_entry').fetchone()[0],3)
        self.assertGreaterEqual(len((destination / 'operation_epoch.txt').read_text()), 32)
        self.assertEqual(Entry.objects.get().content, '正文')
        self.assertEqual(Session.objects.count(), 1)
        with self.assertRaises(CommandError):
            call_command('hub_restore', input=str(self.backup), key_file=str(self.key), destination=str(destination), stdout=io.StringIO())

    def test_tampered_snapshot_never_publishes_a_restored_database(self):
        self.make_backup()
        data = bytearray(self.backup.read_bytes()); data[len(data)//2] ^= 1; self.backup.write_bytes(data)
        destination = self.folder / 'invalid'
        with self.assertRaises(CommandError):
            call_command('hub_restore', input=str(self.backup), key_file=str(self.key), destination=str(destination), stdout=io.StringIO())
        self.assertFalse((destination / 'hub.sqlite3').exists())
