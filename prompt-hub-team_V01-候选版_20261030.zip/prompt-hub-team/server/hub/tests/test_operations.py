import os
from pathlib import Path
import subprocess
import sys
from django.test import TestCase, SimpleTestCase, override_settings
from hub.models import Entry
from .test_tracer import APIClientMixin


class DiskGuardTests(APIClientMixin, TestCase):
    def test_maintenance_is_dry_run_by_default_and_preserves_expired_intent_tombstones(self):
        import io
        from datetime import timedelta
        from django.core.management import call_command
        from django.utils import timezone
        from hub.models import AuditEvent, Member, OperationReceipt
        actor = Member.objects.get(username='alice')
        event = AuditEvent.objects.create(actor=actor, action='old', request_id='old')
        AuditEvent.objects.filter(pk=event.pk).update(created_at=timezone.now() - timedelta(days=91))
        receipt = OperationReceipt.objects.create(actor=actor, operation_id='expired', digest='a'*64, result={'entry': 'old private body'}, expires_at=timezone.now() - timedelta(days=1))
        call_command('hub_maintenance', stdout=io.StringIO())
        self.assertTrue(AuditEvent.objects.filter(pk=event.pk).exists())
        call_command('hub_maintenance', apply=True, stdout=io.StringIO())
        self.assertFalse(AuditEvent.objects.filter(pk=event.pk).exists())
        receipt.refresh_from_db(); self.assertEqual(receipt.result, {})
        self.assertEqual(receipt.digest, 'a'*64)

    def test_health_endpoint_reports_only_service_status(self):
        response = self.client.get('/healthz/')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {'status': 'ok'})

    def test_administrator_cli_unlock_clears_only_the_named_account_limit(self):
        import io
        from django.core.management import call_command
        from hub.models import RateBucket
        from hub.rate_limits import private_key
        from django.utils import timezone
        for name in ('alice', 'bob'):
            RateBucket.objects.create(key=private_key('login-account', name), window_start=timezone.now(), count=5)
        call_command('hub_unlock', username='alice', stdout=io.StringIO())
        self.assertFalse(RateBucket.objects.filter(key=private_key('login-account', 'alice')).exists())
        self.assertTrue(RateBucket.objects.filter(key=private_key('login-account', 'bob')).exists())

    @override_settings(DISK_STOP_PERCENT=0)
    def test_disk_guard_rejects_writes_but_keeps_reads_available(self):
        client = self.session('alice')
        response = self.write(client, '/api/entries/', {'kind': 'PROMPT', 'title': '禁止写', 'content': '正文', 'intro': '', 'tags': [], 'operation_id': 'disk-stop', 'operation_epoch': 'local-development-epoch'})
        self.assertEqual(response.status_code, 503)
        self.assertEqual(response.json()['error'], 'disk_guard')
        self.assertEqual(Entry.objects.count(), 0)
        self.assertEqual(client.get('/api/entries/?kind=PROMPT').status_code, 200)


class DeploymentGuardTests(SimpleTestCase):
    def test_public_settings_without_required_secrets_refuse_to_start(self):
        env = {k: v for k, v in os.environ.items() if k not in ('PH_SECRET_KEY', 'PH_OPERATION_EPOCH', 'PH_LOCAL_HTTP')}
        env['PH_PRODUCTION'] = '1'; env['DJANGO_SETTINGS_MODULE'] = 'config.settings'
        result = subprocess.run([sys.executable, 'manage.py', 'check'], cwd=Path(__file__).resolve().parents[2], env=env, capture_output=True, timeout=15)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn(b'production_configuration_required', result.stderr)
