import json
from django.test import Client, TestCase
from hub.models import Member

class APIClientMixin:
    @classmethod
    def setUpTestData(cls):
        for name in ('alice', 'bob'):
            Member.objects.create_user(username=name, password='Tracer-Strong-2026!', display_name=name, must_change_password=False)

    def session(self, name):
        client = Client(enforce_csrf_checks=True)
        bootstrap = client.get('/api/session/')
        self.assertEqual(bootstrap.status_code, 200)
        token = client.cookies['csrftoken'].value
        response = client.post('/api/login/', json.dumps({'username': name, 'password': 'Tracer-Strong-2026!'}), content_type='application/json', HTTP_X_CSRFTOKEN=token)
        self.assertEqual(response.status_code, 200)
        return client

    def write(self, client, path, value, method='post'):
        return getattr(client, method)(path, json.dumps(value), content_type='application/json', HTTP_X_CSRFTOKEN=client.cookies['csrftoken'].value)

class SharedTracerTests(APIClientMixin, TestCase):
    def test_two_sessions_share_note_but_cannot_change_another_owners_body(self):
        alice, bob = self.session('alice'), self.session('bob')
        created = self.write(alice, '/api/entries/', {'kind': 'PROMPT', 'title': '需求澄清', 'content': '先澄清【目标】', 'intro': '', 'tags': ['需求'], 'operation_id': 'create-1', 'operation_epoch': 'local-development-epoch'})
        self.assertEqual(created.status_code, 201)
        entry = created.json()['entry']
        self.assertEqual(entry['owner']['username'], 'alice')
        read = bob.get(f"/api/entries/{entry['id']}/")
        self.assertEqual(read.status_code, 200)
        saved = self.write(bob, f"/api/entries/{entry['id']}/note/", {'text': '补充验收条件', 'note_version': 1, 'operation_id': 'note-1', 'operation_epoch': 'local-development-epoch'}, 'patch')
        self.assertEqual(saved.status_code, 200)
        denied = self.write(bob, f"/api/entries/{entry['id']}/", {'title': '恶意替换', 'content': '恶意替换', 'intro': '', 'tags': [], 'body_version': 1, 'operation_id': 'bad-body', 'operation_epoch': 'local-development-epoch'}, 'patch')
        self.assertEqual(denied.status_code, 403)
        self.assertTrue(denied.json()['request_id'])
        final = alice.get(f"/api/entries/{entry['id']}/").json()['entry']
        self.assertEqual(final['content'], '先澄清【目标】')
        self.assertEqual(final['owner']['username'], 'alice')
        self.assertEqual(final['shared_note'], '补充验收条件')
        self.assertEqual(final['note_version'], 2)
