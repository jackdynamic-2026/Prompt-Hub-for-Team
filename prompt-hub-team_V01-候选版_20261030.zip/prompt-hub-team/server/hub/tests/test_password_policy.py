from django.contrib.auth import authenticate
from django.core.exceptions import ValidationError
from django.contrib.auth.password_validation import validate_password
from django.test import TestCase
from hub.models import Member
from .test_tracer import APIClientMixin


class EightCharacterPasswordTests(APIClientMixin, TestCase):
    def setUp(self):
        admin = Member.objects.get(username='alice')
        admin.is_superuser = True
        admin.save()
        self.admin = self.session('alice')

    def test_eight_character_member_creation_and_seven_character_rejection(self):
        common = {'display_name': '测试成员', 'is_admin': False, 'operation_epoch': 'local-development-epoch'}
        rejected = self.write(self.admin, '/api/members/', {**common, 'username': 'short', 'temporary_password': 'N8v4Q2x', 'operation_id': 'short'})
        self.assertEqual(rejected.status_code, 422)
        self.assertFalse(Member.objects.filter(username='short').exists())
        accepted = self.write(self.admin, '/api/members/', {**common, 'username': 'eight', 'temporary_password': 'N8v4Q2x9', 'operation_id': 'eight'})
        self.assertEqual(accepted.status_code, 201)
        self.assertTrue(Member.objects.get(username='eight').check_password('N8v4Q2x9'))

    def test_first_change_accepts_eight_and_revokes_old_session(self):
        bob = self.session('bob')
        other = self.session('bob')
        Member.objects.filter(username='bob').update(must_change_password=True)
        result = self.write(bob, '/api/password/', {'old_password': 'Tracer-Strong-2026!', 'new_password': 'N8v4Q2x9', 'operation_id': 'change-eight', 'operation_epoch': 'local-development-epoch'})
        self.assertEqual(result.status_code, 200)
        self.assertFalse(result.json()['user']['must_change_password'])
        self.assertIsNotNone(authenticate(username='bob', password='N8v4Q2x9'))
        self.assertIsNone(authenticate(username='bob', password='Tracer-Strong-2026!'))
        self.assertEqual(other.get('/api/entries/?kind=PROMPT').status_code, 401)
        self.assertEqual(bob.get('/api/entries/?kind=PROMPT').status_code, 200)

    def test_admin_reset_uses_same_policy_and_suggests_optional_change(self):
        member = Member.objects.get(username='bob')
        result = self.write(self.admin, f'/api/members/{member.pk}/', {'temporary_password': 'N8v4Q2x9', 'operation_id': 'reset-eight', 'operation_epoch': 'local-development-epoch'}, 'patch')
        self.assertEqual(result.status_code, 200)
        member.refresh_from_db()
        self.assertFalse(member.must_change_password)
        self.assertTrue(member.password_change_suggested)
        self.assertTrue(member.check_password('N8v4Q2x9'))

    def test_default_validator_boundaries_and_common_passwords(self):
        with self.assertRaises(ValidationError):
            validate_password('N8v4Q2x')
        validate_password('N8v4Q2x9')
        validate_password('N8v4Q2x9Z')
        with self.assertRaises(ValidationError):
            validate_password('password')

    def test_wrong_current_password_does_not_modify_hash(self):
        bob = self.session('bob')
        result = self.write(bob, '/api/password/', {'old_password': 'wrong', 'new_password': 'N8v4Q2x9', 'operation_id': 'wrong-current', 'operation_epoch': 'local-development-epoch'})
        self.assertEqual(result.status_code, 401)
        self.assertTrue(Member.objects.get(username='bob').check_password('Tracer-Strong-2026!'))

    def test_account_limit_is_distinguishable_in_private_logs(self):
        import json
        from pathlib import Path
        from django.conf import settings
        from django.test import Client
        client = Client(enforce_csrf_checks=True)
        client.get('/api/session/')
        response = None
        for _ in range(6):
            response = self.write(client, '/api/login/', {'username': 'bob', 'password': 'incorrect'})
        self.assertEqual(response.status_code, 429)
        self.assertNotIn('rate_limit_scope', response.json())
        records = [json.loads(line) for line in (Path(settings.DATA_DIR) / 'runtime.jsonl').read_text(encoding='utf-8').splitlines()]
        rejected = [r for r in records if r.get('request_id') == response.json()['request_id'] and r.get('result') == 'rejected']
        self.assertEqual(len(rejected), 1)
        self.assertEqual(rejected[0].get('rate_limit_scope'), 'account')
