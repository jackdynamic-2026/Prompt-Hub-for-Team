"""Real parser, authenticated Django/SQLite and subprocess regression tests; no mocks."""
import json
import os
from pathlib import Path
import subprocess
import sys
from django.test import SimpleTestCase, TestCase
from hub.exchange import parse_legacy
from hub.models import Entry
from .test_tracer import APIClientMixin


class LegacyBudgetTests(SimpleTestCase):
    def test_real_parser_startup_control(self):
        self.run_parser("from hub.exchange import parse_legacy; assert parse_legacy('1、标题：\\n正文')[0]['content'] == '正文'")

    def run_parser(self, code):
        # Fixed BEFORE RED: five seconds including interpreter/Django startup.
        script = "import os; os.environ.setdefault('DJANGO_SETTINGS_MODULE','config.settings'); import django; django.setup(); " + code
        try:
            result = subprocess.run([sys.executable, '-c', script], cwd=Path(__file__).resolve().parents[2], env=os.environ.copy(), capture_output=True, text=True, timeout=5)
        except subprocess.TimeoutExpired:
            self.fail('Real legacy parser exceeded the predeclared 5-second subprocess budget')
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_missing_colon_after_long_whitespace_finishes_within_budget(self):
        self.run_parser("from hub.exchange import parse_legacy; from hub.errors import APIError; "
                        "\ntry: parse_legacy('1、' + ' ' * 65536 + 'x')"
                        "\nexcept APIError as e: assert e.code == 'legacy_boundaries'"
                        "\nelse: raise AssertionError('Missing required colon must not parse')")

    def test_compatibility_and_large_body_remain_valid(self):
        self.run_parser("from hub.exchange import parse_legacy; "
                        "assert parse_legacy('1.'+' '*65536+'标题\\n正文', True)[0]['title']=='标题'; "
                        "assert len(parse_legacy('1、标题：\\n'+'x'*50000)[0]['content'])==50000")

    def test_unicode_and_embedded_colon_contract(self):
        text = '\ufeff\r\n\r\n\u2003１２、\t阶段：说明: \r\n正文\r1.正文编号\r\n\r\n2、第二条：\r\n次行'
        parsed = parse_legacy(text)
        self.assertEqual([(v['title'], v['content']) for v in parsed], [('阶段：说明', '正文\n1.正文编号'), ('第二条', '次行')])
        self.assertEqual(parse_legacy('1. 标题：\n正文', True)[0]['title'], '标题')


class ImportDiagnosticsTests(APIClientMixin, TestCase):
    def setUp(self):
        self.client_a = self.session('alice')

    def preview(self, text, mode='legacy'):
        return self.write(self.client_a, '/api/exchange/preview/', {'text': text, 'mode': mode, 'operation_id': 'v11-import', 'operation_epoch': 'local-development-epoch'})

    def test_real_preview_commit_tracer_and_safe_rejection(self):
        text = '1、技术审查：\n请核对事实\n\n2、需求澄清：\n请提出问题'
        preview = self.preview(text)
        self.assertEqual(preview.status_code, 200)
        self.assertEqual(Entry.objects.count(), 0)
        payload = {'text': text, 'mode': 'legacy', 'preview_token': preview.json()['preview_token'], 'confirmed': True, 'operation_id': 'v11-import', 'operation_epoch': 'local-development-epoch'}
        response = self.write(self.client_a, '/api/exchange/commit/', payload)
        self.assertEqual(response.status_code, 201)
        self.assertEqual(list(Entry.objects.order_by('pk').values_list('title', 'content')), [('技术审查', '请核对事实'), ('需求澄清', '请提出问题')])
        rejected = self.preview('1、' + 'x'*121 + '：\n正文')
        self.assertEqual(rejected.status_code, 422)
        self.assertEqual(rejected.json()['line'], 1)
        self.assertEqual(rejected.json()['entry_index'], 1)
        self.assertEqual(Entry.objects.count(), 2)

    def test_preview_logs_safe_context_without_text(self):
        secret_text = '绝不应进入日志的正文-v11'
        response = self.preview('1、标题：\n' + secret_text)
        self.assertEqual(response.status_code, 200)
        from django.conf import settings
        records = [json.loads(line) for line in (settings.DATA_DIR / 'runtime.jsonl').read_text(encoding='utf-8').splitlines()]
        matching = [r for r in records if r['request_id'] == response.headers['X-Request-ID'] and r['event'] == 'import.parse']
        self.assertEqual([r['result'] for r in matching], ['started', 'completed'])
        record = matching[-1]
        self.assertEqual(record['mode'], 'legacy')
        self.assertEqual(record['result'], 'completed')
        self.assertEqual(record['entry_count'], 1)
        self.assertNotIn(secret_text, json.dumps(records, ensure_ascii=False))
