import json
import tempfile
from pathlib import Path
from django.test import Client, TestCase, override_settings
from hub.models import Member
from .test_tracer import APIClientMixin

class SecurityContractTests(APIClientMixin, TestCase):
    def test_real_log_path_failure_keeps_committed_data_and_emits_stderr_fallback(self):
        from hub.models import Entry
        with tempfile.TemporaryDirectory() as folder:
            blocked = Path(folder) / 'not-a-directory'; blocked.write_text('owned test input', encoding='utf-8')
            with override_settings(DATA_DIR=blocked):
                client = self.session('alice')
                response = self.write(client, '/api/entries/', {'kind': 'PROMPT', 'title': '日志故障验收', 'content': '正文', 'intro': '', 'tags': [], 'operation_id': 'log-io-failure', 'operation_epoch': 'local-development-epoch'})
            self.assertEqual(response.status_code, 201)
            self.assertEqual(Entry.objects.get(pk=response.json()['entry']['id']).content, '正文')
            self.assertEqual(blocked.read_text(encoding='utf-8'), 'owned test input')
            self.assertTrue(response.headers['X-Request-ID'])

    def test_real_log_rotation_respects_age_and_budget(self):
        import os
        import time
        with tempfile.TemporaryDirectory() as folder, override_settings(DATA_DIR=Path(folder)):
            root = Path(folder)
            expired = root / 'runtime-expired.jsonl'; expired.write_text('expired\n', encoding='utf-8')
            old = time.time() - 16 * 86400; os.utime(expired, (old, old))
            (root / 'runtime.jsonl').write_bytes(b' ' * (5 * 1024 * 1024 + 1))
            client = self.session('alice')
            response = client.get('/api/entries/?kind=PROMPT')
            self.assertEqual(response.status_code, 200)
            self.assertFalse(expired.exists())
            self.assertLessEqual(sum(p.stat().st_size for p in root.glob('runtime*.jsonl')), 100 * 1024 * 1024)
            self.assertIn(response.headers['X-Request-ID'], (root / 'runtime.jsonl').read_text(encoding='utf-8'))

    def test_csrf_failure_has_safe_error_and_correlation_id(self):
        client = self.session('alice')
        response = client.post('/api/entries/', '{}', content_type='application/json')
        self.assertEqual(response.status_code, 403)
        self.assertEqual(response.headers.get('Content-Type'), 'application/json')
        self.assertTrue(response.json()['request_id'])
        self.assertEqual(response.json()['error'], 'csrf_rejected')

    def test_first_login_can_skip_password_change_and_replaces_old_session(self):
        member = Member.objects.get(username='alice'); member.must_change_password = True; member.save()
        client = self.session('alice')
        self.assertEqual(client.get('/api/entries/?kind=PROMPT').status_code, 200)
        self.assertTrue(client.get('/api/session/').json()['user']['password_change_suggested'])
        bad = self.write(client, '/api/password/', {'old_password': 'Tracer-Strong-2026!', 'new_password': 'short', 'operation_id': 'pw-bad', 'operation_epoch': 'local-development-epoch'})
        self.assertEqual(bad.status_code, 422)
        changed = self.write(client, '/api/password/', {'old_password': 'Tracer-Strong-2026!', 'new_password': 'Stronger-Password-2026!', 'operation_id': 'pw-good', 'operation_epoch': 'local-development-epoch'})
        self.assertEqual(changed.status_code, 200)
        self.assertFalse(changed.json()['user']['must_change_password'])
        self.assertEqual(client.get('/api/entries/?kind=PROMPT').status_code, 200)
        member.refresh_from_db(); self.assertTrue(member.check_password('Stronger-Password-2026!')); self.assertEqual(member.auth_version, 2)

    def test_login_rate_limit_uses_database_and_generic_message(self):
        client = Client(enforce_csrf_checks=True); client.get('/api/session/')
        for index in range(5):
            response = self.write(client, '/api/login/', {'username': 'alice', 'password': 'WrongPassword-2026!'})
            self.assertIn(response.status_code, (401, 429))
        blocked = self.write(client, '/api/login/', {'username': 'alice', 'password': 'Tracer-Strong-2026!'})
        self.assertEqual(blocked.status_code, 429)
        other = Client(enforce_csrf_checks=True); other.get('/api/session/')
        self.assertEqual(self.write(other, '/api/login/', {'username': 'alice', 'password': 'Tracer-Strong-2026!'}).status_code, 429)

    def test_unknown_api_path_is_json_404_not_spa(self):
        response = Client().get('/api/not-a-real-route/')
        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.headers['Content-Type'], 'application/json')
        self.assertTrue(response.json()['request_id'])

    def test_sensitive_text_is_not_in_runtime_log_and_rejected_write_has_terminal_record(self):
        with tempfile.TemporaryDirectory() as folder, override_settings(DATA_DIR=Path(folder)):
            client = self.session('alice')
            created = self.write(client, '/api/entries/', {'kind': 'PROMPT', 'title': '日志测试', 'content': 'TOP_SECRET_BODY_2026', 'intro': '', 'tags': [], 'operation_id': 'log-create', 'operation_epoch': 'local-development-epoch'})
            entry_id = created.json()['entry']['id']
            response = self.write(client, f'/api/entries/{entry_id}/note/', {'text': 'TOP_SECRET_NOTE_2026', 'owner_id': 123, 'note_version': 1, 'operation_id': 'log-denied', 'operation_epoch': 'local-development-epoch'}, 'patch')
            self.assertEqual(response.status_code, 422)
            text = (Path(folder) / 'runtime.jsonl').read_text(encoding='utf-8')
            self.assertNotIn('TOP_SECRET', text); self.assertNotIn('Tracer-Strong', text)
            terminal = [json.loads(line) for line in text.splitlines() if json.loads(line)['request_id'] == response.json()['request_id']]
            self.assertTrue(any(event['result'] == 'rejected' for event in terminal))
            completed = next(json.loads(line) for line in text.splitlines() if json.loads(line)['request_id'] == created.headers['X-Request-ID'] and json.loads(line)['result'] == 'completed')
            self.assertEqual(completed['target_id'], entry_id)
            self.assertEqual(completed['target_type'], 'entry')
            self.assertEqual(completed['operation_id'], 'log-create')

    def test_receipt_status_is_private_to_its_actor(self):
        a, b = self.session('alice'), self.session('bob')
        self.write(a, '/api/entries/', {'kind': 'PROMPT', 'title': '回执', 'content': '正文', 'intro': '', 'tags': [], 'operation_id': 'status-test', 'operation_epoch': 'local-development-epoch'})
        self.assertEqual(a.get('/api/operations/status-test/').status_code, 200)
        self.assertEqual(b.get('/api/operations/status-test/').status_code, 404)
