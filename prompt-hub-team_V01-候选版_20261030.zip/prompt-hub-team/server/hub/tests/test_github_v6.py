import uuid
from datetime import timedelta
from django.test import TestCase
from django.utils import timezone
from hub.models import Entry, ExternalLease, RateBucket, RepositoryCache
from hub.errors import APIError
from .test_tracer import APIClientMixin


class GitHubRefreshTests(APIClientMixin, TestCase):
    def setUp(self):
        self.client = self.session('alice')
        source = {'provider': 'github', 'owner': 'django', 'repo': 'django', 'skill_path': '', 'source_url': 'https://github.com/django/django'}
        response = self.write(self.client, '/api/entries/', {'kind': 'SKILL', 'title': '刷新测试', 'intro': '人工介绍', 'tags': [], 'skill_source': source, 'operation_id': str(uuid.uuid4()), 'operation_epoch': 'local-development-epoch'})
        self.assertEqual(response.status_code, 201)
        self.entry = response.json()['entry']

    def refresh(self):
        return self.write(self.client, f"/api/entries/{self.entry['id']}/github/", {})

    def test_recent_cache_reports_cached_without_advancing_check_time(self):
        checked = timezone.now() - timedelta(seconds=10)
        RepositoryCache.objects.create(key='django/django', stars=0, state='verified', fetched_at=checked)
        result = self.refresh()
        self.assertEqual(result.status_code, 200)
        self.assertEqual(result.json()['refresh']['outcome'], 'cached')
        self.assertEqual(result.json()['entry']['github_snapshot']['stars'], 0)
        self.assertEqual(RepositoryCache.objects.get().fetched_at, checked)
        self.assertFalse(RateBucket.objects.filter(key='github-global').exists())

    def test_manual_refresh_does_not_hide_behind_day_old_cache(self):
        RepositoryCache.objects.create(key='django/django', stars=123, state='verified', fetched_at=timezone.now()-timedelta(minutes=2))
        RateBucket.objects.create(key='github-global', count=30, window_start=timezone.now())
        result = self.refresh()
        self.assertEqual(result.status_code, 429)
        self.assertEqual(result.json()['error'], 'github_budget')
        self.assertIn('Retry-After', result)
        self.assertEqual(RepositoryCache.objects.get().stars, 123)

    def test_pair_budget_does_not_spend_global_if_user_is_exhausted(self):
        from hub.github import reserve_attempt
        RateBucket.objects.create(key='github-global', count=2, window_start=timezone.now())
        RateBucket.objects.create(key='github-user-1', count=5, window_start=timezone.now())
        with self.assertRaises(APIError):
            reserve_attempt(1)
        self.assertEqual(RateBucket.objects.get(key='github-global').count, 2)

    def test_old_success_and_failure_cannot_write_after_lease_takeover(self):
        from hub.github import commit_cache
        ExternalLease.objects.create(key='github', token='new-owner', expires_at=timezone.now()+timedelta(seconds=20))
        RepositoryCache.objects.create(key='django/django', stars=999, state='verified')
        for values in ({'stars': 1, 'state': 'verified'}, {'state': 'failed'}):
            with self.assertRaises(APIError):
                commit_cache('old-owner', 'django/django', values)
        self.assertEqual(RepositoryCache.objects.get().stars, 999)
        self.assertEqual(RepositoryCache.objects.get().state, 'verified')

    def test_provider_cooldown_prevents_other_repository_fetch(self):
        RateBucket.objects.create(key='github-provider-cooldown', window_start=timezone.now(), blocked_until=timezone.now()+timedelta(seconds=120))
        result = self.refresh()
        self.assertEqual(result.status_code, 429)
        self.assertEqual(result.json()['scope'], 'provider')
        self.assertGreater(result.json()['retry_after_seconds'], 100)
        self.assertFalse(ExternalLease.objects.exists())

    def test_retry_state_machine_has_one_retry_and_one_shared_deadline(self):
        from hub.github_policy import retry_allowed
        self.assertTrue(retry_allowed({'retryable': True}, 1, 1))
        self.assertFalse(retry_allowed({'retryable': True}, 2, 15))
        self.assertFalse(retry_allowed({'retryable': True}, 1, 0.69))
        self.assertFalse(retry_allowed({'retryable': False}, 1, 15))

    def test_successful_pair_reservations_and_expired_window(self):
        from hub.github import reserve_attempt
        old = timezone.now()-timedelta(hours=2)
        RateBucket.objects.create(key='github-global', count=30, window_start=old)
        RateBucket.objects.create(key='github-user-1', count=5, window_start=old)
        reserve_attempt(1); reserve_attempt(1)
        self.assertEqual(RateBucket.objects.get(key='github-global').count, 2)
        self.assertEqual(RateBucket.objects.get(key='github-user-1').count, 2)

    def test_expired_lease_cannot_mark_old_cache_failed(self):
        from hub.github import commit_cache
        ExternalLease.objects.create(key='github', token='expired', expires_at=timezone.now()-timedelta(seconds=1))
        RepositoryCache.objects.create(key='django/django', stars=0, state='verified')
        with self.assertRaises(APIError):
            commit_cache('expired', 'django/django', {'state': 'failed'})
        self.assertEqual(RepositoryCache.objects.get().state, 'verified')

    def test_classification_and_rate_headers_do_not_retry_permission_or_shorten_wait(self):
        from email.utils import format_datetime
        from hub.github_policy import classify_http, cooldown_until
        self.assertFalse(classify_http(403, {}, b'{}')['retryable'])
        self.assertNotIn('provider', classify_http(403, {}, b'{}'))
        self.assertTrue(classify_http(503, {}, b'{}')['retryable'])
        self.assertFalse(classify_http(301, {}, b'{}')['retryable'])
        self.assertTrue(classify_http(429, {}, b'{}')['provider'])
        self.assertTrue(classify_http(403, {'x-ratelimit-remaining':'0'}, b'{}')['provider'])
        now = timezone.now().replace(microsecond=0)
        later = now+timedelta(days=2)
        self.assertGreaterEqual(cooldown_until({'retry-after':'172800'}, now), later)
        self.assertGreaterEqual(cooldown_until({'retry-after':format_datetime(later)}, now), later)
        self.assertGreaterEqual(cooldown_until({'retry-after':'bad'}, now), now+timedelta(seconds=60))

    def test_source_changed_result_cannot_be_attached_to_entry(self):
        from types import SimpleNamespace
        from hub.github import reply
        item = Entry.objects.get(pk=self.entry['id'])
        source = item.skill_source
        item.source_version += 1; item.save(update_fields=['source_version'])
        cache = RepositoryCache.objects.create(key='django/django', stars=123)
        with self.assertRaises(APIError) as error:
            reply(SimpleNamespace(request_id='source-change'), item.pk, source, 1, cache, 'updated', 1)
        self.assertEqual(error.exception.code, 'github_source_changed')

    def test_future_cache_timestamp_is_not_fresh(self):
        from hub.github_policy import usable_cache
        cache = RepositoryCache.objects.create(key='django/django', stars=0, fetched_at=timezone.now()+timedelta(hours=1), state='verified')
        self.assertFalse(usable_cache(cache))
        result = self.client.get(f"/api/entries/{self.entry['id']}/")
        self.assertFalse(result.json()['entry']['repository_verified'])

    def test_unreaped_worker_guard_blocks_new_network_work(self):
        RateBucket.objects.create(key='github-worker-unreaped', count=1234, window_start=timezone.now())
        result = self.refresh()
        self.assertEqual(result.status_code, 503)
        self.assertEqual(result.json()['error'], 'github_worker_unreaped')
        self.assertTrue(result.json()['manual_intervention_required'])
        self.assertFalse(ExternalLease.objects.exists())

    def test_unreaped_guard_is_not_expired_by_routine_maintenance(self):
        from hub.github import commit_cache
        ExternalLease.objects.create(key='github', token='owner', expires_at=timezone.now()+timedelta(seconds=20))
        commit_cache('owner', 'django/django', {'state':'failed'}, unreaped_pid=1234)
        self.assertGreater(RateBucket.objects.get(key='github-worker-unreaped').blocked_until, timezone.now()+timedelta(days=2))

    def test_out_of_range_upstream_reset_is_not_shortened_to_one_minute(self):
        from hub.github_policy import cooldown_until
        until = cooldown_until({'x-ratelimit-remaining':'0', 'x-ratelimit-reset':str(10**30)}, timezone.now())
        self.assertEqual(until.year, 9999)

    def test_first_failed_refresh_does_not_hide_imported_unverified_stars(self):
        Entry.objects.filter(pk=self.entry['id']).update(github_snapshot={'stars':321,'fetched_at':'2026-10-01T00:00:00Z','state':'unverified'})
        RepositoryCache.objects.create(key='django/django', state='failed', retry_after=timezone.now()+timedelta(seconds=60))
        result = self.client.get(f"/api/entries/{self.entry['id']}/")
        self.assertEqual(result.json()['entry']['github_snapshot']['stars'], 321)
        self.assertFalse(result.json()['entry']['repository_verified'])
        failed = self.refresh()
        self.assertEqual(failed.status_code, 429)
        self.assertTrue(failed.json()['cached_data_available'])

    def test_exception_policy_uses_safe_classification_not_raw_messages(self):
        import requests
        from hub.github_transport import classify_exception
        timeout = classify_exception(requests.exceptions.ReadTimeout('sensitive-test-text'))
        self.assertEqual(timeout['error'], 'github_timeout')
        self.assertTrue(timeout['retryable'])
        self.assertNotIn('sensitive-test-text', str(timeout))
        self.assertFalse(classify_exception(requests.exceptions.SSLError('certificate'))['retryable'])
        denied = classify_exception(PermissionError(13, 'denied'))
        self.assertEqual(denied['error'], 'github_network_forbidden')
        self.assertFalse(denied['retryable'])
