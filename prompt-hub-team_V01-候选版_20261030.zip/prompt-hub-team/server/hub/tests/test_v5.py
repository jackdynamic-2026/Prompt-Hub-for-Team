"""V5 contracts: real Django, real SQLite and real file content; no replacements."""
import json
from datetime import timedelta
from django.test import TestCase
from django.utils import timezone
from hub.models import Member, Entry, AuditEvent, OperationReceipt
from .test_tracer import APIClientMixin

SAMPLE = '''Skill TXT v1
导出时间：2026-10-18T23:30:00+08:00

=== Skill ===
名称：审查Skill
GitHub：https://github.com/mattpocock/skills
仓库路径：skills/review
标签：
| AI, Coding
| 开发
分享人：source-admin
GitHub Star：12；采集时间：2026-10-17T20:00:00Z
团队推荐：3
介绍：
| 第一行
| === Skill ===
| 名称：只是文字
|
| | 原有竖线
|
备注：
|   备注两边空格  
=== 结束 ===
'''

class V5Contracts(APIClientMixin, TestCase):
    def setUp(self):
        self.a, self.b = self.session('alice'), self.session('bob')
        self.n = 0

    def op(self, **data):
        self.n += 1
        return {**data, 'operation_id': f'v5-{self.n}', 'operation_epoch': 'local-development-epoch'}

    def create(self, kind='PROMPT'):
        r = self.write(self.a, '/api/entries/', self.op(kind=kind, title='测试', content='正文' if kind == 'PROMPT' else '', intro='介绍' if kind == 'SKILL' else '', tags=['旧标签']))
        self.assertEqual(r.status_code, 201, r.content)
        return r.json()['entry']

    def test_tracer_import_simple_confirm_replay_and_current_read(self):
        data = self.op(text=SAMPLE, mode='skill_simple_v1')
        p = self.write(self.b, '/api/exchange/preview/', data)
        self.assertEqual(p.status_code, 200, p.content)
        self.assertEqual(p.json()['entries'][0]['tags'], ['AI, Coding', '开发'])
        confirmed = {**data, 'preview_token': p.json()['preview_token'], 'confirmed': True}
        r = self.write(self.b, '/api/exchange/commit/', confirmed)
        self.assertEqual(r.status_code, 201, r.content)
        self.assertEqual(self.write(self.b, '/api/exchange/commit/', confirmed).json(), r.json())
        self.assertEqual(Entry.objects.count(), 1)
        value = self.b.get(f"/api/entries/{r.json()['ids'][0]}/").json()['entry']
        self.assertEqual(value['kind'], 'SKILL')
        self.assertEqual(value['owner']['username'], 'bob')
        self.assertEqual(value['origin']['source_author'], 'source-admin')
        self.assertEqual(value['intro'], '第一行\n=== Skill ===\n名称：只是文字\n\n| 原有竖线\n')
        self.assertEqual(value['shared_note'], '  备注两边空格  ')
        self.assertEqual(value['recommendation_count'], 0)
        self.assertEqual(value['source_recommendation_snapshot']['count'], 3)
        exported = self.b.get('/api/exchange/export/?scope=kind&kind=SKILL&format=skill_simple_v1')
        self.assertEqual(exported.status_code, 200, exported.content)
        roundtrip = self.write(self.a, '/api/exchange/preview/', self.op(text=exported.content.decode(), mode='skill_simple_v1'))
        self.assertEqual(roundtrip.status_code, 200, roundtrip.content)
        self.assertEqual(roundtrip.json()['entries'][0]['intro'], value['intro'])

    def test_collaborative_tags_old_body_explicit_delete_and_history(self):
        e = self.create(); path = f"/api/entries/{e['id']}/"
        added = self.write(self.b, path+'tags/', self.op(add=['新标签']))
        self.assertEqual(added.status_code, 200, added.content)
        v = added.json()['entry']; self.assertEqual(v['tag_version'], 2)
        self.assertEqual(v['body_version'], 1)
        updated = self.write(self.a, path, self.op(title='修改', content='新正文', intro='', body_version=1), 'patch')
        self.assertEqual(updated.status_code, 200, updated.content)
        self.assertEqual({t['name'] for t in updated.json()['entry']['tags']}, {'旧标签','新标签'})
        ids = [t['id'] for t in v['tags'] if t['name']=='旧标签']
        self.assertEqual(self.write(self.b, path+'tags/', self.op(remove_ids=ids, tag_version=2)).status_code, 403)
        self.assertEqual(self.write(self.a, path+'tags/', self.op(remove_ids=ids, tag_version=2)).status_code, 200)
        stale = self.write(self.a, path, self.op(title='修改', content='新正文', intro='', body_version=2, tags=['旧标签']), 'patch')
        self.assertEqual(stale.status_code, 409)
        revision = self.a.get(path+'history/').json()['bodies'][0]
        restored = self.write(self.a, path+'restore/', self.op(domain='body', revision_id=revision['id'], version=2))
        self.assertEqual(restored.status_code, 200, restored.content)
        self.assertEqual([t['name'] for t in restored.json()['entry']['tags']], ['新标签'])

    def test_recommendation_is_independent_private_favorite_and_active_accounts(self):
        e = self.create(); path = f"/api/entries/{e['id']}/"
        self.write(self.a, path+'favorite/', {'favorite': True})
        self.assertEqual(self.b.get(path).json()['entry']['recommendation_count'], 0)
        payload = self.op(recommended=True)
        for _ in range(2):
            r = self.write(self.b, path+'recommendation/', payload)
            self.assertEqual(r.status_code, 200, r.content)
            self.assertEqual(r.json()['recommendation_count'], 1)
        self.assertFalse(self.b.get(path).json()['entry']['is_favorite'])
        self.assertEqual(self.write(self.a,path+'recommendation/',self.op(recommended=True)).json()['recommendation_count'],2)
        self.assertEqual(self.write(self.a,path+'recommendation/',self.op(recommended=False)).json()['recommendation_count'],1)
        current=self.a.get(path).json()['entry']
        self.assertEqual((current['body_version'],current['note_version'],current['tag_version']),(1,1,1))
        self.assertEqual(current['updated_at'],e['updated_at'])
        Member.objects.filter(username='bob').update(is_active=False)
        self.assertEqual(self.a.get(path).json()['entry']['recommendation_count'], 0)
        Member.objects.filter(username='bob').update(is_active=True)
        self.assertEqual(self.a.get(path).json()['entry']['recommendation_count'], 1)
        self.assertEqual(self.write(self.a, path+'recommendation/', self.op(recommended='true')).status_code, 422)

    def test_optional_password_and_personal_idle_preference(self):
        Member.objects.filter(username='bob').update(must_change_password=True)
        bob = self.session('bob')
        self.assertEqual(bob.get('/api/entries/?kind=PROMPT').status_code, 200)
        user = bob.get('/api/session/').json()['user']
        self.assertFalse(user['must_change_password'])
        self.assertTrue(user['password_change_suggested'])
        self.assertEqual(user['idle_timeout_minutes'], 60)
        r = self.write(bob, '/api/preferences/', self.op(idle_timeout_minutes=120, dismiss_password_suggestion=True))
        self.assertEqual(r.status_code, 200, r.content)
        self.assertFalse(r.json()['user']['password_change_suggested'])
        self.assertEqual(r.json()['user']['idle_timeout_minutes'], 120)
        for bad in (True, 0, -1, 10081, 1.2):
            self.assertEqual(self.write(bob, '/api/preferences/', self.op(idle_timeout_minutes=bad)).status_code, 422)

    def test_simple_invalid_entire_file_is_rejected_without_writes(self):
        variants = [SAMPLE.replace('名称：审查Skill','名称：审查Skill\n名称：重复'), SAMPLE.replace('=== 结束 ===',''), SAMPLE.replace('| 第一行','无前缀'), SAMPLE.replace('团队推荐：3','团队推荐：true'), SAMPLE.replace('20:00:00Z','20:00:00'), SAMPLE.replace('skills/review','../secret'), SAMPLE.replace('Skill TXT v1','Skill TXT v2')]
        for text in variants:
            r = self.write(self.a, '/api/exchange/preview/', self.op(text=text, mode='skill_simple_v1'))
            self.assertEqual(r.status_code, 422, r.content)
            self.assertTrue(r.json()['request_id'])
        self.assertEqual(Entry.objects.count(), 0)

    def test_v3_export_snapshot_and_import_does_not_vote(self):
        e=self.create(); path=f"/api/entries/{e['id']}/"
        self.write(self.b,path+'recommendation/',self.op(recommended=True))
        r=self.a.get('/api/exchange/export/?kind=PROMPT&scope=kind&format=full_v3')
        self.assertEqual(r.status_code,200,r.content)
        doc=json.loads(r.content); self.assertEqual(doc['schema_version'],3)
        self.assertEqual(doc['entries'][0]['recommendation_snapshot']['count'],1)
        d=self.op(text=r.content.decode(),mode='full'); p=self.write(self.a,'/api/exchange/preview/',d)
        self.assertEqual(p.status_code,200,p.content)
        result=self.write(self.a,'/api/exchange/commit/',{**d,'preview_token':p.json()['preview_token'],'confirmed':True})
        self.assertEqual(result.status_code,201,result.content)
        copied=self.a.get(f"/api/entries/{result.json()['ids'][0]}/").json()['entry']
        self.assertEqual(copied['recommendation_count'],0)
        self.assertEqual(copied['source_recommendation_snapshot']['count'],1)


    def test_simple_source_errors_have_the_actual_field_line(self):
        text=SAMPLE.replace('https://github.com/mattpocock/skills','https://example.com/a/b')
        result=self.write(self.a,'/api/exchange/preview/',self.op(text=text,mode='skill_simple_v1'))
        self.assertEqual(result.status_code,422)
        self.assertEqual(result.json()['field'],'GitHub')
        self.assertEqual(result.json()['line'],6)

    def test_tag_duplicate_batch_and_count_limit_are_based_on_current_union(self):
        e=self.create();path=f"/api/entries/{e['id']}/tags/"
        repeated=self.write(self.b,path,self.op(add=['旧标签']*11))
        self.assertEqual(repeated.status_code,200,repeated.content)
        self.assertEqual(repeated.json()['entry']['tag_version'],1)
        overflow=self.write(self.b,path,self.op(add=[f'new{i}' for i in range(10)]))
        self.assertEqual(overflow.status_code,422)
        self.assertEqual(Entry.objects.get(pk=e['id']).tags.count(),1)

    def test_recommendation_delete_restore_and_multitag_counts(self):
        e=self.create();path=f"/api/entries/{e['id']}/"
        self.write(self.b,path+'recommendation/',self.op(recommended=True))
        self.write(self.b,path+'tags/',self.op(add=['第二标签']))
        ids=','.join(str(t.pk) for t in Entry.objects.get(pk=e['id']).tags.all())
        listed=self.a.get('/api/entries/?kind=PROMPT&tag_ids='+ids).json()
        self.assertEqual(listed['total'],1);self.assertEqual(listed['entries'][0]['recommendation_count'],1)
        self.assertEqual(self.write(self.a,path,self.op(body_version=1,note_version=1),'delete').status_code,200)
        self.assertEqual(self.write(self.b,path+'recommendation/',self.op(recommended=False)).status_code,404)
        Member.objects.filter(username='alice').update(is_superuser=True)
        restored=self.write(self.a,path+'undelete/',self.op())
        self.assertEqual(restored.status_code,200)
        self.assertEqual(restored.json()['entry']['recommendation_count'],1)


    def test_created_member_has_optional_suggestion_and_legacy_gate_stays_false(self):
        Member.objects.filter(username='alice').update(is_superuser=True)
        result=self.write(self.a,'/api/members/',self.op(username='new-v5',display_name='新成员',temporary_password='New-Password-2026!',is_admin=False))
        self.assertEqual(result.status_code,201,result.content)
        self.assertFalse(result.json()['member']['must_change_password'])
        self.assertTrue(result.json()['member']['password_change_suggested'])
        member=Member.objects.get(username='new-v5')
        self.assertFalse(member.must_change_password)
        self.assertTrue(member.password_change_suggested)

    def test_v3_invalid_snapshot_fields_are_rejected_without_import(self):
        import copy
        self.create()
        document=json.loads(self.a.get('/api/exchange/export/?kind=PROMPT&scope=kind&format=full_v3').content)
        variants=[]
        for value in (-1,True,'3',1.5,2147483648,None):
            bad=copy.deepcopy(document);bad['entries'][0]['recommendation_snapshot']['count']=value;variants.append(bad)
        for value in ('2026-10-18T00:00:00','not-a-date'):
            bad=copy.deepcopy(document);bad['entries'][0]['recommendation_snapshot']['captured_at']=value;variants.append(bad)
        bad=copy.deepcopy(document);bad['entries'][0]['recommendation_snapshot']['actor_ids']=[1];variants.append(bad)
        for bad in variants:
            response=self.write(self.a,'/api/exchange/preview/',self.op(text=json.dumps(bad),mode='full'))
            self.assertEqual(response.status_code,422,response.content)
        self.assertEqual(Entry.objects.count(),1)

    def test_context_mismatch_is_rejected_and_has_a_specific_private_log_reason(self):
        from django.conf import settings
        response=self.b.get('/api/entries/?kind=PROMPT',HTTP_X_SESSION_CONTEXT=self.a.session['session_context'])
        self.assertEqual(response.status_code,401)
        records=[json.loads(line) for line in (Path(settings.DATA_DIR)/'runtime.jsonl').read_text(encoding='utf-8').splitlines()]
        matching=[r for r in records if r.get('request_id')==response.json()['request_id'] and r.get('event')=='session.context_changed']
        self.assertEqual(len(matching),1)
        self.assertEqual(matching[0]['reason_code'],'context_mismatch')

class SessionPolicyContracts(APIClientMixin, TestCase):
    def test_default_idle_activity_and_expired_session_never_revives(self):
        from django.apps import apps
        client=self.session('alice')
        response=self.write(client,'/api/activity/',{})
        self.assertEqual(response.status_code,200,response.content)
        Policy=apps.get_model('hub','SessionPolicy')
        policy=Policy.objects.get(actor__username='alice')
        self.assertEqual(policy.idle_timeout_minutes,60)
        past=timezone.now()-timedelta(minutes=59)
        Policy.objects.filter(pk=policy.pk).update(last_active_at=past)
        self.assertEqual(client.get('/api/entries/?kind=PROMPT').status_code,200)
        policy.refresh_from_db(); self.assertEqual(policy.last_active_at,past)
        self.assertEqual(self.write(client,'/api/activity/',{}).status_code,200)
        policy.refresh_from_db(); self.assertGreater(policy.last_active_at,past)
        Policy.objects.filter(pk=policy.pk).update(last_active_at=timezone.now()-timedelta(minutes=60,seconds=1))
        self.assertEqual(self.write(client,'/api/activity/',{}).status_code,401)
        self.assertEqual(client.get('/api/entries/?kind=PROMPT').status_code,401)

    def test_preference_updates_current_not_other_session_and_removes_absolute_cap(self):
        from django.apps import apps
        a,b=self.session('alice'),self.session('alice')
        response=self.write(a,'/api/preferences/',{'idle_timeout_minutes':120,'operation_id':'prefs-a','operation_epoch':'local-development-epoch'})
        self.assertEqual(response.status_code,200)
        Policy=apps.get_model('hub','SessionPolicy')
        windows=list(Policy.objects.filter(actor__username='alice').order_by('created_at').values_list('idle_timeout_minutes',flat=True))
        self.assertEqual(windows,[120,60])
        session=a.session; session['started_at']=(timezone.now()-timedelta(days=2)).timestamp(); session.save()
        self.assertEqual(a.get('/api/entries/?kind=PROMPT').status_code,200)
        self.assertEqual(int(a.cookies['sessionid']['max-age']),7200)

    def test_shortening_idle_after_long_activity_gap_is_a_valid_user_operation(self):
        from hub.models import SessionPolicy
        client=self.session('alice')
        SessionPolicy.objects.filter(actor__username='alice').update(last_active_at=timezone.now()-timedelta(minutes=59))
        response=self.write(client,'/api/preferences/',{'idle_timeout_minutes':5,'operation_id':'shorten-policy','operation_epoch':'local-development-epoch'})
        self.assertEqual(response.status_code,200,response.content)
        self.assertEqual(client.get('/api/entries/?kind=PROMPT').status_code,200)
        policy=SessionPolicy.objects.get(actor__username='alice')
        self.assertGreater(policy.last_active_at,timezone.now()-timedelta(seconds=10))

    def test_logout_invalidates_lease_and_stale_save_cannot_restore_it(self):
        client=self.session('alice'); old=client.session; self.assertTrue(old['_auth_user_id'])
        self.assertEqual(self.write(client,'/api/logout/',{}).status_code,200)
        from django.contrib.sessions.backends.base import UpdateError
        with self.assertRaises(UpdateError): old.save()
        self.assertEqual(client.get('/api/entries/?kind=PROMPT').status_code,401)


from django.test import TransactionTestCase, override_settings
from django.db import connection, close_old_connections
from django.conf import settings
from pathlib import Path
import tempfile
from concurrent.futures import ThreadPoolExecutor
from threading import Barrier

class V5TransactionEvidence(APIClientMixin, TransactionTestCase):
    def setUp(self):
        for name in ('alice','bob'):
            Member.objects.create_user(username=name,password='Tracer-Strong-2026!',display_name=name,must_change_password=False)

    def test_committed_log_and_real_receipt_insert_failure_rollback(self):
        with tempfile.TemporaryDirectory() as folder, override_settings(DATA_DIR=Path(folder)):
            a=self.session('alice')
            base={'kind':'PROMPT','title':'日志','content':'PRIVATE_V5_TEXT','intro':'','tags':[],'operation_epoch':'local-development-epoch'}
            ok=self.write(a,'/api/entries/',{**base,'operation_id':'committed-log'})
            self.assertEqual(ok.status_code,201)
            records=[json.loads(x) for x in (Path(folder)/'runtime.jsonl').read_text(encoding='utf-8').splitlines()]
            self.assertTrue(any(x['event']=='entry.create' and x['result']=='committed' for x in records))
            with connection.cursor() as cursor:
                cursor.execute("CREATE TRIGGER v5_reject_receipt BEFORE INSERT ON hub_operationreceipt BEGIN SELECT RAISE(ABORT, 'test-receipt-io'); END")
            try:
                failed=self.write(a,'/api/entries/',{**base,'operation_id':'rolled-back-log'})
                self.assertEqual(failed.status_code,500)
            finally:
                with connection.cursor() as cursor:cursor.execute('DROP TRIGGER v5_reject_receipt')
            self.assertEqual(Entry.objects.count(),1)
            self.assertFalse(OperationReceipt.objects.filter(operation_id='rolled-back-log').exists())
            text=(Path(folder)/'runtime.jsonl').read_text(encoding='utf-8')
            self.assertNotIn('PRIVATE_V5_TEXT',text)
            records=[json.loads(x) for x in text.splitlines() if json.loads(x).get('operation_id')=='rolled-back-log']
            self.assertFalse(any(x['result']=='committed' for x in records))
            self.assertTrue(any(x['result'] in ('failed','unknown','rolled_back') for x in records))
            self.assertTrue(any(x['stage']=='entry.create.receipt' for x in records), 'Failure must identify receipt persistence stage')

    def test_committed_business_with_real_session_write_failure_is_queryable(self):
        from hub.models import SessionPolicy
        client=self.session('alice')
        SessionPolicy.objects.filter(actor__username='alice').update(last_active_at=timezone.now()-timedelta(seconds=40))
        value={'kind':'PROMPT','title':'会话保存故障','content':'业务已提交','intro':'','tags':[],'operation_id':'session-io-failed','operation_epoch':'local-development-epoch'}
        with connection.cursor() as cursor:
            cursor.execute("CREATE TRIGGER v5_session_io BEFORE UPDATE ON django_session BEGIN SELECT RAISE(ABORT, 'session-write-blocked'); END")
        try:
            result=self.write(client,'/api/entries/',value)
            self.assertEqual(result.status_code,503,result.content)
            self.assertEqual(result.json()['error'],'session_persist_unconfirmed')
            self.assertTrue(result.json()['request_id'])
            status=client.get('/api/operations/session-io-failed/')
            self.assertEqual(status.status_code,200,status.content)
            self.assertEqual(Entry.objects.count(),1)
        finally:
            with connection.cursor() as cursor:cursor.execute('DROP TRIGGER v5_session_io')
        retry=self.write(client,'/api/entries/',value)
        self.assertEqual(retry.status_code,201)
        self.assertEqual(Entry.objects.count(),1)

    def test_real_connections_append_at_limit_never_lose_tags_or_exceed_ten(self):
        a,b=self.session('alice'),self.session('bob')
        data={'kind':'PROMPT','title':'并发标签','content':'正文','intro':'','tags':[f'tag{i}' for i in range(9)],'operation_id':'create-limit','operation_epoch':'local-development-epoch'}
        e=self.write(a,'/api/entries/',data).json()['entry']; barrier=Barrier(2)
        def add(client,name):
            close_old_connections();barrier.wait(timeout=10)
            try:return self.write(client,f"/api/entries/{e['id']}/tags/",{'add':[name],'operation_id':name,'operation_epoch':'local-development-epoch'}).status_code
            finally:close_old_connections()
        with ThreadPoolExecutor(max_workers=2) as pool:
            fs=[pool.submit(add,a,'append-a'),pool.submit(add,b,'append-b')];statuses=[f.result(timeout=20) for f in fs]
        self.assertEqual(statuses.count(200),1,statuses)
        self.assertTrue(all(x in (200,422,503) for x in statuses),statuses)
        self.assertEqual(Entry.objects.get(pk=e['id']).tags.count(),10)
