import threading
import requests
from django.test import TransactionTestCase
from hub.models import Member

class WindowsWSGIContracts(TransactionTestCase):
    def test_real_waitress_serves_login_and_team_on_loopback(self):
        from config.windows_server import build_server, close_server
        Member.objects.create_user(username='windows-user',display_name='Windows',password='Native-Strong-2026!')
        server=build_server(port=0)
        thread=threading.Thread(target=server.run,daemon=True);thread.start()
        client=requests.Session()
        try:
            base=f'http://127.0.0.1:{server.effective_port}'
            health=client.get(base+'/healthz/',timeout=10)
            self.assertEqual(health.status_code,200)
            boot=client.get(base+'/api/session/',timeout=10)
            result=client.post(base+'/api/login/',json={'username':'windows-user','password':'Native-Strong-2026!'},headers={'X-CSRFToken':boot.json()['csrf_token']},timeout=10)
            self.assertEqual(result.status_code,200,result.text)
            self.assertEqual(client.get(base+'/api/entries/?kind=SKILL',timeout=10).status_code,200)
            self.assertEqual(client.get(base+'/team/',timeout=10).status_code,200)
        finally:
            client.close();close_server(server);thread.join(timeout=5)
            self.assertFalse(thread.is_alive())
