from django.test import TestCase
from hub.models import Member
from .test_tracer import APIClientMixin

class ManagementContractTests(APIClientMixin, TestCase):
    def setUp(self):
        admin = Member.objects.get(username='alice'); admin.is_superuser = True; admin.save()
        self.a, self.b = self.session('alice'), self.session('bob')
        self.intent = {'operation_id': 'manage-1', 'operation_epoch': 'local-development-epoch'}

    def test_only_admin_can_create_account_and_list_safe_member_fields(self):
        data = {'username': 'Carol', 'display_name': '陈晓', 'temporary_password': 'Temporary-Strong-2026!', 'is_admin': False, **self.intent}
        self.assertEqual(self.write(self.b, '/api/members/', data).status_code, 403)
        response = self.write(self.a, '/api/members/', data)
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.json()['member']['username'], 'carol')
        self.assertFalse(response.json()['member']['must_change_password'])
        self.assertTrue(response.json()['member']['password_change_suggested'])
        members = self.a.get('/api/members/')
        self.assertEqual(members.status_code, 200)
        for member in members.json()['members']:
            self.assertNotIn('password', member)
            self.assertNotIn('temporary_password', member)
        self.assertNotIn('Temporary-Strong-2026!', str(members.json()))

    def test_admin_cannot_disable_self_or_remove_last_administrator(self):
        actor = Member.objects.get(username='alice')
        self.assertEqual(self.write(self.a, f'/api/members/{actor.pk}/', {**self.intent, 'is_active': False}, 'patch').status_code, 422)
        self.assertEqual(self.write(self.a, f'/api/members/{actor.pk}/', {**self.intent, 'is_admin': False, 'operation_id': 'demote-self'}, 'patch').status_code, 422)
        actor.refresh_from_db(); self.assertTrue(actor.is_active); self.assertTrue(actor.is_superuser)

    def test_disabling_member_revokes_existing_session_without_reassigning_entries(self):
        entry = self.write(self.b, '/api/entries/', {'kind': 'PROMPT', 'title': '归属', 'content': '正文', 'intro': '', 'tags': [], **self.intent}).json()['entry']
        bob = Member.objects.get(username='bob')
        response = self.write(self.a, f'/api/members/{bob.pk}/', {**self.intent, 'is_active': False}, 'patch')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(self.b.get('/api/entries/?kind=PROMPT').status_code, 401)
        value = self.a.get(f"/api/entries/{entry['id']}/").json()['entry']
        self.assertEqual(value['owner']['username'], 'bob')

    def test_favorite_is_explicit_idempotent_and_private(self):
        entry = self.write(self.a, '/api/entries/', {'kind': 'PROMPT', 'title': '收藏', 'content': '正文', 'intro': '', 'tags': [], **self.intent}).json()['entry']
        for _ in range(2):
            response = self.write(self.b, f"/api/entries/{entry['id']}/favorite/", {'favorite': True})
            self.assertEqual(response.status_code, 200)
        self.assertEqual(self.b.get('/api/entries/?kind=PROMPT&favorite=1').json()['total'], 1)
        self.assertEqual(self.a.get('/api/entries/?kind=PROMPT&favorite=1').json()['total'], 0)

    def test_recycle_bin_is_admin_only_and_does_not_leak_deleted_entries(self):
        entry = self.write(self.a, '/api/entries/', {'kind': 'PROMPT', 'title': '删除后', 'content': '正文', 'intro': '', 'tags': [], **self.intent}).json()['entry']
        self.write(self.a, f"/api/entries/{entry['id']}/", {'body_version': 1, 'note_version': 1, 'operation_id': 'delete-1', 'operation_epoch': 'local-development-epoch'}, 'delete')
        self.assertEqual(self.b.get('/api/recycle/').status_code, 403)
        value = self.a.get('/api/recycle/')
        self.assertEqual(value.status_code, 200)
        self.assertEqual(value.json()['entries'][0]['id'], entry['id'])

    def test_favorite_flags_and_export_use_the_current_member(self):
        import json
        entry = self.write(self.a, '/api/entries/', {'kind': 'PROMPT', 'title': '我的收藏', 'content': '正文', 'intro': '', 'tags': [], **self.intent}).json()['entry']
        self.write(self.b, f"/api/entries/{entry['id']}/favorite/", {'favorite': True})
        self.assertTrue(self.b.get(f"/api/entries/{entry['id']}/").json()['entry']['is_favorite'])
        self.assertFalse(self.a.get('/api/entries/?kind=PROMPT').json()['entries'][0]['is_favorite'])
        self.assertEqual(self.a.get('/api/exchange/export/?kind=PROMPT&favorite=1').status_code, 422)
        data = self.b.get('/api/exchange/export/?kind=PROMPT&favorite=1')
        self.assertEqual(json.loads(data.content)['entry_count'], 1)
