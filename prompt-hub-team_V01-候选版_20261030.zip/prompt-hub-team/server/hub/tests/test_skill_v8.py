"""V8 real Django/SQLite and text contracts. No replaced components."""
import json
from django.conf import settings
from django.test import TestCase
from hub.models import Entry, RepositoryCache, AuditEvent
from hub.sources import validate_source
from hub.errors import APIError
from .test_tracer import APIClientMixin

URL = 'https://github.com/django/django/tree/main/skills/中文%20目录?tab=readme&x=1#usage'


class SkillV8Contracts(APIClientMixin, TestCase):
    def setUp(self):
        self.a, self.b = self.session('alice'), self.session('bob')
        self.n = 0

    def op(self, **value):
        self.n += 1
        return dict(value, operation_id=f'v8-{self.n}', operation_epoch='local-development-epoch')

    def source(self, url=URL, owner='django', repo='django'):
        return dict(provider='github', owner=owner, repo=repo, skill_path='', source_url=url)

    def create(self):
        response = self.write(self.a, '/api/entries/', self.op(kind='SKILL', title='完整链接', intro='人工介绍\n\n保留心得', content='', tags=['原标签'], skill_source=self.source()))
        self.assertEqual(response.status_code, 201, response.content)
        return response.json()['entry']

    def update(self, entry, source, intro=None, client=None):
        return self.write(client or self.a, f"/api/entries/{entry['id']}/", self.op(title=entry['title'], intro=entry['intro'] if intro is None else intro, content='', body_version=entry['body_version'], skill_source=source), 'patch')

    def test_full_link_survives_create_read_edit_and_history_restore(self):
        e = self.create()
        self.assertEqual(e['skill_source']['source_url'], URL)
        self.assertEqual(Entry.objects.get(pk=e['id']).skill_source['source_url'], URL)
        changed = self.update(e, self.source(URL+'-changed'))
        self.assertEqual(changed.status_code, 200, changed.content)
        history = self.a.get(f"/api/entries/{e['id']}/history/").json()['bodies'][0]
        restored = self.write(self.a, f"/api/entries/{e['id']}/restore/", self.op(domain='body', revision_id=history['id'], version=changed.json()['entry']['body_version']))
        self.assertEqual(restored.status_code, 200, restored.content)
        self.assertEqual(restored.json()['entry']['skill_source']['source_url'], URL)

    def test_both_export_formats_preview_commit_and_reexport_keep_url_and_intro(self):
        e = self.create()
        for mode in ('full', 'skill_simple_v1'):
            with self.subTest(mode=mode):
                exported = self.a.get('/api/exchange/export/', {'scope': 'kind', 'kind': 'SKILL', 'format': mode})
                self.assertEqual(exported.status_code, 200, exported.content)
                data = self.op(text=exported.content.decode(), mode=mode)
                preview = self.write(self.b, '/api/exchange/preview/', data)
                self.assertEqual(preview.status_code, 200, preview.content)
                self.assertEqual(preview.json()['entries'][0]['skill_source']['source_url'], URL)
                committed = self.write(self.b, '/api/exchange/commit/', dict(data, preview_token=preview.json()['preview_token'], confirmed=True))
                self.assertEqual(committed.status_code, 201, committed.content)
                copy = Entry.objects.get(pk=committed.json()['ids'][0])
                self.assertEqual(copy.skill_source['source_url'], URL)
                self.assertEqual(copy.intro, e['intro'])
                again = self.b.get('/api/exchange/export/', {'scope': 'selected', 'kind': 'SKILL', 'ids': str(copy.pk), 'format': mode})
                self.assertEqual(again.status_code, 200, again.content)
                second = self.write(self.a, '/api/exchange/preview/', self.op(text=again.content.decode(), mode=mode))
                self.assertEqual(second.status_code, 200, second.content)
                self.assertEqual(second.json()['entries'][0]['skill_source']['source_url'], URL)
                self.assertEqual(second.json()['entries'][0]['intro'], e['intro'])

    def test_same_repository_locator_change_keeps_snapshot_but_fences_old_source(self):
        e = self.create()
        Entry.objects.filter(pk=e['id']).update(github_snapshot={'stars': 321, 'state': 'unverified', 'fetched_at': None})
        response = self.update(e, self.source(URL+'-new'))
        self.assertEqual(response.status_code, 200, response.content)
        value = response.json()['entry']
        self.assertEqual(value['source_version'], e['source_version']+1)
        self.assertEqual(value['github_snapshot']['stars'], 321)
        self.assertFalse(value['repository_verified'])

    def test_repository_switch_and_removal_clear_snapshot_without_deleting_shared_cache(self):
        for source in (self.source('https://github.com/python/cpython/tree/main', 'python', 'cpython'), None):
            with self.subTest(source=source):
                e = self.create()
                Entry.objects.filter(pk=e['id']).update(github_snapshot={'stars': 321, 'state': 'unverified', 'fetched_at': None})
                RepositoryCache.objects.get_or_create(key='django/django', defaults={'state': 'failed'})
                response = self.update(e, source)
                self.assertEqual(response.status_code, 200, response.content)
                self.assertIsNone(Entry.objects.get(pk=e['id']).github_snapshot)
                self.assertTrue(RepositoryCache.objects.filter(key='django/django').exists())

    def test_source_validation_preserves_values_and_rejects_ambiguity(self):
        for url in (URL, 'https://github.com/django/django/', 'https://github.com/django/django/blob/main/a%20b.md', '  https://github.com/django/django#intro  '):
            self.assertEqual(validate_source(self.source(url))['source_url'], url.strip())
        bad = ['https://github.com/django//django/tree/main', 'https://github.com/django/django/../other',
               'https://github.com/django/django/\\evil', 'https://github.com/django/django\n/x',
               'https://github.com/django/django/%0a', 'https://github.com/%64jango/django',
               'https://github.com.evil.test/django/django', 'https://github.com:443/django/django',
               'https://user:pass@github.com/django/django', 'https://github.com/python/cpython']
        for url in bad:
            with self.subTest(url=url), self.assertRaises(APIError):
                validate_source(self.source(url))

    def test_full_preview_and_commit_agree_on_trimmed_locator(self):
        self.create()
        document = json.loads(self.a.get('/api/exchange/export/?scope=kind&kind=SKILL&format=full').content)
        document['entries'][0]['skill_source']['source_url'] = '  '+URL+'  '
        data = self.op(text=json.dumps(document), mode='full')
        preview = self.write(self.b, '/api/exchange/preview/', data)
        self.assertEqual(preview.status_code, 200, preview.content)
        self.assertEqual(preview.json()['entries'][0]['skill_source']['source_url'], URL)
        result = self.write(self.b, '/api/exchange/commit/', dict(data, preview_token=preview.json()['preview_token'], confirmed=True))
        self.assertEqual(result.status_code, 201, result.content)
        self.assertEqual(Entry.objects.get(pk=result.json()['ids'][0]).skill_source['source_url'], URL)

    def test_repository_case_change_keeps_snapshot_and_audits_source_change(self):
        e = self.create()
        Entry.objects.filter(pk=e['id']).update(github_snapshot={'stars': 321, 'state': 'unverified', 'fetched_at': None})
        result = self.update(e, self.source(URL.replace('/django/django/', '/Django/Django/'), 'Django', 'Django'))
        self.assertEqual(result.status_code, 200, result.content)
        self.assertEqual(result.json()['entry']['github_snapshot']['stars'], 321)
        self.assertEqual(result.json()['entry']['source_version'], e['source_version']+1)
        events = [json.loads(line) for line in (settings.DATA_DIR/'runtime.jsonl').read_text(encoding='utf-8').splitlines()]
        matching = [v for v in events if v['request_id'] == result['X-Request-ID'] and v['event'] == 'entry.source_changed']
        self.assertEqual(len(matching), 1)
        self.assertEqual(matching[0]['source_change_kind'], 'locator')
        self.assertFalse(matching[0]['snapshot_cleared'])
        self.assertNotIn('source_url', matching[0])
        self.assertNotIn('?tab=', json.dumps(matching[0]))

    def test_url_and_intro_length_boundaries_with_non_bmp(self):
        prefix = 'https://github.com/django/django#'
        valid = prefix + '😀'*(2048-len(prefix))
        self.assertEqual(validate_source(self.source(valid))['source_url'], valid)
        with self.assertRaises(APIError):
            validate_source(self.source(valid+'x'))
        e = self.create()
        ok = self.update(e, self.source(), intro='😀'*5000)
        self.assertEqual(ok.status_code, 200, ok.content)
        denied = self.update(ok.json()['entry'], self.source(), intro='😀'*5001)
        self.assertEqual(denied.status_code, 422)

    def test_appended_intro_conflict_permissions_tags_and_audit(self):
        e = self.create()
        appended = e['intro']+'\n\nGitHub 仓库介绍'
        denied = self.update(e, self.source(), intro=appended, client=self.b)
        self.assertEqual(denied.status_code, 403)
        changed = self.update(e, self.source(), intro=appended)
        self.assertEqual(changed.status_code, 200, changed.content)
        stale = self.update(e, self.source(), intro='覆盖', client=self.session('alice'))
        self.assertEqual(stale.status_code, 409)
        value = self.a.get(f"/api/entries/{e['id']}/").json()['entry']
        self.assertEqual(value['intro'], appended)
        self.assertEqual([t['name'] for t in value['tags']], ['原标签'])
        self.assertTrue(AuditEvent.objects.filter(action='entry.updated', target_id=e['id']).exists())
