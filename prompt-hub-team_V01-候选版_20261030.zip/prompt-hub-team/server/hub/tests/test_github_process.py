"""Real process lifecycle tests. Helpers execute real OS I/O, not API fixtures."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import unittest


class GitHubProcessTests(unittest.TestCase):
    server = str(Path(__file__).resolve().parents[2])
    def test_supervised_process_completes_without_stdin_shutdown_deadlock(self):
        from hub.github_transport import run_process
        code = "from hub.github_transport import watch_parent; watch_parent(); print('{}',flush=True)"
        self.assertEqual(run_process([sys.executable, '-c', code], time.monotonic()+5, cwd=self.server), {})

    def test_real_blocked_process_is_terminated_and_reaped(self):
        from hub.github_transport import run_process
        events = []
        result = run_process([sys.executable, '-c', 'import time; time.sleep(60)'], time.monotonic()+0.5,
                             lambda name, **fields: events.append((name, fields)))
        self.assertEqual(result['error'], 'github_time_budget')
        self.assertIn('worker_terminated', [name for name, _ in events])
        self.assertIn('worker_reaped', [name for name, _ in events])

    def test_parent_death_closes_real_lifeline(self):
        with tempfile.TemporaryDirectory() as folder:
            marker = Path(folder)/'child-done'
            code = "from hub.github_transport import watch_parent; import time; from pathlib import Path; watch_parent(); print('READY',flush=True); time.sleep(1); Path(__import__('sys').argv[1]).write_text('orphan-survived')"
            child = subprocess.Popen([sys.executable, '-c', code, str(marker)], cwd=self.server, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
            try:
                self.assertEqual(child.stdout.readline().strip(), b'READY')
                child.stdin.close()  # OS closes the same handle when parent exits.
                self.assertEqual(child.wait(timeout=3), 70)
                self.assertFalse(marker.exists())
            finally:
                if child.poll() is None:
                    child.kill(); child.wait()
                child.stdout.close()

    @unittest.skipUnless(os.name == 'nt', 'Windows process handles; Linux parent-death acceptance is separate')
    def test_abrupt_parent_termination_stops_actual_child_on_windows(self):
        import ctypes
        from ctypes import wintypes
        child_code = "from hub.github_transport import watch_parent; import time; watch_parent(); print('READY',flush=True); time.sleep(60)"
        parent_code = "import subprocess,sys,time; p=subprocess.Popen([sys.executable,'-c',sys.argv[1]],stdin=subprocess.PIPE,stdout=subprocess.PIPE); assert p.stdout.readline().strip()==b'READY'; print(p.pid,flush=True); time.sleep(60)"
        parent = subprocess.Popen([sys.executable, '-c', parent_code, child_code], cwd=self.server, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        kernel.OpenProcess.restype = wintypes.HANDLE
        kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
        kernel.CloseHandle.argtypes = [wintypes.HANDLE]
        kernel.TerminateProcess.argtypes = [wintypes.HANDLE, wintypes.UINT]
        handle = None
        try:
            pid = int(parent.stdout.readline().strip())
            handle = kernel.OpenProcess(0x100001, False, pid)
            self.assertTrue(handle)
            parent.kill(); parent.wait(timeout=3)
            self.assertEqual(kernel.WaitForSingleObject(handle, 3000), 0, 'worker survived actual parent process death')
        finally:
            if parent.poll() is None:
                parent.kill(); parent.wait()
            if handle:
                kernel.TerminateProcess(handle, 71); kernel.CloseHandle(handle)
            parent.stdout.close()
