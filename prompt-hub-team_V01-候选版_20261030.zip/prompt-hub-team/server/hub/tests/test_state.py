from django.test import TestCase
from django.utils import timezone
from datetime import timedelta
from hub.models import AuditEvent, Entry, Member
from .test_tracer import APIClientMixin

class StateContractTests(APIClientMixin, TestCase):
    def setUp(self):
        self.a = self.session('alice')
        self.b = self.session('bob')
        self.p = {'kind': 'PROMPT', 'title': '需求测试', 'content': '正文0', 'intro': '', 'tags': ['需求', 'Ｐｙｔｈｏｎ'], 'operation_id': 'new-1', 'operation_epoch': 'local-development-epoch'}
        self.entry = self.write(self.a, '/api/entries/', self.p).json()['entry']
        self.path = f"/api/entries/{self.entry['id']}/"

    def note(self, text='备注1', version=1, op='note-1', **fields):
        return self.write(self.b, self.path + 'note/', {'text': text, 'note_version': version, 'operation_id': op, 'operation_epoch': 'local-development-epoch', **fields}, 'patch')

    def test_same_operation_replay_creates_only_one_entry(self):
        replay = self.write(self.a, '/api/entries/', self.p)
        self.assertEqual(replay.status_code, 201)
        self.assertEqual(replay.json()['entry']['id'], self.entry['id'])
        self.assertEqual(Entry.objects.count(), 1)
        self.assertEqual(AuditEvent.objects.filter(action='entry.created').count(), 1)

    def test_operation_payload_or_epoch_mismatch_does_not_write(self):
        mismatch = self.write(self.a, '/api/entries/', {**self.p, 'title': '不同载荷'})
        self.assertEqual(mismatch.status_code, 409)
        stale = self.note(operation_epoch='obsolete')
        self.assertEqual(stale.status_code, 409)
        self.assertEqual(self.a.get(self.path).json()['entry']['shared_note'], '')

    def test_empty_intent_and_invalid_body_are_rejected(self):
        response = self.write(self.a, '/api/entries/', {**self.p, 'operation_id': ''})
        self.assertEqual(response.status_code, 422)
        response = self.write(self.a, self.path, {'title': '名称', 'content': '', 'intro': '', 'tags': [], 'body_version': 1, 'operation_id': 'empty-body', 'operation_epoch': 'local-development-epoch'}, 'patch')
        self.assertEqual(response.status_code, 422)

    def test_current_no_change_does_not_add_version_but_stale_same_text_conflicts(self):
        self.assertEqual(self.note().status_code, 200)
        before = self.a.get(self.path).json()['entry']
        response = self.note(version=2, op='note-no-change')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()['entry']['note_version'], 2)
        self.assertEqual(response.json()['entry']['updated_at'], before['updated_at'])
        self.assertEqual(self.note(version=1, op='note-stale').status_code, 409)

    def test_domains_and_field_whitelist_are_independent(self):
        self.assertEqual(self.note().status_code, 200)
        response = self.write(self.a, self.path, {'title': '新标题', 'content': '正文1', 'intro': '', 'tags': ['验收'], 'tag_version': 1, 'body_version': 1, 'operation_id': 'body-1', 'operation_epoch': 'local-development-epoch'}, 'patch')
        self.assertEqual(response.status_code, 200)
        value = response.json()['entry']
        self.assertEqual((value['body_version'], value['note_version'], value['shared_note']), (2, 2, '备注1'))
        self.assertEqual(self.note(version=2, op='bad-fields', owner_id=1).status_code, 422)
        self.assertEqual(self.a.get(self.path).json()['entry']['shared_note'], '备注1')

    def test_history_restore_is_new_version_and_preserves_body(self):
        admin = Member.objects.get(username='alice'); admin.is_superuser = True; admin.save()
        self.assertEqual(self.note('第一版备注', 1, 'n1').status_code, 200)
        self.assertEqual(self.note('第二版备注', 2, 'n2').status_code, 200)
        history = self.a.get(self.path + 'history/')
        self.assertEqual(history.status_code, 200)
        previous = next(r for r in history.json()['notes'] if r['snapshot'] == '第一版备注')
        response = self.write(self.a, self.path + 'restore/', {'domain': 'note', 'revision_id': previous['id'], 'version': 3, 'operation_id': 'restore-1', 'operation_epoch': 'local-development-epoch'})
        self.assertEqual(response.status_code, 200)
        value = response.json()['entry']
        self.assertEqual(value['note_version'], 4)
        self.assertEqual(value['shared_note'], '第一版备注')
        self.assertEqual(value['content'], '正文0')

    def test_restoring_identical_snapshot_still_creates_a_new_version(self):
        admin = Member.objects.get(username='alice'); admin.is_superuser = True; admin.save()
        self.note('A', 1, 'n1'); self.note('B', 2, 'n2'); self.note('A', 3, 'n3')
        previous = next(r for r in self.a.get(self.path + 'history/').json()['notes'] if r['snapshot'] == 'A')
        response = self.write(self.a, self.path + 'restore/', {'domain': 'note', 'revision_id': previous['id'], 'version': 4, 'operation_id': 'same-restore', 'operation_epoch': 'local-development-epoch'})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()['entry']['note_version'], 5)

    def test_delete_checks_both_versions_and_restore_invalidates_old_forms(self):
        self.assertEqual(self.note().status_code, 200)
        fields = {'body_version': 1, 'note_version': 1, 'operation_id': 'delete-old', 'operation_epoch': 'local-development-epoch'}
        self.assertEqual(self.write(self.a, self.path, fields, 'delete').status_code, 409)
        self.assertEqual(self.write(self.a, self.path, {**fields, 'note_version': 2, 'operation_id': 'delete-ok'}, 'delete').status_code, 200)
        self.assertEqual(self.b.get(self.path).status_code, 404)
        self.assertEqual(self.note(op='after-delete').status_code, 404)
        admin = Member.objects.get(username='alice'); admin.is_superuser = True; admin.save()
        restored = self.write(self.a, self.path + 'undelete/', {'operation_id': 'undelete', 'operation_epoch': 'local-development-epoch'})
        self.assertEqual(restored.status_code, 200)
        self.assertGreater(restored.json()['entry']['note_version'], 2)

    def test_boolean_versions_cannot_authorize_delete(self):
        response = self.write(self.a, self.path, {'body_version': True, 'note_version': True, 'operation_id': 'delete-booleans', 'operation_epoch': 'local-development-epoch'}, 'delete')
        self.assertEqual(response.status_code, 409)
        self.assertEqual(self.a.get(self.path).status_code, 200)

    def test_auth_version_revocation_is_checked_on_every_request(self):
        member = Member.objects.get(username='bob'); member.auth_version += 1; member.save()
        self.assertEqual(self.b.get(self.path).status_code, 401)
        self.assertEqual(self.note().status_code, 401)

    def test_idle_expiry_replaces_the_old_absolute_limit(self):
        state = self.b.session; state['started_at'] = (timezone.now() - timedelta(hours=13)).timestamp(); state.save()
        self.assertEqual(self.b.get(self.path).status_code, 200)
        client = self.session('bob')
        from hub.models import SessionPolicy
        SessionPolicy.objects.filter(actor__username='bob').update(last_active_at=timezone.now()-timedelta(minutes=61))
        self.assertEqual(client.get(self.path).status_code, 401)

    def test_filters_are_server_side_and_reject_unknown_tags(self):
        self.write(self.a, '/api/entries/', {**self.p, 'kind': 'SKILL', 'content': '', 'intro': '介绍', 'operation_id': 'skill-1'})
        tag = self.entry['tags'][0]['id']
        result = self.b.get('/api/entries/', {'kind': 'PROMPT', 'name': '需求', 'tag_ids': str(tag), 'page_size': '1'})
        self.assertEqual(result.status_code, 200)
        self.assertEqual(result.json()['total'], 1)
        self.assertEqual(len(result.json()['entries']), 1)
        self.assertEqual(result.json()['entries'][0]['kind'], 'PROMPT')
        self.assertEqual(self.b.get('/api/entries/', {'kind': 'PROMPT', 'tag_ids': '999999'}).status_code, 422)
        self.assertEqual(self.b.get('/api/entries/', {'kind': 'PROMPT', 'updated_from': '2026-10-18', 'updated_to': '2026-10-17'}).status_code, 422)
