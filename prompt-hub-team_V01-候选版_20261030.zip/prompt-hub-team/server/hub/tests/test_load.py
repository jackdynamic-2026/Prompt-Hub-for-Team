"""Explicit, isolated real-HTTP capacity gate. Never run on the OpenClaw host."""
from concurrent.futures import ThreadPoolExecutor
import json
import math
import os
from pathlib import Path
import time
from unittest import skipUnless
import requests
from django.test import LiveServerTestCase
from hub.models import Member


@skipUnless(os.environ.get('PH_LOAD_TEST') == '1', '10分钟真实负载门槛须显式开启')
class CapacityTests(LiveServerTestCase):
    def test_maximum_file_and_ten_real_sessions_for_ten_minutes(self):
        clients = []
        epoch = 'local-development-epoch'
        for i in range(10):
            name = f'load-{i}'
            Member.objects.create_user(username=name, display_name=name, password='Load-Strong-2026!', must_change_password=False)
            client = requests.Session(); client.get(self.live_server_url + '/api/session/', timeout=10)
            login = client.post(self.live_server_url + '/api/login/', json={'username': name, 'password': 'Load-Strong-2026!'}, headers={'X-CSRFToken': client.cookies['csrftoken']}, timeout=15)
            self.assertEqual(login.status_code, 200)
            clients.append(client); self.addCleanup(client.close)

        def post(client, path, payload, timeout=60):
            return client.post(self.live_server_url + path, json=payload, headers={'X-CSRFToken': client.cookies['csrftoken']}, timeout=timeout)

        origin = {'source_entry_id': 'source', 'source_author': 'input', 'source_created_at': '2026-10-17T00:00:00Z', 'source_updated_at': '2026-10-17T00:00:00Z', 'source_note_editor': 'input', 'source_note_updated_at': '2026-10-17T00:00:00Z'}
        entry = {'kind': 'PROMPT', 'title': '容量条目', 'content': '\\' * 4200, 'intro': '', 'shared_note': '边界备注', 'tags': ['容量'], 'skill_source': None, 'github_snapshot': None, 'origin': origin}
        document = {'format': 'prompt-hub-exchange', 'schema_version': 2, 'export_id': '11111111-1111-4111-8111-111111111111', 'source_system': 'capacity-input', 'exported_at': '2026-10-17T00:00:00Z', 'scope': {'kind': 'ALL', 'filters': {}}, 'entry_count': 2000, 'entries': [{**entry, 'title': f'容量条目{i}'} for i in range(2000)]}
        text = json.dumps(document, ensure_ascii=False)
        text += ' ' * (20 * 1024 * 1024 - len(text.encode()))
        self.assertEqual(len(text.encode()), 20 * 1024 * 1024)
        intent = {'text': text, 'mode': 'full', 'operation_id': 'capacity-import', 'operation_epoch': epoch}
        started = time.monotonic()
        preview = post(clients[0], '/api/exchange/preview/', intent)
        self.assertEqual(preview.status_code, 200, preview.content[:300])
        token = preview.json()['preview_token']; preview.close(); del preview
        committed = post(clients[0], '/api/exchange/commit/', {**intent, 'preview_token': token, 'confirmed': True})
        self.assertEqual(committed.status_code, 201, committed.content[:300])
        self.assertEqual(committed.json()['entry_count'], 2000)
        import_seconds = time.monotonic() - started
        self.assertEqual(post(clients[0], '/api/exchange/preview/', {**intent, 'text': text + ' '}).status_code, 413)
        del text, intent, document
        exported = clients[0].get(self.live_server_url + '/api/exchange/export/?scope=kind&kind=PROMPT', timeout=60)
        self.assertEqual(exported.status_code, 200, exported.content[:300])
        rows = exported.json(); self.assertEqual(rows['entry_count'], 2000)
        self.assertEqual(rows['entries'][0]['content'], '\\' * 4200)
        self.assertEqual(rows['entries'][0]['shared_note'], '边界备注')
        exported.close(); del rows, exported
        owned = []
        for i, client in enumerate(clients):
            created = post(client, '/api/entries/', {'kind': 'PROMPT', 'title': f'负载自有条目{i}', 'content': 'owner body', 'intro': '', 'tags': [], 'operation_id': f'load-create-{i}', 'operation_epoch': epoch})
            self.assertEqual(created.status_code, 201)
            owned.append(created.json()['entry'])

        def exercise(index):
            client = clients[index]; entry_id = owned[index]['id']; version = 1
            reads, writes, failures = [], [], []
            started = time.monotonic(); iterations = 0; last_text = ''
            while time.monotonic() - started < 600:
                tick = time.monotonic(); iterations += 1
                try:
                    response = client.get(self.live_server_url + '/api/entries/?kind=PROMPT&page_size=20', timeout=10)
                    if response.status_code != 200 or response.json()['total'] != 2010:
                        failures.append({'phase': 'read', 'status': response.status_code})
                    reads.append(time.monotonic() - tick)
                    if iterations % 20 == 0:
                        payload = {'text': f'client-{index}-round-{iterations}', 'note_version': version, 'operation_id': f'load-note-{index}-{iterations}', 'operation_epoch': epoch}
                        write_started = time.monotonic()
                        for attempt in range(3):
                            response = client.patch(self.live_server_url + f'/api/entries/{entry_id}/note/', json=payload, headers={'X-CSRFToken': client.cookies['csrftoken']}, timeout=10)
                            if response.status_code != 503:
                                break
                            time.sleep(0.1)
                        if response.status_code == 200:
                            version = response.json()['entry']['note_version']; last_text = payload['text']
                        else:
                            failures.append({'phase': 'write', 'status': response.status_code})
                        writes.append(time.monotonic() - write_started)
                except requests.RequestException as exc:
                    failures.append({'phase': 'transport', 'type': type(exc).__name__})
                time.sleep(max(0, 1 - (time.monotonic() - tick)))
            final = client.get(self.live_server_url + f'/api/entries/{entry_id}/', timeout=10)
            self.assertEqual(final.status_code, 200)
            self.assertEqual(final.json()['entry']['shared_note'], last_text)
            self.assertEqual(final.json()['entry']['note_version'], version)
            self.assertEqual(final.json()['entry']['content'], 'owner body')
            return {'reads': reads, 'writes': writes, 'failures': failures, 'duration': time.monotonic() - started}

        with ThreadPoolExecutor(max_workers=10) as pool:
            results = list(pool.map(exercise, range(10)))
        reads = sorted(v for result in results for v in result['reads'])
        writes = sorted(v for result in results for v in result['writes'])
        failures = [v for result in results for v in result['failures']]
        read_p95 = reads[math.ceil(len(reads) * 0.95) - 1]
        write_p95 = writes[math.ceil(len(writes) * 0.95) - 1]
        report = {'sessions': 10, 'seed_entries': 2000, 'file_bytes': 20 * 1024 * 1024, 'import_preview_commit_seconds': round(import_seconds, 3), 'minimum_duration_seconds': min(r['duration'] for r in results), 'read_count': len(reads), 'write_count': len(writes), 'read_p95_seconds': read_p95, 'write_p95_seconds': write_p95, 'failures': failures}
        if os.environ.get('PH_LOAD_REPORT'):
            Path(os.environ['PH_LOAD_REPORT']).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
        self.assertEqual(failures, [], report)
        self.assertGreater(len(writes), 0)
        self.assertLessEqual(read_p95, 1, report)
        self.assertLessEqual(write_p95, 2, report)
