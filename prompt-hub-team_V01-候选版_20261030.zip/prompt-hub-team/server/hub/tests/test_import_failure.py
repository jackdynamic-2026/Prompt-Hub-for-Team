import json
from django.db import connection
from django.test import TransactionTestCase
from hub.models import AuditEvent, Entry, Member, OperationReceipt
from .test_exchange import fixture
from .test_tracer import APIClientMixin


class ImportStorageFailureTests(APIClientMixin, TransactionTestCase):
    def test_real_sqlite_page_quota_failure_rolls_back_the_entire_import(self):
        Member.objects.create_user(username='alice', password='Tracer-Strong-2026!', display_name='alice', must_change_password=False)
        client = self.session('alice')
        sample = fixture(); item = sample['entries'][0]
        sample['entries'] = [{**item, 'title': f'真实空间约束{i}', 'content': 'x' * 50000} for i in range(2)]
        text = json.dumps(sample, ensure_ascii=False)
        payload = {'text': text, 'mode': 'full', 'operation_id': 'quota-import', 'operation_epoch': 'local-development-epoch'}
        preview = self.write(client, '/api/exchange/preview/', payload)
        self.assertEqual(preview.status_code, 200)
        with connection.cursor() as cursor:
            cursor.execute('VACUUM')
            cursor.execute('PRAGMA page_count'); pages = cursor.fetchone()[0]
            cursor.execute('PRAGMA max_page_count'); original = cursor.fetchone()[0]
            # An actual SQLite storage quota. No mocked exception or replaced transaction.
            cursor.execute(f'PRAGMA max_page_count={pages + 18}')
        try:
            response = self.write(client, '/api/exchange/commit/', {**payload, 'confirmed': True, 'preview_token': preview.json()['preview_token']})
        finally:
            with connection.cursor() as cursor:
                cursor.execute(f'PRAGMA max_page_count={original}')
        self.assertEqual(response.status_code, 503, response.content[:300])
        self.assertEqual(response.json()['error'], 'database_unavailable')
        self.assertEqual(Entry.objects.count(), 0)
        self.assertEqual(AuditEvent.objects.count(), 0)
        self.assertEqual(OperationReceipt.objects.count(), 0)
        self.assertEqual(Member.objects.filter(username='alice').count(), 1)
