import copy
import json
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase
from hub.models import Entry
from .test_tracer import APIClientMixin

def fixture():
    origin = {'source_entry_id': 'external-1', 'source_author': '伪造管理员', 'source_created_at': '2026-10-16T01:00:00Z', 'source_updated_at': '2026-10-17T01:00:00Z', 'source_note_editor': '外部编辑者', 'source_note_updated_at': '2026-10-17T01:00:00Z'}
    prompt = {'kind': 'PROMPT', 'title': '需求澄清', 'content': '  前置空白\r\n1、正文编号：\n"引号" \\ 反斜杠 😀\n', 'intro': '', 'shared_note': '  共同备注\n备注：不是分隔符\r\n', 'tags': ['需求', 'Python'], 'skill_source': None, 'github_snapshot': None, 'origin': origin}
    skill = {'kind': 'SKILL', 'title': 'Skill资料', 'content': '', 'intro': '这是资料，不是代码', 'shared_note': '', 'tags': ['工程'], 'skill_source': {'provider': 'github', 'owner': 'django', 'repo': 'django', 'skill_path': '', 'source_url': 'https://github.com/django/django'}, 'github_snapshot': {'stars': 0, 'fetched_at': '2026-10-17T01:00:00Z', 'state': 'unverified'}, 'origin': {**origin, 'source_entry_id': 'external-2'}}
    return {'format': 'prompt-hub-exchange', 'schema_version': 2, 'export_id': '11111111-1111-4111-8111-111111111111', 'source_system': 'external', 'exported_at': '2026-10-17T02:00:00Z', 'scope': {'kind': 'ALL', 'filters': {}}, 'entry_count': 2, 'entries': [prompt, skill]}

class ExchangeContractTests(APIClientMixin, TestCase):
    def test_preview_exposes_the_actual_existing_tag_mapping(self):
        created = self.write(self.client_a, '/api/entries/', {'kind': 'PROMPT', 'title': '已有标签', 'content': '正文', 'intro': '', 'tags': ['PYTHON'], 'operation_id': 'seed-tag', 'operation_epoch': 'local-development-epoch'}).json()['entry']
        preview = self.preview()
        self.assertEqual(preview.status_code, 200)
        mapping = next(row for row in preview.json()['tag_mapping'] if row['source'] == 'Python')
        self.assertEqual(mapping['target'], 'PYTHON')
        self.assertEqual(mapping['existing_tag_id'], created['tags'][0]['id'])

    def test_tag_mapping_changed_after_preview_requires_another_preview(self):
        preview = self.preview()
        self.write(self.client_a, '/api/entries/', {'kind': 'PROMPT', 'title': '后建标签', 'content': '正文', 'intro': '', 'tags': ['PyThOn'], 'operation_id': 'late-tag', 'operation_epoch': 'local-development-epoch'})
        response = self.commit(preview.json())
        self.assertEqual(response.status_code, 409)
        self.assertEqual(Entry.objects.count(), 1)

    def test_legacy_preview_rejects_unconsumed_preamble_and_invalid_fields(self):
        for text in ('不能被丢掉的前言\n\n1、标题：\n正文', '1、' + 'x' * 121 + '：\n正文', '\ud800'):
            with self.subTest(text=text[:20]):
                response = self.preview(text, mode='legacy')
                self.assertEqual(response.status_code, 422)
        accepted = self.preview('\ufeff\n\n1、' + 'x' * 120 + '：\n正文', mode='legacy')
        self.assertEqual(accepted.status_code, 200)
        self.assertEqual(Entry.objects.count(), 0)

    def test_depth_limit_accepts_16_and_rejects_17_before_parsing_entries(self):
        nested = 0
        for _ in range(14):
            nested = {'x': nested}
        self.sample['scope']['filters'] = nested
        self.assertEqual(self.preview().status_code, 200)
        self.sample['scope']['filters'] = {'x': nested}
        rejected = self.preview()
        self.assertEqual(rejected.status_code, 422)
        self.assertEqual(rejected.json()['error'], 'too_deep')

    def test_count_2001_is_rejected_without_creating_entries(self):
        self.sample['entries'] = [self.sample['entries'][0]] * 2001
        self.sample['entry_count'] = 2001
        response = self.preview()
        self.assertEqual(response.status_code, 422)
        self.assertEqual(response.json()['error'], 'invalid_count')
        self.assertEqual(Entry.objects.count(), 0)

    def test_literal_field_limits_are_checked_during_preview(self):
        for index, field, limit in ((0, 'title', 120), (0, 'content', 50000), (1, 'intro', 5000), (0, 'shared_note', 10000)):
            with self.subTest(field=field):
                sample = copy.deepcopy(self.sample); sample['entries'][index][field] = 'x' * limit
                self.assertEqual(self.preview(json.dumps(sample)).status_code, 200)
                sample['entries'][index][field] += 'x'
                self.assertEqual(self.preview(json.dumps(sample)).status_code, 422)

    def setUp(self):
        self.client_a = self.session('alice')
        self.sample = fixture()

    def preview(self, text=None, **extra):
        return self.write(self.client_a, '/api/exchange/preview/', {'text': text if text is not None else json.dumps(self.sample, ensure_ascii=False), 'mode': 'full', 'operation_id': 'import-1', 'operation_epoch': 'local-development-epoch', **extra})

    def commit(self, preview, text=None, **extra):
        return self.write(self.client_a, '/api/exchange/commit/', {'text': text if text is not None else json.dumps(self.sample, ensure_ascii=False), 'mode': 'full', 'preview_token': preview['preview_token'], 'confirmed': True, 'operation_id': 'import-1', 'operation_epoch': 'local-development-epoch', **extra})

    def test_preview_cancel_has_no_database_side_effect_and_requires_confirmation(self):
        preview = self.preview()
        self.assertEqual(preview.status_code, 200)
        self.assertEqual(preview.json()['entry_count'], 2)
        self.assertEqual(Entry.objects.count(), 0)
        self.assertEqual(self.commit(preview.json(), confirmed=False).status_code, 422)
        self.assertEqual(Entry.objects.count(), 0)

    def test_complete_two_kind_import_and_export_preserve_independent_literal_values(self):
        preview = self.preview()
        self.assertEqual(preview.status_code, 200)
        result = self.commit(preview.json())
        self.assertEqual(result.status_code, 201)
        self.assertEqual(Entry.objects.count(), 2)
        self.assertTrue(all(x.owner.username == 'alice' for x in Entry.objects.all()))
        exported = self.client_a.get('/api/exchange/export/', {'scope': 'all'})
        self.assertEqual(exported.status_code, 200)
        document = json.loads(exported.content)
        self.assertEqual(document['schema_version'], 2)
        self.assertEqual(document['entry_count'], 2)
        rows = {x['kind']: x for x in document['entries']}
        self.assertEqual(rows['PROMPT']['content'], '  前置空白\r\n1、正文编号：\n"引号" \\ 反斜杠 😀\n')
        self.assertEqual(rows['PROMPT']['shared_note'], '  共同备注\n备注：不是分隔符\r\n')
        self.assertEqual(set(rows['PROMPT']['tags']), {'需求', 'Python'})
        self.assertEqual(rows['SKILL']['github_snapshot']['stars'], 0)
        self.assertEqual(rows['PROMPT']['origin']['source_author'], 'alice')
        self.assertNotIn('category_path', rows['PROMPT'])

    def test_replaying_commit_never_creates_second_batch(self):
        preview = self.preview()
        self.assertEqual(preview.status_code, 200)
        first = self.commit(preview.json())
        self.assertEqual(first.status_code, 201)
        second = self.commit(preview.json())
        self.assertEqual(second.status_code, 201)
        self.assertEqual(first.json(), second.json())
        self.assertEqual(Entry.objects.count(), 2)

    def test_changed_file_or_forged_token_does_not_write(self):
        preview = self.preview()
        self.assertEqual(preview.status_code, 200)
        changed = copy.deepcopy(self.sample); changed['entries'][0]['shared_note'] = '换过文件'
        self.assertEqual(self.commit(preview.json(), json.dumps(changed)).status_code, 409)
        self.assertEqual(self.commit({'preview_token': 'forged'}).status_code, 409)
        self.assertEqual(Entry.objects.count(), 0)

    def test_rejects_v1_duplicate_keys_unknown_fields_and_non_finite_numbers(self):
        cases = ['{"format":"x","format":"y"}', '{"schema_version":NaN}', '{"schema_version":Infinity}']
        old = copy.deepcopy(self.sample); old['schema_version'] = 1; old['entries'][0]['category_path'] = ['旧目录']; cases.append(json.dumps(old))
        unknown = copy.deepcopy(self.sample); unknown['entries'][0]['admin'] = True; cases.append(json.dumps(unknown))
        bool_stars = copy.deepcopy(self.sample); bool_stars['entries'][1]['github_snapshot']['stars'] = True; cases.append(json.dumps(bool_stars))
        for text in cases:
            with self.subTest(text=text[:50]):
                self.assertEqual(self.preview(text).status_code, 422)
        self.assertEqual(Entry.objects.count(), 0)

    def test_rejects_one_bad_entry_without_creating_first_good_entry(self):
        self.sample['entries'][1]['tags'] = ['x'] * 11
        self.assertEqual(self.preview().status_code, 422)
        self.assertEqual(Entry.objects.count(), 0)

    def test_invalid_utf8_real_upload_is_rejected_without_fallback(self):
        response = self.client_a.post('/api/exchange/preview/', {'file': SimpleUploadedFile('bad.txt', b'\xff\xfe'), 'mode': 'full', 'operation_id': 'import-1', 'operation_epoch': 'local-development-epoch'}, HTTP_X_CSRFTOKEN=self.client_a.cookies['csrftoken'].value)
        self.assertEqual(response.status_code, 422)

    def test_legacy_format_is_explicit_and_keeps_body_numbering(self):
        original = '1、标题：\n正文\n1.普通编号\n\n2、第二条：\n第二正文'
        bad = self.preview(original)
        self.assertEqual(bad.status_code, 422)
        preview = self.preview(original, mode='legacy')
        self.assertEqual(preview.status_code, 200)
        self.assertEqual(preview.json()['entries'][0]['content'], '正文\n1.普通编号')
        self.assertEqual(preview.json()['entries'][0]['shared_note'], '')

    def test_export_uses_all_matching_pages_not_only_current_page(self):
        preview = self.preview()
        self.assertEqual(preview.status_code, 200)
        self.assertEqual(self.commit(preview.json()).status_code, 201)
        response = self.client_a.get('/api/exchange/export/', {'scope': 'all', 'page_size': '1'})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(json.loads(response.content)['entry_count'], 2)
        self.assertEqual(self.client_a.get('/api/exchange/export/', {'scope': 'all', 'format': 'legacy'}).status_code, 422)

    def test_export_entire_kind_is_distinct_from_filtered_results(self):
        preview = self.preview(); self.commit(preview.json())
        self.write(self.client_a, '/api/entries/', {'kind': 'PROMPT', 'title': '第二条', 'content': '正文', 'intro': '', 'tags': [], 'operation_id': 'another-prompt', 'operation_epoch': 'local-development-epoch'})
        result = self.client_a.get('/api/exchange/export/', {'scope': 'kind', 'kind': 'PROMPT'})
        self.assertEqual(result.status_code, 200)
        self.assertEqual(json.loads(result.content)['entry_count'], 2)
        filtered = self.client_a.get('/api/exchange/export/', {'scope': 'filtered', 'kind': 'PROMPT', 'name': '第二条'})
        self.assertEqual(json.loads(filtered.content)['entry_count'], 1)

    def test_legacy_readable_export_appends_shared_note_as_plain_body_text(self):
        preview = self.preview()
        self.assertEqual(preview.status_code, 200)
        self.assertEqual(self.commit(preview.json()).status_code, 201)
        response = self.client_a.get('/api/exchange/export/', {'kind': 'PROMPT', 'format': 'legacy_notes'})
        self.assertEqual(response.status_code, 200)
        expected = '1、需求澄清：\n  前置空白\r\n1、正文编号：\n"引号" \\ 反斜杠 😀\n\n{备注：  共同备注\n备注：不是分隔符\r\n}'
        self.assertEqual(response.content.decode('utf-8'), expected)
        self.assertEqual(Entry.objects.get(kind='PROMPT').note.text, '  共同备注\n备注：不是分隔符\r\n')
        old_reader = self.preview(expected, mode='legacy')
        self.assertEqual(old_reader.status_code, 200)
        self.assertIn('{备注：', old_reader.json()['entries'][0]['content'])
        self.assertEqual(old_reader.json()['entries'][0]['shared_note'], '')
        self.assertEqual(self.client_a.get('/api/exchange/export/', {'scope': 'all', 'format': 'legacy_notes'}).status_code, 422)
