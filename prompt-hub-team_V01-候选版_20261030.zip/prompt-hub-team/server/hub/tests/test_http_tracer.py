import requests
from django.test import LiveServerTestCase
from hub.models import Member

class HTTPTracerTests(LiveServerTestCase):
    def test_actual_http_server_has_team_entry_and_two_independent_sessions(self):
        for name in ('alice', 'bob'):
            Member.objects.create_user(username=name, password='Tracer-Strong-2026!', display_name=name, must_change_password=False)
        sessions = []
        for name in ('alice', 'bob'):
            client = requests.Session()
            bootstrap = client.get(self.live_server_url + '/api/session/', timeout=5)
            self.assertEqual(bootstrap.status_code, 200)
            response = client.post(self.live_server_url + '/api/login/', json={'username': name, 'password': 'Tracer-Strong-2026!'}, headers={'X-CSRFToken': client.cookies['csrftoken']}, timeout=5)
            self.assertEqual(response.status_code, 200)
            sessions.append(client)
        alice, bob = sessions
        data = {'kind': 'PROMPT', 'title': 'HTTP共享', 'content': '真实请求', 'intro': '', 'tags': [], 'operation_id': 'http-create', 'operation_epoch': 'local-development-epoch'}
        response = alice.post(self.live_server_url + '/api/entries/', json=data, headers={'X-CSRFToken': alice.cookies['csrftoken']}, timeout=5)
        self.assertEqual(response.status_code, 201)
        entry = response.json()['entry']
        response = bob.patch(self.live_server_url + f"/api/entries/{entry['id']}/note/", json={'text': '真实HTTP备注', 'note_version': 1, 'operation_id': 'http-note', 'operation_epoch': 'local-development-epoch'}, headers={'X-CSRFToken': bob.cookies['csrftoken']}, timeout=5)
        self.assertEqual(response.status_code, 200)
        final = alice.get(self.live_server_url + f"/api/entries/{entry['id']}/", timeout=5).json()['entry']
        self.assertEqual(final['shared_note'], '真实HTTP备注')
        self.assertEqual(final['content'], '真实请求')
        page = alice.get(self.live_server_url + '/team/', timeout=5)
        self.assertEqual(page.status_code, 200)
        self.assertIn('提示词与技能分享库', page.text)
        for client in sessions:
            client.close()
