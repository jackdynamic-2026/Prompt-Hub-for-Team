import os
from unittest import skipUnless
from django.test import TestCase
from .test_tracer import APIClientMixin

class SkillSourceTests(APIClientMixin, TestCase):
    def setUp(self):
        self.a = self.session('alice')
        self.source = {'provider': 'github', 'owner': 'django', 'repo': 'django', 'skill_path': '', 'source_url': 'https://github.com/django/django'}

    def create(self, source, op='skill-new'):
        return self.write(self.a, '/api/entries/', {'kind': 'SKILL', 'title': '公开仓库资料', 'content': '', 'intro': '人工介绍', 'tags': ['工程'], 'skill_source': source, 'operation_id': op, 'operation_epoch': 'local-development-epoch'})

    def test_skill_can_record_a_public_repository_without_network_or_code(self):
        response = self.create(self.source)
        self.assertEqual(response.status_code, 201)
        entry = response.json()['entry']
        self.assertEqual(entry['skill_source']['source_url'], 'https://github.com/django/django')
        self.assertIsNone(entry['github_snapshot'])
        self.assertEqual(entry['intro'], '人工介绍')

    def test_arbitrary_network_targets_and_invalid_paths_are_rejected(self):
        urls = ['http://127.0.0.1/admin', 'https://github.com@127.0.0.1/django/django', 'https://github.com.evil.test/django/django', 'https://github.com:443/django/django']
        for i, url in enumerate(urls):
            with self.subTest(url=url):
                self.assertEqual(self.create({**self.source, 'source_url': url}, f'bad-source-{i}').status_code, 422)
        self.assertEqual(self.create({**self.source, 'skill_path': '../private'}, 'bad-path').status_code, 422)

    def test_changing_repository_clears_the_old_imported_star_snapshot(self):
        from hub.models import Entry
        entry = self.create(self.source).json()['entry']
        Entry.objects.filter(pk=entry['id']).update(github_snapshot={'stars': 987, 'fetched_at': None, 'state': 'unverified'})
        source = {**self.source, 'owner': 'python', 'repo': 'cpython', 'source_url': 'https://github.com/python/cpython'}
        response = self.write(self.a, f"/api/entries/{entry['id']}/", {'title': entry['title'], 'content': '', 'intro': '新仓库', 'tags': [], 'skill_source': source, 'body_version': 1, 'operation_id': 'change-source', 'operation_epoch': 'local-development-epoch'}, 'patch')
        self.assertEqual(response.status_code, 200)
        self.assertIsNone(response.json()['entry']['github_snapshot'])
        self.assertEqual(response.json()['entry']['source_version'], 2)

    def test_repository_pages_preserve_locator_without_validating_skill_files(self):
        urls = ['https://github.com/django/django/tree/main',
                'https://github.com/django/django/blob/main/README.rst',
                'https://github.com/django/django/tree/missing-branch/missing-skill?tab=readme#intro',
                'https://github.com/django/django?redirect=https://evil.test#intro']
        for i, url in enumerate(urls):
            with self.subTest(url=url):
                response = self.create({**self.source, 'source_url': url}, f'nested-{i}')
                self.assertEqual(response.status_code, 201, response.content)
                source = response.json()['entry']['skill_source']
                self.assertEqual(source['source_url'], url)
                self.assertEqual(source['skill_path'], '')

    def test_mismatched_repository_and_encoded_authority_are_still_rejected(self):
        for i, url in enumerate(['https://github.com/python/cpython/tree/main',
                                 'https://github.com/%64jango/django/tree/main',
                                 'https://github.com/django/django\n/tree/main']):
            with self.subTest(url=url):
                self.assertEqual(self.create({**self.source, 'source_url': url}, f'unsafe-{i}').status_code, 422)

    def test_metadata_parser_rejects_invalid_shapes_without_replacing_business_logic(self):
        from hub.github import parse_metadata
        from hub.errors import APIError
        values = [b'[]', b'null', b'not-json', b'{"stargazers_count": true, "full_name":"django/django"}', b'{"stargazers_count":-1,"full_name":"django/django"}', b'{"stargazers_count":1,"full_name":123}', b'{"stargazers_count":1,"full_name":"other/repo"}']
        for raw in values:
            with self.subTest(raw=raw), self.assertRaises(APIError):
                parse_metadata(raw, 'django/django')
        self.assertEqual(parse_metadata(b'{"stargazers_count":0,"full_name":"django/django","description":"unit input"}', 'django/django'), (0, 'unit input'))

    @skipUnless(os.environ.get('PH_LIVE_GITHUB') == '1', '真实GitHub网络测试须显式开启，未运行不计通过')
    def test_real_github_metadata_preserves_manual_fields(self):
        created = self.create({**self.source, 'source_url': 'https://github.com/django/django/tree/main?tab=readme#intro'})
        self.assertEqual(created.status_code, 201)
        entry = created.json()['entry']
        response = self.write(self.a, f"/api/entries/{entry['id']}/github/", {})
        self.assertEqual(response.status_code, 200, response.content)
        value = response.json()['entry']
        self.assertEqual(value['intro'], '人工介绍')
        self.assertEqual(value['shared_note'], '')
        self.assertEqual(value['updated_at'], entry['updated_at'])
        self.assertIs(type(value['github_snapshot']['stars']), int)
        self.assertGreaterEqual(value['github_snapshot']['stars'], 0)
        self.assertEqual(value['github_snapshot']['state'], 'verified')
        self.assertFalse(value['skill_path_verified'])
