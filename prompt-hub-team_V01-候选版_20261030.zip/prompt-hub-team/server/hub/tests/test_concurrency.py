from concurrent.futures import ThreadPoolExecutor
from threading import Barrier
from django.db import close_old_connections
from django.test import TransactionTestCase
from hub.models import Entry, Member
from .test_tracer import APIClientMixin

class ConcurrentWriteTests(APIClientMixin, TransactionTestCase):
    def setUp(self):
        for name in ('alice', 'bob'):
            Member.objects.create_user(username=name, password='Tracer-Strong-2026!', display_name=name, must_change_password=False)

    def test_two_real_connections_never_silently_overwrite_one_note_version(self):
        a, b = self.session('alice'), self.session('bob')
        entry = self.write(a, '/api/entries/', {'kind': 'PROMPT', 'title': '并发', 'content': '正文', 'intro': '', 'tags': [], 'operation_id': 'concurrent-create', 'operation_epoch': 'local-development-epoch'}).json()['entry']
        barrier = Barrier(2)
        def save(client, text, op):
            close_old_connections(); barrier.wait(timeout=10)
            try:
                return self.write(client, f"/api/entries/{entry['id']}/note/", {'text': text, 'note_version': 1, 'operation_id': op, 'operation_epoch': 'local-development-epoch'}, 'patch').status_code
            finally:
                close_old_connections()
        with ThreadPoolExecutor(max_workers=2) as pool:
            futures = [pool.submit(save, a, 'A的备注', 'concurrent-a'), pool.submit(save, b, 'B的备注', 'concurrent-b')]
            statuses = [f.result(timeout=20) for f in futures]
        self.assertEqual(statuses.count(200), 1, statuses)
        self.assertTrue(all(s in (200, 409, 503) for s in statuses), statuses)
        final = self.a_entry(a, entry['id'])
        self.assertIn(final['shared_note'], ('A的备注', 'B的备注'))
        self.assertEqual(final['note_version'], 2)
        self.assertEqual(final['content'], '正文')

    def a_entry(self, client, entry_id):
        return client.get(f'/api/entries/{entry_id}/').json()['entry']
