import json
from django.core.management.base import BaseCommand, CommandError
from hub.models import Member, RateBucket
from hub.rate_limits import private_key


class Command(BaseCommand):
    help = '受控管理员终端解除单个账号的登录冷却；不解除IP限流'

    def add_arguments(self, parser):
        parser.add_argument('--username', required=True)

    def handle(self, *args, **options):
        name = Member.normalize_username(options['username'])
        member = Member.objects.filter(username=name).first()
        if not member:
            raise CommandError('账号不存在')
        RateBucket.objects.filter(key=private_key('login-account', name)).delete()
        self.stdout.write(json.dumps({'event': 'account_unlocked_by_operator', 'target_id': member.pk}))
