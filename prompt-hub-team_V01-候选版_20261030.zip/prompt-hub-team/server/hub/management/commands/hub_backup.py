import json
import uuid
from django.core.management.base import BaseCommand, CommandError
from django.db import connection
from hub.backup import read_key, snapshot


class Command(BaseCommand):
    help = '创建并核验加密本地快照；不代表异机备份成功'

    def add_arguments(self, parser):
        parser.add_argument('--output', required=True)
        parser.add_argument('--key-file', required=True)

    def handle(self, *args, **options):
        backup_id = str(uuid.uuid4())
        self.stdout.write(json.dumps({'event': 'backup_started', 'backup_id': backup_id}))
        try:
            connection.ensure_connection()
            if connection.in_atomic_block:
                raise ValueError('不能在业务事务中创建备份')
            result = snapshot(connection.connection, options['output'], read_key(options['key_file']))
        except Exception as exc:
            self.stderr.write(json.dumps({'event': 'backup_failed', 'backup_id': backup_id, 'error_type': type(exc).__name__}))
            raise CommandError('本地快照未完成，保留上一份备份；检查空间、密钥和输出路径') from exc
        self.stdout.write(json.dumps({'event': 'backup_local_verified', 'backup_id': backup_id, **result}))
