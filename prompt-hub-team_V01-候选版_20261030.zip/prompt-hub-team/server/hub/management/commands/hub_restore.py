import json
import uuid
from django.core.management.base import BaseCommand, CommandError
from hub.backup import read_key, restore


class Command(BaseCommand):
    help = '验证加密备份并恢复到新目录；不会替换运行数据库或切流'

    def add_arguments(self, parser):
        parser.add_argument('--input', required=True)
        parser.add_argument('--key-file', required=True)
        parser.add_argument('--destination', required=True)

    def handle(self, *args, **options):
        restore_id = str(uuid.uuid4())
        self.stdout.write(json.dumps({'event': 'restore_started', 'restore_id': restore_id}))
        try:
            result = restore(options['input'], options['destination'], read_key(options['key_file']))
        except Exception as exc:
            self.stderr.write(json.dumps({'event': 'restore_failed', 'restore_id': restore_id, 'error_type': type(exc).__name__}))
            raise CommandError('恢复未完成；目录须全新，备份及密钥须有效；不要开放服务') from exc
        self.stdout.write(json.dumps({'event': 'restore_verified', 'restore_id': restore_id, **result}))
