import json
from datetime import timedelta
from django.contrib.sessions.models import Session
from django.core.management.base import BaseCommand
from django.db import transaction
from django.db.models import Q
from django.utils import timezone
from hub.models import AuditEvent, OperationReceipt, RateBucket


class Command(BaseCommand):
    help = '默认只预览。--apply清理到期运行记录，不删除条目、用户或最后备份'

    def add_arguments(self, parser):
        parser.add_argument('--apply', action='store_true')

    def handle(self, *args, **options):
        now = timezone.now()
        audits = AuditEvent.objects.filter(created_at__lt=now - timedelta(days=90))
        sessions = Session.objects.filter(expire_date__lte=now)
        receipts = OperationReceipt.objects.filter(expires_at__lte=now).exclude(result={})
        rates = RateBucket.objects.filter(window_start__lt=now - timedelta(days=2)).filter(Q(blocked_until__lte=now) | Q(blocked_until__isnull=True))
        summary = {'event': 'maintenance', 'apply': options['apply'], 'audits': audits.count(), 'sessions': sessions.count(), 'receipt_results': receipts.count(), 'rate_buckets': rates.count()}
        if options['apply']:
            with transaction.atomic():
                audits.delete(); sessions.delete(); rates.delete()
                # Retain actor/ID/digest/expiry. Otherwise a very late retry could create a duplicate.
                receipts.update(result={})
        self.stdout.write(json.dumps(summary))
