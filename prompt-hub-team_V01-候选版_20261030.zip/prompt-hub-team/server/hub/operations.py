import hashlib
import json
import re
from datetime import timedelta
from functools import wraps
from django.conf import settings
from django.db import transaction
from django.utils import timezone
from .authentication import check_writer
from .errors import APIError
from .models import OperationReceipt
from .observability import event

def mutation(action):
    def decorate(fn):
        @wraps(fn)
        def execute(request, *args):
            payload = args[-1]
            op = payload.get('operation_id')
            if not isinstance(op, str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,80}', op):
                raise APIError('invalid_operation', '需要有效的操作ID')
            if payload.get('operation_epoch') != settings.OPERATION_EPOCH:
                raise APIError('stale_epoch', '系统已恢复或更新，请刷新并重新核对操作', 409)
            request.operation_id = op
            digest = hashlib.sha256(json.dumps([request.method, action, args[:-1], payload], ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
            with transaction.atomic():
                request.stage = action+'.authorize'
                check_writer(request)
                request.stage = action+'.receipt_lookup'
                old = OperationReceipt.objects.filter(actor=request.user, operation_id=op).first()
                if old:
                    if old.digest != digest:
                        raise APIError('payload_mismatch', '相同操作ID的载荷不同', 409)
                    if old.expires_at <= timezone.now():
                        raise APIError('receipt_expired', '回执已过期，请读取当前内容后重新确认', 409)
                    event(request, 'receipt.replayed', 'replayed', operation_id=op)
                    return old.result
                request.stage = action+'.apply'
                result = fn(request, *args)
                request.stage = action+'.receipt'
                OperationReceipt.objects.create(actor=request.user, operation_id=op, digest=digest, result=result, expires_at=timezone.now() + timedelta(hours=24))
                event(request, action, 'prepared')
                request.stage = action+'.commit'
                transaction.on_commit(lambda: event(request, action, 'committed'))
                return result
        return execute
    return decorate
