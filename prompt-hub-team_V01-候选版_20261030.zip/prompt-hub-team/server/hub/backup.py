"""Private, authenticated streaming snapshots. Restore never replaces a live database."""
import hashlib
import os
from pathlib import Path
import secrets
import sqlite3
import tempfile
import time
from contextlib import closing
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

MAGIC = b'PHBK1\x00'
CHUNK = 1024 * 1024
MAX_BYTES = 2 * 1024 * 1024 * 1024


def read_key(path):
    key = Path(path).read_bytes()
    if len(key) != 32:
        raise ValueError('密钥文件必须是32个随机字节，不能使用口令文本')
    return key


def check_database(path):
    with closing(sqlite3.connect(f'{Path(path).resolve().as_uri()}?mode=ro', uri=True)) as db:
        if db.execute('PRAGMA integrity_check').fetchall() != [('ok',)]:
            raise ValueError('数据库完整性检查失败')
        if db.execute('PRAGMA foreign_key_check').fetchone():
            raise ValueError('数据库外键检查失败')


def encrypt(source, output, key):
    nonce = os.urandom(12)
    cipher = Cipher(algorithms.AES(key), modes.GCM(nonce)).encryptor()
    cipher.authenticate_additional_data(MAGIC)
    with Path(source).open('rb') as plain, Path(output).open('xb') as encrypted:
        os.chmod(output, 0o600)
        encrypted.write(MAGIC + nonce)
        while chunk := plain.read(CHUNK):
            encrypted.write(cipher.update(chunk))
        encrypted.write(cipher.finalize()); encrypted.write(cipher.tag)
        encrypted.flush(); os.fsync(encrypted.fileno())


def decrypt(source, output, key):
    size = Path(source).stat().st_size
    if not len(MAGIC) + 28 < size <= MAX_BYTES + len(MAGIC) + 28:
        raise ValueError('备份大小无效或超过2GiB')
    with Path(source).open('rb') as encrypted, Path(output).open('xb') as plain:
        os.chmod(output, 0o600)
        if encrypted.read(len(MAGIC)) != MAGIC:
            raise ValueError('备份格式无效')
        nonce = encrypted.read(12)
        encrypted.seek(-16, 2); tag = encrypted.read(16)
        encrypted.seek(len(MAGIC) + 12)
        cipher = Cipher(algorithms.AES(key), modes.GCM(nonce, tag)).decryptor()
        cipher.authenticate_additional_data(MAGIC)
        remaining = size - len(MAGIC) - 28
        while remaining:
            chunk = encrypted.read(min(CHUNK, remaining))
            if not chunk:
                raise ValueError('备份被截断')
            plain.write(cipher.update(chunk)); remaining -= len(chunk)
        plain.write(cipher.finalize())  # No SQLite access before the authentication tag passes.
        plain.flush(); os.fsync(plain.fileno())


def digest(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as handle:
        while chunk := handle.read(CHUNK):
            value.update(chunk)
    return value.hexdigest()


def snapshot(connection, output, key):
    output = Path(output).resolve()
    if output.exists():
        raise ValueError('输出文件已存在，禁止覆盖')
    with tempfile.TemporaryDirectory(prefix='.ph-backup-', dir=output.parent) as folder:
        plain = Path(folder) / 'snapshot.sqlite3'; encrypted = Path(folder) / 'snapshot.phbk'
        started = time.monotonic()
        def progress(status, remaining, total):
            if total * 4096 > MAX_BYTES or time.monotonic() - started > 60:
                raise ValueError('备份超出大小或时间预算，请保留上一份备份并调查')
        with closing(sqlite3.connect(plain)) as target:
            connection.backup(target, pages=256, progress=progress, sleep=0.05)
        if plain.stat().st_size > MAX_BYTES:
            raise ValueError('数据库超过2GiB')
        check_database(plain)
        encrypt(plain, encrypted, key)
        verification = Path(folder) / 'verification.sqlite3'
        decrypt(encrypted, verification, key); check_database(verification)
        # Hard-link publication fails if another process has already created this name.
        os.link(encrypted, output)
    return {'sha256': digest(output), 'bytes': output.stat().st_size, 'state': 'local_snapshot_verified'}


def restore(source, destination, key):
    destination = Path(destination).resolve()
    if destination.exists():
        raise ValueError('恢复目录已存在；只允许恢复到全新目录')
    with tempfile.TemporaryDirectory(prefix='.ph-restore-', dir=destination.parent) as folder:
        database = Path(folder) / 'hub.sqlite3'
        decrypt(source, database, key); check_database(database)
        with closing(sqlite3.connect(database)) as db:
            with db:
                db.execute('DELETE FROM django_session')
                db.execute('DELETE FROM hub_operationreceipt')
                db.execute('DELETE FROM hub_externallease')
                if db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='hub_sessionpolicy'").fetchone():
                    db.execute('DELETE FROM hub_sessionpolicy')
                db.execute('UPDATE hub_member SET auth_version=auth_version+1')
        check_database(database)
        epoch = secrets.token_urlsafe(32)
        destination.mkdir(mode=0o700)
        try:
            with (destination / 'operation_epoch.txt').open('x', encoding='ascii') as handle:
                handle.write(epoch + '\n')
            os.chmod(destination / 'operation_epoch.txt', 0o600)
            os.link(database, destination / 'hub.sqlite3')
        except Exception:
            # Remove only files created by this operation. Never touch an existing database.
            (destination / 'operation_epoch.txt').unlink(missing_ok=True)
            destination.rmdir()
            raise
    return {'state': 'restore_verified_offline', 'sha256': digest(destination / 'hub.sqlite3')}
