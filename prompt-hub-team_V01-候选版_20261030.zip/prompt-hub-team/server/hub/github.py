import base64
import json
import time
import uuid
from datetime import timedelta
from django.db import transaction, DatabaseError
from django.utils import timezone
from .errors import APIError
from .models import ExternalLease, RepositoryCache
from .observability import event
from .services import get_entry, serialize
from .github_transport import fetch_once
from .github_policy import (reserve_attempt, commit_cache, assert_lease, wait_error,
                            check_cooldowns, usable_cache, classify_http, cooldown_until, retry_allowed, MESSAGES)


def repo_key(source):
    return (source['owner'] + '/' + source['repo']).lower()


def parse_metadata(raw, key):
    try:
        data = json.loads(raw)
    except (ValueError, UnicodeError):
        raise APIError('github_invalid_json', '仓库响应格式无效', 502)
    if not isinstance(data, dict):
        raise APIError('github_invalid_response', '仓库响应必须是对象', 502)
    stars, name = data.get('stargazers_count'), data.get('full_name')
    if type(stars) is not int or stars < 0 or not isinstance(name, str) or name.lower() != key:
        raise APIError('github_invalid_response', '仓库响应字段或来源不匹配', 502)
    description = data.get('description') or ''
    return stars, description if isinstance(description, str) and len(description) <= 5000 else ''


def reply(request, entry_id, source, version, cache, outcome, attempts):
    current = get_entry(entry_id)
    if current.source_version != version or not current.skill_source or repo_key(current.skill_source) != repo_key(source):
        event(request, 'github.result_discarded', 'discarded', reason='source_changed')
        raise APIError('github_source_changed', '来源已变化，请重新读取条目', 409)
    return {'entry': serialize(current), 'candidate_intro': cache.description,
            'refresh': {'outcome': outcome, 'request_id': request.request_id, 'attempts': attempts,
                        'checked_at': cache.fetched_at.isoformat() if cache.fetched_at else None,
                        'cache_age_seconds': max(0, int((timezone.now()-cache.fetched_at).total_seconds())) if cache.fetched_at else None}}


def refresh(request, entry_id):
    entry = get_entry(entry_id)
    if entry.kind != 'SKILL' or not entry.skill_source:
        raise APIError('missing_source', '请先由分享人设置公开GitHub仓库来源')
    source, version = entry.skill_source, entry.source_version
    key = repo_key(source)
    token, attempts, outcome, owned = str(uuid.uuid4()), 0, 'failed', False
    started = time.monotonic()

    def log(name, result='completed', **fields):
        request.stage = 'github.'+name
        event(request, 'github.'+name, result, repository_key=key, source_version=version, **fields)

    log('refresh_started', 'started')
    try:
        cache = RepositoryCache.objects.filter(key=key).first()
        if cache and cache.fetched_at and cache.fetched_at > timezone.now():
            log('cache_invalid', 'rejected', reason='future_timestamp')
        check_cooldowns(cache)
        if usable_cache(cache) and cache.state == 'verified' and timezone.now()-cache.fetched_at < timedelta(seconds=60):
            outcome = 'cached'
            log('cache_hit', outcome=outcome)
            return reply(request, entry_id, source, version, cache, outcome, attempts)
        now = timezone.now()
        with transaction.atomic():
            lease, _ = ExternalLease.objects.get_or_create(key='github', defaults={'token': '', 'expires_at': now})
            owned = bool(ExternalLease.objects.filter(pk=lease.pk, expires_at__lte=now).update(token=token, expires_at=now+timedelta(seconds=20)))
            if not owned:
                log('lease_busy', 'rejected')
                lease.refresh_from_db()
                raise wait_error('github_busy', '已有仓库刷新正在进行，请稍后再试', lease.expires_at, 'lease', cache, 503)
        log('lease_acquired')
        cache = RepositoryCache.objects.filter(key=key).first()
        check_cooldowns(cache)
        if usable_cache(cache) and cache.state == 'verified' and timezone.now()-cache.fetched_at < timedelta(seconds=60):
            outcome = 'cached'
            log('cache_hit', outcome=outcome)
            return reply(request, entry_id, source, version, cache, outcome, attempts)
        current = get_entry(entry_id)
        if current.source_version != version:
            raise APIError('github_source_changed', '来源已变化，请重新读取条目', 409)
        deadline = started+16
        etag = cache.etag if usable_cache(cache) and cache.etag and not any(ord(c)<32 or ord(c)==127 for c in cache.etag) else ''
        for attempt in (1, 2):
            assert_lease(token)
            if deadline-time.monotonic() < 0.5:
                result = {'error': 'github_time_budget', 'retryable': False}
                break
            try:
                reserve_attempt(request.user.pk)
            except APIError as exc:
                log('budget_rejected', 'rejected', attempt=attempt, scope=exc.details['scope'])
                if attempts:
                    commit_cache(token, key, {'state': 'stale' if cache and cache.stars is not None else 'failed', 'retry_after': timezone.now()+timedelta(seconds=30)})
                raise
            attempts = attempt
            log('budget_reserved', attempt=attempt)
            log('attempt_started', 'started', attempt=attempt)
            before = time.monotonic()
            result = fetch_once(source['owner'], source['repo'], etag, deadline,
                                lambda name, **fields: log(name, 'failed' if name == 'worker_failed' else 'completed', attempt=attempt, **fields))
            log('attempt_finished', 'failed' if result.get('error') else 'completed', attempt=attempt,
                duration_ms=round((time.monotonic()-before)*1000), http_status=result.get('status'),
                error_code=result.get('error'), exception_type=result.get('exception_type'),
                os_errno=result.get('os_errno'), winerror=result.get('winerror'), bytes_read=result.get('bytes_read'),
                remaining_budget_ms=max(0, round((deadline-time.monotonic())*1000)))
            if 'error' not in result:
                try:
                    status, headers = result['status'], result['headers']
                    if type(status) is not int or not isinstance(headers, dict):
                        raise ValueError()
                    body = base64.b64decode(result['body'], validate=True)
                    if len(body)>256*1024:
                        raise ValueError()
                except (ValueError, KeyError, TypeError):
                    result = {'error': 'github_worker_invalid_output', 'retryable': False}
                else:
                    error = classify_http(status, headers, body)
                    if error:
                        result.update(error)
                    else:
                        try:
                            if status == 304:
                                if not etag or not usable_cache(cache):
                                    raise APIError('github_invalid_cache', 'GitHub返回304但没有有效本地Star缓存', 502)
                                values = {'state': 'verified', 'fetched_at': timezone.now(), 'retry_after': None}
                            else:
                                stars, description = parse_metadata(body, key)
                                values = {'stars': stars, 'description': description, 'etag': headers.get('etag', '')[:250], 'state': 'verified', 'fetched_at': timezone.now(), 'retry_after': None}
                        except APIError as exc:
                            result = {'error': exc.code, 'message': exc.message, 'retryable': False}
                            log('response_rejected', 'rejected', error_code=exc.code)
                        else:
                            log('response_validated', http_status=status)
                            cache = commit_cache(token, key, values)
                            outcome = 'not_modified' if status == 304 else 'updated'
                            log('cache_committed', outcome=outcome)
                            return reply(request, entry_id, source, version, cache, outcome, attempts)
            if retry_allowed(result, attempt, deadline-time.monotonic()):
                log('retry_scheduled', attempt=attempt+1, error_code=result['error'])
                time.sleep(0.2)
            else:
                log('retry_skipped', reason='not_retryable' if not result.get('retryable') else 'attempts_or_time_exhausted', error_code=result['error'])
                break
        code = result['error']
        until = cooldown_until(result.get('headers', {}), timezone.now()) if result.get('provider') else timezone.now()+timedelta(seconds=30)
        commit_cache(token, key, {'state': 'stale' if cache and cache.stars is not None else 'failed', 'retry_after': until}, until if result.get('provider') else None, result.get('worker_pid') if code == 'github_worker_unreaped' else None)
        log('failure_state_committed', error_code=code)
        if code == 'github_worker_unreaped':
            raise APIError(code, '网络工作进程未确认结束，已暂停仓库刷新；请联系管理员核验进程', 503, scope='provider_lifecycle', manual_intervention_required=True)
        raise wait_error(code, result.get('message') or MESSAGES.get(code, '仓库刷新执行失败，请凭关联号检查服务日志'), until, 'provider' if result.get('provider') else 'repository', cache, 429 if result.get('provider') else 502 if code in ('github_not_found', 'github_access_denied', 'github_redirect_blocked', 'github_remote_error') else 503)
    except APIError as exc:
        outcome = exc.code
        if 'cached_data_available' in exc.details and isinstance(entry.github_snapshot, dict) and type(entry.github_snapshot.get('stars')) is int and entry.github_snapshot['stars'] >= 0:
            exc.details['cached_data_available'] = True
        if exc.code in ('github_cooldown', 'github_provider_cooldown'):
            log('cooldown_hit', 'rejected', scope=exc.details.get('scope'), retry_at=exc.details.get('retry_at'))
        log('refresh_rejected', 'rejected', error_code=exc.code, scope=exc.details.get('scope'), retry_at=exc.details.get('retry_at'))
        raise
    except DatabaseError:
        log('database_failed', 'failed', error_code='database_unavailable', failed_stage=request.stage)
        raise
    finally:
        if owned:
            try:
                released = ExternalLease.objects.filter(key='github', token=token).update(expires_at=timezone.now())
                log('lease_released' if released else 'result_discarded', reason='released' if released else 'lease_replaced')
            except DatabaseError:
                log('lease_release_failed', 'failed', error_code='database_unavailable')
        log('refresh_finished', 'completed' if outcome in ('updated', 'not_modified', 'cached') else 'failed', outcome=outcome, attempts=attempts, duration_ms=round((time.monotonic()-started)*1000))
