# 提示词与技能分享库

最新源码构建、首次运行和发布边界见 [README](README.md)。源码检出须先执行 `npm ci`、`npm run build`；下面“已包含构建”的说明仅适用于明确附带 `dist` 的交付包，不适用于普通 Git 检出。公开前还须完成 [发布清单](docs/OPEN_SOURCE_CHECKLIST.md)。

这是从个人版 Prompt Hub 当前工作副本建立的团队版候选实现。原目录没有被覆盖。`/` 仍是个人版，`/team/` 使用同源后端共享数据。不能把团队版只上传到 GitHub Pages 后宣称可用。

## 已实现的入口

- 用户名密码登录。管理员创建账号。首次登录可选择改密，也可稍后在个人设置中修改。停用及权限变更撤销旧会话。
- 提示词、Skills 分开显示。只用标签。支持名称、标签、分享人、更新时间及个人收藏筛选。
- 分享人和管理员修改内容。全部有效成员修改共同备注并追加标签；只有分享人和管理员能显式删除标签。保存正文和恢复历史均保留当前协作标签。正文及备注使用独立版本，旧版本保存返回冲突。
- 历史快照各保留10份。恢复生成新版本。删除进回收站，管理员可在30天内恢复。
- Skills 只保存介绍、公开 GitHub 仓库资料、仓库 Star 和心得。仓库核验不证明 Skill 路径存在或代码安全。
- 团队推荐独立于私有收藏；有效成员各一票，显示总数。
- 个人设置默认60分钟无操作超时，实际活动续期，可设5至10080分钟；后台查询不续期。
- 完整 TXT 协议2／3及Skill简洁TXT先预览后导入。导入只创建副本。另提供旧版可读 TXT，正文后附 `{备注：…}`。
- 结构化日志、写入回执、登录限流、磁盘停写、离线备份恢复命令和部署模板。

## 从旧候选版升级（先完成）

先在你自己的服务终端按Ctrl+C停止旧服务，不要结束不明进程。然后在项目根目录执行以下步骤。本次代码更新不会自动修改你现用数据库或重设zadmin密码；若配置了PH_DATA_DIR，先核对其实际位置。

```powershell
.\.venv\Scripts\python.exe -m pip install -r server/requirements.lock.txt
if ($LASTEXITCODE -ne 0) { throw "依赖安装失败，停止升级" }
$env:PH_PRODUCTION='0'
$env:PH_LOCAL_HTTP='1'
$taskBackupRoot = Join-Path (Split-Path (Get-Location) -Parent) ('prompt-hub-backup-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
New-Item -ItemType Directory -Path $taskBackupRoot | Out-Null
.\.venv\Scripts\python.exe -c "import os,sys; from pathlib import Path; p=Path(sys.argv[1]); p.open('xb').write(os.urandom(32))" (Join-Path $taskBackupRoot 'backup.key')
Set-Location server
..\.venv\Scripts\python.exe manage.py shell -c "from django.conf import settings; from pathlib import Path; import sqlite3; p=settings.DATA_DIR/'hub.sqlite3'; assert p.is_file(), '已有数据库不存在，停止升级'; db=sqlite3.connect(p.as_uri()+'?mode=ro',uri=True); print('实际数据库:',p); print('原条目数:',db.execute('select count(*) from hub_entry').fetchone()[0]); db.close()"
if ($LASTEXITCODE -ne 0) { throw "数据库预检查失败，停止升级" }
..\.venv\Scripts\python.exe manage.py hub_backup --output (Join-Path $taskBackupRoot 'before-v5.phbk') --key-file (Join-Path $taskBackupRoot 'backup.key')
if ($LASTEXITCODE -ne 0) { throw "加密备份失败，停止升级" }
# 仅在上一步明确输出 backup_local_verified 且退出码为0后继续。
..\.venv\Scripts\python.exe manage.py migrate --noinput
if ($LASTEXITCODE -ne 0) { throw "迁移失败，停止升级" }
..\.venv\Scripts\python.exe manage.py check
if ($LASTEXITCODE -ne 0) { throw "检查失败，不启动服务" }
..\.venv\Scripts\python.exe manage.py runserver 127.0.0.1:8891 --noreload
```

每一步失败就停止，不要直接执行下一步。备份密钥不要公开，也不要只与备份保存在同一设备。升级后浏览器刷新，重新登录；原密码不变。已交付前端构建，无需额外运行npm构建。Windows正式部署另见 [deploy/windows/README.md](deploy/windows/README.md)。

## 本地启动

使用 Python 3.12 或3.13。本轮修复在Windows Python 3.13.5下验证。交付包已包含前端构建，体验时不需要先安装 Node。下面的命令在项目目录执行。请使用独立虚拟环境，不改个人项目或 OpenClaw 的环境。

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r server/requirements.lock.txt
$env:PH_PRODUCTION='0'
$env:PH_LOCAL_HTTP='1'
Set-Location server
..\.venv\Scripts\python.exe manage.py migrate
..\.venv\Scripts\python.exe manage.py createsuperuser
& {
    $ErrorActionPreference = 'Stop'
    $listeners = @(Get-NetTCPConnection -State Listen | Where-Object LocalPort -eq 8891)
    if ($listeners.Count) { throw "8891端口已有服务，请先核对PID：$($listeners.OwningProcess -join ',')，不要重复启动或直接结束其他服务。" }
    ..\.venv\Scripts\python.exe manage.py runserver 127.0.0.1:8891 --noreload
}
```

浏览器访问 `http://127.0.0.1:8891/team/`。创建管理员时输入自己的显示名和口令。交付包不含开发数据库或预置生产账号。开发服务器仅用于本机体验。

端口检查若提示“拒绝访问”，不能当作端口空闲。先完成进程核验再启动。测试使用独立端口和数据库，结束后只清理本人启动的测试进程。排查账号问题时，先用浏览器关联号对应实际服务日志，再核对进程路径和数据目录，不能只看当前终端目录。

用户密码默认最少8位，保留常见密码拦截。选择改密时，在个人设置输入当前密码、新密码、确认新密码，两次一致后提交。CLI重设密码也使用当前校验配置，不使用弱密码绕过确认。重设`zadmin`时，在你实际运行项目的`server`目录执行：

```powershell
..\.venv\Scripts\python.exe manage.py changepassword zadmin
```

在终端提示处输入两次新密码；不把密码写进命令或聊天。重设不自动清除登录冷却；确需解除该账号冷却时使用`manage.py hub_unlock --username zadmin`，它不解除IP限流。

列表卡片的普通区域可以打开详情；选择文字不会打开，同条重复点击不重建详情。共同备注冲突时保留草稿，先读取最新备注，以最新内容为底稿核对后再保存。草稿只保留在当前页面内存。同账号会话过期后重新登录、打开原条目可找回备注草稿；切账号会清除。刷新或关闭页面前请自行复制。

## TXT 选择

| 格式 | 用途 | 边界 |
| --- | --- | --- |
| Skill简洁TXT v1 | Skills默认可读格式，可重新导入；介绍、备注和标签使用竖线前缀 | 来源星数不变成本地投票；来源作者不赋权 |
| 完整 TXT 协议3 | 同协议2并带团队推荐快照 | 本站真实推荐从0开始，来源数字仅供参考 |
| 完整 TXT 协议2 | 团队版之间迁移条目、标签、独立共同备注和来源声明 | 不恢复账号权限、收藏或完整历史 |
| 旧版可读 TXT · 正文附备注 | 给旧 Prompt Hub 或文本编辑器阅读 | `{备注：…}` 会作为正文导入，不还原为独立备注 |
| 旧 Prompt TXT · 仅标题正文 | 保持原个人版导出习惯 | 省略备注、标签和来源；只用于提示词 |

Skill简洁格式示例在 [docs/examples/skill-simple-v1.txt](docs/examples/skill-simple-v1.txt)。支持浏览器提供“选择位置并保存”，其余提供普通下载，目录由浏览器控制。取消另存为不会自动下载；普通下载只确认发起，不假称落盘完成。

旧格式示例在 [testdata/legacy-with-notes.txt](testdata/legacy-with-notes.txt)。完整协议示例在 [docs/examples/full-v2.txt](docs/examples/full-v2.txt)。旧格式有固有歧义：正文或备注内的独立编号标题可能被识别为新条目。必须核对导入预览。完整协议用于无损保留已约定字段。

## 开发检查

前端使用 Node 22.12 以上的22系版本或本次实际验证的 Node 24。保留现有 `npm` 流程。

```text
npm ci
npm run lint
npx tsc -b
npm run build
npm run test -- --run
```

后端在 `server/` 执行：

```powershell
$env:PH_PRODUCTION='0'
$env:PH_LOCAL_HTTP='1'
$env:PH_DATA_DIR='隔离测试目录的绝对路径'
$env:PH_TEST_DB=Join-Path $env:PH_DATA_DIR 'team-test.sqlite3'
..\.venv\Scripts\python.exe manage.py test hub.tests --noinput
..\.venv\Scripts\python.exe manage.py makemigrations --check --dry-run
..\.venv\Scripts\python.exe manage.py check
```

测试目录必须已存在。框架只创建和删除明确指定的测试库，禁止指向运行数据库。真实 GitHub 测试需另设 `PH_LIVE_GITHUB=1`。10分钟容量检查需另设 `PH_LOAD_TEST=1`，并单独运行 `hub.tests.test_load`。未开启的测试显示跳过，不能计为通过。

新增后端测试使用真实组件。个人版历史测试包含 Mock，单独披露。不要把全部前端测试归类为无 Mock。

## 结构

```text
src/team/                 团队 View、状态编排和接口适配
server/hub/services.py    权限、双域版本和历史等业务规则
server/hub/exchange.py    完整及旧 TXT 协议
server/hub/github.py      固定公开 GitHub API、缓存及预算
server/hub/operations.py  事务、操作ID和写入回执
server/hub/backup.py      一致快照、加密与新目录恢复
deploy/                  未执行的目标部署模板
```

上线步骤、OpenClaw 保护边界和回退要求见 [deploy/README.md](deploy/README.md)。验证结果及未满足的门槛见 [docs/verification-v5.md](docs/verification-v5.md)。本地检查通过不等于云端、手机真机或异机备份验收通过。
