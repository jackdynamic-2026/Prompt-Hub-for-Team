# 提示词与技能分享库

面向小团队的 Prompt 与 Skills 资料分享平台。React/TypeScript 前端，Django/SQLite 后端。`/team/` 是团队共享库，`/` 保留浏览器本地个人版，两者数据不自动互通。

这是开源候选源码。项目许可证、第三方内容授权和正式安全报告渠道尚待确认；完成 [发布清单](docs/OPEN_SOURCE_CHECKLIST.md) 后再公开。

## 功能

- 管理员创建成员，用户名/密码登录；首次改密可选，支持个人无操作超时设置。
- Prompt 与 Skills 分开管理；按名称、标签、分享人、更新时间和收藏筛选。
- 共享备注、协作标签、历史版本、回收站及团队推荐。
- Skills 保存介绍、完整 GitHub 链接、仓库 Star 与心得，不存储或执行仓库代码。
- TXT 预览后确认导入；支持完整协议、Skill 简洁 TXT 和旧 Prompt TXT。
- 结构化日志、写入回执、登录限制及加密备份/恢复命令。

## 本地开发启动

推荐 Node.js 24 和 Python 3.13。当前本地验证环境是 Windows / Python 3.13.5 / Node 24；Linux、Python 3.12 的实际结果以 CI/部署验收为准。不要复用生产数据或 OpenClaw 的 Python 环境。

先在项目根目录构建前端：

```powershell
npm ci
npm run build
```

逐条执行以下 Windows PowerShell 命令；任何一步失败，先处理错误再继续：

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r server/requirements.lock.txt
$env:PH_PRODUCTION='0'
$env:PH_LOCAL_HTTP='1'
.\.venv\Scripts\python.exe server/manage.py migrate
.\.venv\Scripts\python.exe server/manage.py createsuperuser
.\.venv\Scripts\python.exe server/manage.py runserver 127.0.0.1:8891 --noreload
```

访问 `http://127.0.0.1:8891/team/`，使用刚创建的管理员登录。源码不附带真实数据库或预设生产账号。`runserver` 仅用于本地开发，不直接对公网开放。

默认数据目录为 `server/data/`；可通过绝对路径 `PH_DATA_DIR` 指定其他目录。启动前核对路径，避免连接错误的数据库。

## TXT 导入

先选格式，再点击“解析并预览”，核对完整正文、备注、标签及条目边界后确认。导入只创建副本。

旧 Prompt 标准标题须独占一行，例如 `1、技术审查：`；标题前留空行，文件开头除外。兼容模式允许既定旧式标题，但仍需人工核对。预览错误会弹窗并保留输入；更改文本、格式或预览失败后，旧确认失效。

旧格式无法无损还原独立标签、共同备注或账号权限。协议细节见 [API 与交换协议](docs/API.md)。

## 检查

```powershell
npx vitest run
npm run lint
npm run typecheck
npm run build
$env:PH_DATA_DIR="$PWD/server/test-data"
$env:PH_LOCAL_HTTP='1'
.\.venv\Scripts\python.exe server/manage.py check
.\.venv\Scripts\python.exe server/manage.py test hub.tests
```

Django 自动使用独立测试数据库；日志写入指定测试目录。新增 V11 测试使用真实解析器、Django/SQLite 和有硬截止的子进程，不使用 Mock。历史前端测试的模拟设施不计为 V11 真实验证。浏览器回归脚本见 `scripts/team-v5-browser.cjs`，需独立测试服务、数据目录与 Playwright。

## 部署、升级与安全

团队后端需要 Python 服务。GitHub Pages 只发布静态个人版或文档，不能运行 Django。

- [团队运行、备份与升级说明](README_TEAM.md)
- [部署模板](deploy/README.md)
- [Windows 部署说明](deploy/windows/README.md)
- [安全报告与支持边界](SECURITY.md)

升级前验证加密备份能恢复，在隔离副本运行迁移和回归。配置使用部署者生成的独立秘密。不要提交环境文件、生产配置、备份密钥、真实账号库或运行日志。云端部署单独验收，源码更新不会自动升级生产。
