# Windows 原生部署

适用路线：Python 3.13、Django、Waitress 3.0.2、本地 SQLite、Caddy HTTPS。前端构建已附带，生产机不要求 Node 或 Docker。参考文件中的磁盘、目录和域名必须按实际目标调整。

本次已在 Windows 上验证真实 Waitress 登录和本机 Caddy HTTPS 链路。公网 DNS、ACME 证书、目标机防火墙、Windows 服务安装及重启仍需现场验收。不要把本机通过当成公网已上线。

## 目录和权限

建议使用专用目录，例如 D:\PromptHub。代码放 app，数据放 private-data，Caddy 放 proxy，证书放 proxy-state，日志分开，备份另存并异机复制。SQLite 不放网络共享盘或云同步盘。

两个 WinSW XML 是配置模板，未自动安装服务。它们使用低权限 LocalService，不使用 LocalSystem。安装后分别启用 PromptHub 和 PromptHubProxy 的独立服务 SID，再把新建专用目录的权限赋给对应 SID。应用仅有代码读取和自身数据／日志写入权限；代理仅有自身配置读取、证书／代理日志写入权限。不要给整个 LocalService 身份或 Everyone 开放两个数据目录。不要递归修改已有项目或系统目录的权限。

仅在管理员已审核目标和权限后执行服务安装。WinSW 使用其官方发行包并独立核对版本及校验值；本包没有附带或安装 WinSW。服务包装器操作、服务 SID／ACL、注销／重启、故障恢复均需在目标机实际验证。

## 应用启动

1. 在 app 中建立独立虚拟环境，安装 server/requirements.lock.txt。Gunicorn 在 Windows 上会被环境标记跳过。
2. 已有数据库先停服务并执行加密备份。更改 PH_DATA_DIR 前核对实际数据路径。
3. 配置独立 PH_SECRET_KEY（至少50字符）、PH_OPERATION_EPOCH（至少32字符）、明确 PH_ALLOWED_HOSTS。
4. 设置 PH_PRODUCTION=1、PH_PROXY_MODE=waitress；不设置 PH_LOCAL_HTTP=1，不开启 DEBUG。
5. 运行 manage.py migrate --noinput，再运行 manage.py check --deploy --fail-level WARNING。当前该严格门槛仍报告W005／W021：未启用HSTS全子域和预加载。目标域名未确定，不能为消除警告就开启它们；先审核实际子域HTTPS范围及预加载策略，再复核部署门槛。未复核前不宣称公网验收通过。
6. 工作目录必须是 app/server。使用独立环境的 python -m config.windows_server。

后端固定监听127.0.0.1，默认18891，禁止把它直接对公网开放。Windows 模式由 Waitress 规范化受信任代理头，Django 和限流逻辑不会再次相信外部 X-Real-IP。应用不读取浏览器传来的用户ID来代投、改偏好或赋权。

服务配置内的 REPLACE 必须全部替换，配置文件不进入公开静态目录。密钥不写进聊天、命令历史或版本库。当前机器 C 盘使用率约95%，会触发生产85%停写保护；本次在使用率约82%的 D 盘隔离目录验证生产链路，没有放宽阈值。目标机器仍应重新检查磁盘。

## HTTPS 代理

Caddyfile.example 使用 PH_PUBLIC_HOST、PH_CADDY_DATA、PH_PROXY_LOG。证书目录必须持久、可写并受限；XDG_CONFIG_HOME／XDG_DATA_HOME 也放代理专用目录，避免后台服务使用意外的用户目录。

本次测试的 Caddy 来源及 SHA256 见 caddy-tested-source.json。下载后先验证官方发行包摘要，再验证配置：

```powershell
.\caddy.exe validate --config .\Caddyfile --adapter caddyfile
.\caddy.exe run --config .\Caddyfile --adapter caddyfile
```

生产使用真实域名与可信证书。确认 A／AAAA、80／443 入站、NAT／云安全组、Windows 防火墙及已有端口归属。仅为新站点添加必要规则，不停止其他应用，不修改 OpenClaw 主机。18891、数据库、密钥和Caddy管理端点不得对公网开放。

代理会覆盖客户端 IP／协议头，清除 X-Real-IP／Forwarded。请求体上限与应用42MiB外层请求和20MiB TXT限制协调；TXT增加转义后仍按实际HTTP字节验收。不要无限扩大限制。

日志保留路径、状态和应用返回的 X-Request-ID 响应头，删除原始查询串、请求头及 Set-Cookie，避免搜索内容或凭证落日志。应用 runtime.jsonl 和服务stderr也需收集、轮转、检查磁盘。后端请求入口记录不代表文件已保存到用户设备。

## 验收和恢复

- 从外网验证证书、登录、CSRF、活动续期、限流来源及后端不可直连。
- 验证服务账号、工作目录、重启／注销／故障恢复及正常停止，确认只启动一个应用实例。
- 加密备份先验证，再复制到独立目的地。任务计划程序创建成功不等于备份成功；告警接收端需明确配置。
- 恢复只允许新目录。恢复会清除会话、会话策略、回执和外部租约，推进认证版本，生成新运行纪元；内容、备注、标签和真实推荐关系保留。
- 回退代码保留新增表，禁止盲目向下迁移。旧代码可插入新库所需的数据库默认值已做真实验证，但回退会回到旧登录策略及旧标签行为，必须重新登录并再次核验功能。禁止新旧服务及前后端混跑。

可用 scripts/windows-https-check.py 在独立目录复现本机链路。它仅绑定回环地址，使用独立测试CA并验证证书，不安装系统信任；结束时只停止自己启动的进程。它不等于公网或Windows服务验收。

参考：[Waitress](https://docs.pylonsproject.org/projects/waitress/en/stable/)、[Caddy运行方式](https://caddyserver.com/docs/running)、[代理头](https://docs.pylonsproject.org/projects/waitress/en/stable/reverse-proxy.html)、[Caddy日志](https://caddyserver.com/docs/caddyfile/directives/log)、[WinSW](https://github.com/winsw/winsw)。
