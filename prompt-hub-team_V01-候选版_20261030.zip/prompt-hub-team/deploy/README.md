# 部署、备份与恢复

本目录是待现场核验的模板。没有在云主机执行。先确认系统、资源、域名、代理、端口、独立账号和备份目的地。截图曾显示 Ubuntu 22.04.5，但本次只读 SSH 连接未通过认证，不能据此确认当前系统。不要按早先“CentOS”的口述直接安装运行时。

## 1. 只读调查

逐项读取并保存结果，不修改既有服务：

```sh
cat /etc/os-release
uname -m
nproc
free -m
df -h
df -i
ss -lnt
docker version
```

还要记录现有代理配置路径、域名和证书流程。记录 OpenClaw 的服务状态、18789 转发和已知最小功能。命令以实际安装情况为准。不要猜测其服务名，不读取或复制其密钥。

准入：受支持的系统、独立目录及用户、空闲端口18891、足够内存和磁盘、可验证的备份及回退步骤。模板给本应用限制512MiB、0.5 CPU、64任务；这不是已验证的最小配置。主机没有余量时停止共机部署。不得为本应用重启 OpenClaw、升级其运行时或修改其目录权限。

## 2. 准备产物

有 Docker 时，优先用独立 Compose 项目。模板不挂载 Docker socket、OpenClaw 路径或其密钥。后端仅映射到 `127.0.0.1:18891`。若无 Docker，评估独立 Python 3.12 虚拟环境及 `prompt-hub.service.example`；不要直接替换系统 Python。旧 CentOS 的运行时、cgroup 和安全维护状态须另行确认。

进入本项目 `deploy/`。将 `.env.example` 复制为私有 `.env`。填入新的随机 `PH_SECRET_KEY`、至少32字符的 `PH_OPERATION_EPOCH` 和实际域名。生产禁止 DEBUG、通配 Host 和本地 HTTP 模式。不要将生产 `.env` 提交或放入交付包。

在本应用目录准备仅UID10001可写的数据目录。不得更改父目录或其他项目权限。先构建、检查配置、迁移，再启动；迁移只执行一次：

```sh
docker compose config --quiet
docker compose build
docker compose run --rm web python manage.py check --deploy
docker compose run --rm web python manage.py migrate --noinput
docker compose run --rm web python manage.py createsuperuser
docker compose up -d web
```

本机无 Docker，以上命令尚未验证。Gunicorn 为新后端依赖，版本锁在 `server/requirements.lock.txt`；Linux Gunicorn 不能由 Windows 开发服务器验收替代。[官方发行页](https://pypi.org/project/gunicorn/)

`check --deploy` 目前保留 W005、W021 两项警告：没有把 HSTS 扩展到所有子域，也没有开启预加载。尚未调查域名树，因此没有自动扩大影响范围或屏蔽警告。正式切流前由域名负责人确认策略。不能报告“严格部署检查全部通过”。

## 3. HTTPS 与切流

先保存现有代理配置。将 `nginx.example.conf` 合并为单独域名的站点，不替换默认站点或 OpenClaw 入口。更换实际证书路径。按实际网络确定唯一受信任代理IP；代理必须覆盖转发头，不能直接信任公网提交的 `X-Real-IP`。

检查代理配置后，仅对新站点做有界冒烟：HTTPS登录、两类读取、跨用户备注、越权拒绝、TXT预览和一次小文件下载。检查IPv4和IPv6暴露面。确认 OpenClaw 原有最小功能仍正常。发现资源压力或既有服务异常，停止新站点切流，只撤销本应用的变更。

代理日志必须记录实际传输状态、响应字节及应用 `X-Request-ID`，但不记录请求正文、Cookie或认证头。应用 `export_ready` 只表示已生成文件；用户可能取消下载。不要记录“用户保存成功”。

## 4. 一致备份

在受控运维终端生成32个随机字节的密钥文件，权限限本应用运维账号。密钥与备份分开保管，并在另一个可信位置保留恢复所需副本。密钥遗失无法解密。密钥不在TXT或应用ZIP内。

独立虚拟环境示例，在 `server/` 执行：

```sh
python manage.py hub_backup --output /独立备份目录/唯一名称.phbk --key-file /受控目录/backup.key
```

Compose 部署时在独立数据卷内指定输出路径，密钥以只读独立挂载提供；不要将宿主机路径误当容器内路径。命令用 SQLite backup API 创建一致快照，执行完整性及外键检查，再以AES-256-GCM流式加密，并重新解密核验。临时明文仅在私有目录存在；认证标签通过后才读取恢复数据库。[算法接口及完整性边界](https://cryptography.io/en/latest/hazmat/primitives/symmetric-encryption/)

本地成功事件是 `backup_local_verified`。它不是异机备份成功。另将加密文件传到已批准的独立主机，比较SHA256并在该机执行恢复验证。失败时保留上次成功备份并通知管理员。目的地与通知渠道未配置，所以当前没有异机备份或告警闭环。

每日备份、每日7份及每周4份的调度和保留策略须在目标环境配置并演练。此候选版没有自动删除备份。运维人员删除到期件前必须确认至少一份可恢复的成功备份。应用产物、依赖锁、非秘密配置模板和密钥保管说明也要纳入备份清单。

## 5. 恢复与回退

先停止本应用写入，保留现状数据库及应用产物。恢复只允许全新目录：

```sh
python manage.py hub_restore --input /备份路径/唯一名称.phbk --key-file /受控目录/backup.key --destination /全新恢复目录
```

命令拒绝覆盖已有目录或数据库。校验通过后清除旧会话、回执和租约，提高账号认证版本，并生成 `operation_epoch.txt`。将该文件中的新epoch写入受控运行配置；保留原SECRET_KEY。不要把旧epoch改回去。

恢复命令不会自动切流。使用匹配版本的应用，对新库执行迁移检查及账号、权限、条目、备注、标签、历史、审计和删除状态验证。说明备份点之后可能丢失的写入时间段。验证通过后才调整本应用数据挂载并开放入口；最后复验OpenClaw最小功能。

升级前保存产物摘要和一致备份，停写并排空请求，单次迁移。结构兼容时可回退旧应用产物；不兼容时恢复匹配的数据库和应用。不得删卷回退。RPO24小时及RTO2小时仍是目标，尚无目标机演练证据。

## 6. 运行维护

`/healthz/` 只返回服务状态。监控应每5分钟检查HTTPS入口、应用空间、日志心跳、最近一次异机成功备份及OpenClaw基线。75%磁盘使用率告警，生产85%停业务写入，并检查剩余字节和inode。配置实际通知渠道前，不宣称告警送达。

运行日志轮转并按14天及约100MiB总预算清理。审计保留90天。受控任务可先预览，再执行清理：

```sh
python manage.py hub_maintenance
python manage.py hub_maintenance --apply
```

清理不删除条目、用户或备份。过期回执只清空结果，保留操作ID和摘要墓碑，防止迟到的旧请求重新创建副本。不要擅自清空回执表。数据库压缩及清理备份不自动执行。

账号被恶意触发冷却时，受控终端可执行 `python manage.py hub_unlock --username 实际用户名`，只解除该账号冷却，保留IP限流。口令重置走管理员接口；不要在公开日志写入新口令。
