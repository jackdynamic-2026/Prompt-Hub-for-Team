import { type Prompt } from '../data/defaultPrompts';
import { v4 as uuidv4 } from 'uuid';

export function extractVariables(text: string): string[] {
  const regex = /【(.*?)】/g;
  const matches = [...text.matchAll(regex)];
  // Use Set to ensure uniqueness
  return Array.from(new Set(matches.map(m => m[1])));
}

export function applyVariables(text: string, values: Record<string, string>): string {
  let result = text;
  for (const [key, value] of Object.entries(values)) {
    // Replace all instances of 【key】 with the value
    const regex = new RegExp(`【${key}】`, 'g');
    result = result.replace(regex, value);
  }
  return result;
}

export type ImportMode = 'standard' | 'compatibility';

export interface ImportEntry extends Prompt {
  sourceLine: number;
  number: number;
}

export interface ImportIssue {
  code: 'numbering' | 'empty-content' | 'preamble' | 'compatibility';
  line: number;
  raw: string;
  message: string;
}

export function analyzeTxtImport(txtContent: string, mode: ImportMode = 'standard'): {
  entries: ImportEntry[];
  issues: ImportIssue[];
} {
  const lines = txtContent.replace(/^\uFEFF/, '').replace(/\r\n?/g, '\n').split('\n');
  const entries: ImportEntry[] = [];
  const issues: ImportIssue[] = [];
  const headerRegex = mode === 'standard'
    ? /^\s*(\d+)\s*、\s*(.+?)[：:]\s*$/
    : /^\s*(\d+)\s*[、.]\s*(.+?)[：:]?\s*$/;
  let current: ImportEntry | null = null;
  let content: string[] = [];
  let preambleLine: number | null = null;

  const finish = () => {
    if (!current) return;
    current.content = content.join('\n').trim();
    entries.push(current);
    if (!current.content) {
      issues.push({ code: 'empty-content', line: current.sourceLine,
        raw: lines[current.sourceLine - 1], message: '该标题下没有正文，请检查是否误拆。' });
    }
  };

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const match = line.match(headerRegex);
    // Both modes require a paragraph boundary; whitespace alone cannot classify a heading.
    const boundary = i === 0 || lines[i - 1].trim() === '';
    if (match && match[2].trim() && boundary) {
      finish();
      const number = Number(match[1]);
      if (!Number.isSafeInteger(number) || number < 1 || (current && number !== current.number + 1)) {
        issues.push({ code: 'numbering', line: i + 1, raw: line,
          message: '编号重复、倒退、跳号或无效，请核对该行是否为新标题。' });
      }
      if (mode === 'compatibility') {
        issues.push({ code: 'compatibility', line: i + 1, raw: line,
          message: '兼容模式使用宽松标题规则，请核对是否把正文编号识别成标题。' });
      }
      current = { id: uuidv4(), title: match[2].trim(), content: '',
        tags: ['导入'], isFavorite: false, sourceLine: i + 1, number };
      content = [];
    } else if (current) {
      content.push(line);
    } else if (line.trim() && preambleLine === null) {
      preambleLine = i;
    }
  }
  finish();
  if (preambleLine !== null) {
    issues.unshift({ code: 'preamble', line: preambleLine + 1, raw: lines[preambleLine],
      message: '首个标题前的文字不会导入，请移入正文或确认可以忽略。' });
  }
  return { entries, issues };
}

export function parseTxtToPrompts(txtContent: string, mode: ImportMode = 'standard'): Prompt[] {
  return analyzeTxtImport(txtContent, mode).entries.map(p => ({
    id: p.id, title: p.title, content: p.content, tags: p.tags, isFavorite: p.isFavorite,
  }));
}

export function formatPromptsToTxt(prompts: Prompt[]): string {
  return prompts.map((prompt, index) => {
    return `${index + 1}、${prompt.title}：\n${prompt.content}`;
  }).join('\n\n');
}
