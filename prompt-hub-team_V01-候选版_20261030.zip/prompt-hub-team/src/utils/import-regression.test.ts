/// <reference types="node" />
import { readFileSync } from 'node:fs';
import { describe, it, expect } from 'vitest';
import { defaultPrompts } from '../data/defaultPrompts';
import { analyzeTxtImport, parseTxtToPrompts, formatPromptsToTxt } from './parser';

describe('TXT import boundaries (real parser, no mocks)', () => {
  it('imports the readable export notes literally into the old personal prompt body', () => {
    const source = readFileSync('testdata/legacy-with-notes.txt', 'utf8');
    const entries = parseTxtToPrompts(source);
    expect(entries.map(p => p.title)).toEqual(['技术方案对抗性审查', '需求澄清助手']);
    expect(entries[0].content).toBe('请区分事实、推断和假设。\n找出最强反例，并给出验证方法。\n我的方案是：【方案】。\n{备注：先核验关键证据，再形成结论。}');
    expect(entries[1].content).toBe('请先列出影响实施的关键歧义，再集中提问。\n{备注：记录尚未确认的需求。}');
  });
  it('preserves all 13 original titles and complete bodies', () => {
    const source = readFileSync('testdata/卡兹克常用提示词.txt', 'utf8');
    expect(parseTxtToPrompts(source).map(({ title, content }) => ({ title, content })))
      .toEqual(defaultPrompts.map(({ title, content }) => ({ title, content: content.replace(/\r\n?/g, '\n') })));
  });

  it.each(['1.正文要求。', '1、正文要求。', '1. 正文要求：'])('keeps %s after a blank line in the body', (line) => {
    const source = `1、钢人论证：\n正文\n\n${line}\n继续正文\n\n2、问诊：\n第二条正文`;
    const prompts = parseTxtToPrompts(source);
    expect(prompts).toHaveLength(2);
    expect(prompts[0].content).toBe(`正文\n\n${line}\n继续正文`);
  });

  it('requires a blank boundary and colon in standard mode', () => {
    expect(parseTxtToPrompts('1、标题：\n正文\n2、正文小标题：\n继续正文')).toHaveLength(1);
    expect(parseTxtToPrompts('1、无冒号\n正文')).toEqual([]);
    expect(parseTxtToPrompts('1. 点号标题：\n正文')).toEqual([]);
  });

  it('supports the old mixed format only in explicit compatibility mode', () => {
    const source = '3、无冒号\n正文\n\n4. 点号标题:\n第二段';
    expect(parseTxtToPrompts(source, 'compatibility').map(p => p.title)).toEqual(['无冒号', '点号标题']);
    expect(analyzeTxtImport(source, 'compatibility').issues.length).toBeGreaterThan(0);
  });

  it.each(['\n', '\r\n', '\r'])('normalizes BOM and line endings %j with accurate line numbers', (eol) => {
    const source = ['\uFEFF1、标题:', '正文', '', '2、标题二：', '正文二'].join(eol);
    const report = analyzeTxtImport(source);
    expect(report.entries.map(p => p.sourceLine)).toEqual([1, 4]);
    expect(report.entries.map(p => p.content)).toEqual(['正文', '正文二']);
    expect(report.issues).toEqual([]);
  });

  it.each(['1', '0', '4'])('flags repeated, reversed or skipped number %s without discarding it', (number) => {
    const report = analyzeTxtImport(`1、标题：\n正文\n\n${number}、注意事项：\n内容`);
    expect(report.entries).toHaveLength(2);
    expect(report.issues).toEqual(expect.arrayContaining([expect.objectContaining({ line: 4, raw: `${number}、注意事项：` })]));
  });

  it('flags empty content and preamble instead of silently hiding them', () => {
    const report = analyzeTxtImport('说明文字\n\n1、标题：\n\n2、标题二：\n正文');
    expect(report.issues.map(issue => issue.code)).toEqual(expect.arrayContaining(['preamble', 'empty-content']));
  });

  it('exposes an indistinguishable sequential body heading for manual preview', () => {
    const report = analyzeTxtImport('1、标题：\n正文\n\n2、正文小标题：\n说明');
    expect(report.entries.map(p => [p.title, p.sourceLine, p.content])).toEqual([
      ['标题', 1, '正文'], ['正文小标题', 4, '说明'],
    ]);
  });

  it('round-trips exported titles and full bodies', () => {
    const source = defaultPrompts.map(p => ({ ...p, content: p.content.replace(/\r\n?/g, '\n') }));
    expect(parseTxtToPrompts(formatPromptsToTxt(source)).map(({ title, content }) => ({ title, content })))
      .toEqual(source.map(({ title, content }) => ({ title, content })));
  });
});
