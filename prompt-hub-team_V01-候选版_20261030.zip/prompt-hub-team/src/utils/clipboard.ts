export interface CopyResult {
  success: boolean;
  isFallback: boolean;
}

/**
 * Dual-layer Clipboard Strategy
 * 优先尝试新版的 navigator.clipboard API，
 * 若在 HTTP 环境（非安全上下文）下抛出异常或不存在，则降级使用 execCommand + DOM Range。
 * 
 * @param text 要复制的文本
 * @returns 返回包含成功状态与是否使用了降级方案的对象
 */
export async function copyToClipboard(text: string): Promise<CopyResult> {
  // 1. 尝试前锋：现代化剪贴板 API (仅限 HTTPS / localhost)
  if (navigator.clipboard && navigator.clipboard.writeText) {
    try {
      await navigator.clipboard.writeText(text);
      return { success: true, isFallback: false };
    } catch (err) {
      // 捕获异常（例如因权限拒绝或浏览器策略阻止），继续流转到后卫逻辑
      console.warn('navigator.clipboard failed, falling back to execCommand:', err);
    }
  }

  // 2. 尝试后卫：传统降级 Fallback (支持 HTTP 局域网的手机环境)
  // 使用纯文本节点和 DOM Selection API 穿透 Android/iOS 视口防御
  const span = document.createElement('span');
  span.textContent = text;
  
  // 保持换行符和空格
  span.style.whiteSpace = 'pre';
  span.style.webkitUserSelect = 'auto';
  span.style.userSelect = 'all';

  // 放置在物理视口内，但彻底隐身，避免阻断用户的物理点击和影响排版
  span.style.position = 'absolute';
  span.style.top = '0px';
  span.style.left = '0px';
  span.style.opacity = '0';
  span.style.pointerEvents = 'none';
  
  document.body.appendChild(span);

  // 精准圈选文本节点
  const selection = window.getSelection();
  const range = document.createRange();
  
  let successful = false;
  try {
    if (selection) {
      selection.removeAllRanges();
      range.selectNode(span);
      selection.addRange(range);
      
      // 执行复制指令
      successful = document.execCommand('copy');
    }
  } catch (err) {
    console.error('Fallback execCommand failed:', err);
  } finally {
    // 强制打扫战场，防止选区蓝屏高亮残留和 DOM 泄漏
    if (selection) {
      selection.removeAllRanges();
    }
    document.body.removeChild(span);
  }
  
  return { success: successful, isFallback: true };
}
