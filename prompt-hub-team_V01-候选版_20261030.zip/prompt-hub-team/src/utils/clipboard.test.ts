import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { copyToClipboard } from './clipboard';

describe('Clipboard Utility (Equivalence Classes)', () => {
  let originalClipboard: any;
  let originalExecCommand: any;

  beforeEach(() => {
    // Save original implementations
    originalClipboard = navigator.clipboard;
    originalExecCommand = document.execCommand;
    
    // Mock getSelection and createRange for the fallback test
    window.getSelection = vi.fn().mockReturnValue({
      removeAllRanges: vi.fn(),
      addRange: vi.fn(),
    });
    document.createRange = vi.fn().mockReturnValue({
      selectNode: vi.fn(),
    } as any);
  });

  afterEach(() => {
    // Restore implementations
    Object.defineProperty(navigator, 'clipboard', {
      value: originalClipboard,
      configurable: true,
    });
    document.execCommand = originalExecCommand;
    
    // @ts-ignore
    delete window.getSelection;
    // @ts-ignore
    delete document.createRange;
    
    vi.restoreAllMocks();
  });

  it('State 1: navigator.clipboard exists and succeeds (HTTPS/Modern)', async () => {
    const writeTextMock = vi.fn().mockResolvedValue(undefined);
    Object.defineProperty(navigator, 'clipboard', {
      value: { writeText: writeTextMock },
      configurable: true,
    });
    
    // We shouldn't need execCommand in this state
    document.execCommand = vi.fn().mockReturnValue(true);

    const result = await copyToClipboard('test string');
    
    expect(writeTextMock).toHaveBeenCalledWith('test string');
    expect(document.execCommand).not.toHaveBeenCalled();
    expect(result).toEqual({ success: true, isFallback: false });
  });

  it('State 2: navigator.clipboard exists but rejects (e.g. permission denied) -> should fallback', async () => {
    const writeTextMock = vi.fn().mockRejectedValue(new Error('Permission denied'));
    Object.defineProperty(navigator, 'clipboard', {
      value: { writeText: writeTextMock },
      configurable: true,
    });
    
    const execCommandSpy = vi.fn().mockReturnValue(true);
    document.execCommand = execCommandSpy;

    const result = await copyToClipboard('test string');
    
    expect(writeTextMock).toHaveBeenCalledWith('test string');
    expect(execCommandSpy).toHaveBeenCalledWith('copy');
    expect(result).toEqual({ success: true, isFallback: true }); // Since fallback succeeds
  });

  it('State 3: navigator.clipboard is undefined (HTTP/Legacy) -> should fallback directly', async () => {
    Object.defineProperty(navigator, 'clipboard', {
      value: undefined,
      configurable: true,
    });
    
    const execCommandSpy = vi.fn().mockReturnValue(true);
    document.execCommand = execCommandSpy;

    const result = await copyToClipboard('test string');
    
    expect(execCommandSpy).toHaveBeenCalledWith('copy');
    expect(result).toEqual({ success: true, isFallback: true });
  });

  it('State 4: both navigator.clipboard and fallback fail', async () => {
    Object.defineProperty(navigator, 'clipboard', {
      value: undefined,
      configurable: true,
    });
    
    // execCommand returns false when it fails
    const execCommandSpy = vi.fn().mockReturnValue(false);
    document.execCommand = execCommandSpy;

    const result = await copyToClipboard('test string');
    
    expect(execCommandSpy).toHaveBeenCalledWith('copy');
    expect(result).toEqual({ success: false, isFallback: true });
  });
});
