import { describe, it, expect, beforeEach, vi } from 'vitest';
import { getPrompts, savePrompt, deletePrompt, toggleFavorite, appendPrompts } from './storage';
import { defaultPrompts } from '../data/defaultPrompts';

// Mock localStorage
const localStorageMock = (() => {
  let store: Record<string, string> = {};
  return {
    getItem: vi.fn((key: string) => store[key] || null),
    setItem: vi.fn((key: string, value: string) => {
      store[key] = value.toString();
    }),
    removeItem: vi.fn((key: string) => {
      delete store[key];
    }),
    clear: vi.fn(() => {
      store = {};
    }),
  };
})();

Object.defineProperty(window, 'localStorage', {
  value: localStorageMock,
});

describe('Storage Manager', () => {
  beforeEach(() => {
    localStorageMock.clear();
    vi.clearAllMocks();
  });

  it('getPrompts should return defaultPrompts when localStorage is empty', () => {
    const prompts = getPrompts();
    expect(prompts).toEqual(defaultPrompts);
  });

  it('savePrompt should add a new prompt', () => {
    const newPrompt = {
      id: 'test-1',
      title: 'Test Prompt',
      content: 'This is a test',
      tags: [],
      isFavorite: false,
    };
    savePrompt(newPrompt);
    const prompts = getPrompts();
    expect(prompts).toContainEqual(newPrompt);
    expect(prompts.length).toBe(defaultPrompts.length + 1);
  });

  it('savePrompt should update an existing prompt', () => {
    const newPrompt = {
      id: 'test-2',
      title: 'Original Title',
      content: 'Content',
      tags: [],
      isFavorite: false,
    };
    savePrompt(newPrompt);
    
    const updatedPrompt = { ...newPrompt, title: 'Updated Title' };
    savePrompt(updatedPrompt);
    
    const prompts = getPrompts();
    expect(prompts.find(p => p.id === 'test-2')?.title).toBe('Updated Title');
    expect(prompts.filter(p => p.id === 'test-2').length).toBe(1);
  });

  it('deletePrompt should remove a prompt by id', () => {
    const newPrompt = {
      id: 'test-3',
      title: 'To Delete',
      content: 'Content',
      tags: [],
      isFavorite: false,
    };
    savePrompt(newPrompt);
    deletePrompt('test-3');
    const prompts = getPrompts();
    expect(prompts.find(p => p.id === 'test-3')).toBeUndefined();
  });

  it('toggleFavorite should toggle the isFavorite flag', () => {
    const newPrompt = {
      id: 'test-4',
      title: 'Favorite Test',
      content: 'Content',
      tags: [],
      isFavorite: false,
    };
    savePrompt(newPrompt);
    toggleFavorite('test-4');
    expect(getPrompts().find(p => p.id === 'test-4')?.isFavorite).toBe(true);
    
    toggleFavorite('test-4');
    expect(getPrompts().find(p => p.id === 'test-4')?.isFavorite).toBe(false);
  });
  it('appendPrompts should append multiple prompts to the end', () => {
    const newPrompts = [
      { id: 'test-5', title: 'Batch 1', content: 'Content', tags: [], isFavorite: false },
      { id: 'test-6', title: 'Batch 2', content: 'Content', tags: [], isFavorite: false }
    ];
    // Cast to any to bypass strict type for test if needed, or import appendPrompts
    appendPrompts(newPrompts);
    const prompts = getPrompts();
    expect(prompts[prompts.length - 2].title).toBe('Batch 1');
    expect(prompts[prompts.length - 1].title).toBe('Batch 2');
    expect(prompts.length).toBe(defaultPrompts.length + 2);
  });
});
import { getHistory, logHistory } from './storage';

describe('History Manager (State Transition & Equivalence Classes)', () => {
  beforeEach(() => {
    localStorageMock.clear();
    vi.clearAllMocks();
  });

  it('State 0: getHistory should return empty array initially', () => {
    expect(getHistory()).toEqual([]);
  });

  it('State 1: Logging a new id should add it to the top', () => {
    logHistory('A');
    expect(getHistory()).toEqual(['A']);
  });

  it('State 2: Logging multiple new ids should maintain LIFO order (latest at index 0)', () => {
    logHistory('A');
    logHistory('B');
    expect(getHistory()).toEqual(['B', 'A']);
  });

  it('State 3: Logging an existing id should deduplicate and move it to the top', () => {
    logHistory('A');
    logHistory('B');
    logHistory('C');
    // Current state: ['C', 'B', 'A']
    logHistory('B'); // Log existing 'B'
    // Expected state: ['B', 'C', 'A']
    expect(getHistory()).toEqual(['B', 'C', 'A']);
  });

  it('State 4 (Boundary): History length should not exceed max capacity (10)', () => {
    // Fill with 10 items (0 to 9)
    for (let i = 0; i < 10; i++) {
      logHistory(`id-${i}`);
    }
    expect(getHistory().length).toBe(10);
    // The top should be 'id-9', the bottom should be 'id-0'
    expect(getHistory()[0]).toBe('id-9');
    expect(getHistory()[9]).toBe('id-0');

    // Trigger eviction: log 11th item
    logHistory('id-10');
    
    // Length must remain 10
    expect(getHistory().length).toBe(10);
    // 'id-10' should be at the top
    expect(getHistory()[0]).toBe('id-10');
    // The oldest 'id-0' should be evicted, so the new bottom is 'id-1'
    expect(getHistory()[9]).toBe('id-1');
  });
});
