import { defaultPrompts, type Prompt } from '../data/defaultPrompts';
import { v4 as uuidv4 } from 'uuid';

const STORAGE_KEY = 'prompt-hub-data';

export function getPrompts(): Prompt[] {
  const data = localStorage.getItem(STORAGE_KEY);
  if (!data) {
    // Initialize with defaults if empty
    localStorage.setItem(STORAGE_KEY, JSON.stringify(defaultPrompts));
    // Return a copy to avoid mutating the original defaultPrompts reference
    return JSON.parse(JSON.stringify(defaultPrompts));
  }
  try {
    return JSON.parse(data) as Prompt[];
  } catch (e) {
    console.error('Failed to parse local storage data', e);
    return defaultPrompts;
  }
}

export function savePrompt(prompt: Prompt): void {
  const prompts = getPrompts();
  const index = prompts.findIndex(p => p.id === prompt.id);
  if (index >= 0) {
    prompts[index] = prompt;
  } else {
    // If no ID, assign one
    if (!prompt.id) {
      prompt.id = uuidv4();
    }
    prompts.push(prompt);
  }
  localStorage.setItem(STORAGE_KEY, JSON.stringify(prompts));
}

export function deletePrompt(id: string): void {
  const prompts = getPrompts();
  const filtered = prompts.filter(p => p.id !== id);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(filtered));
}

export function appendPrompts(newPrompts: Prompt[]): void {
  const prompts = getPrompts();
  prompts.push(...newPrompts);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(prompts));
}

export function toggleFavorite(id: string): void {
  const prompts = getPrompts();
  const prompt = prompts.find(p => p.id === id);
  if (prompt) {
    prompt.isFavorite = !prompt.isFavorite;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(prompts));
  }
}

const HISTORY_KEY = 'prompt-hub-history';

export function getHistory(): string[] {
  const data = localStorage.getItem(HISTORY_KEY);
  return data ? JSON.parse(data) : [];
}

export function logHistory(id: string): void {
  let history = getHistory();
  // Remove if exists to push to top
  history = history.filter(item => item !== id);
  // Add to top
  history.unshift(id);
  // Keep only last 10
  if (history.length > 10) {
    history = history.slice(0, 10);
  }
  localStorage.setItem(HISTORY_KEY, JSON.stringify(history));
}
