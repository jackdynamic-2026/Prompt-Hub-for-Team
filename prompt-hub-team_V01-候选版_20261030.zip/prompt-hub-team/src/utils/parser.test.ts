import { describe, it, expect } from 'vitest';
import { extractVariables, applyVariables, parseTxtToPrompts, formatPromptsToTxt } from './parser';

describe('Prompt Variable Parser (Equivalence Classes)', () => {
  it('should return empty array for text without variables', () => {
    const text = 'Hello world, this is a test.';
    expect(extractVariables(text)).toEqual([]);
  });

  it('should extract a single variable', () => {
    const text = 'Hello 【Name】';
    expect(extractVariables(text)).toEqual(['Name']);
  });

  it('should extract multiple distinct variables', () => {
    const text = 'Hello 【Name】, you are 【Age】 years old.';
    expect(extractVariables(text)).toEqual(['Name', 'Age']);
  });

  it('should extract unique variables even if they appear multiple times', () => {
    const text = 'Hello 【Name】, are you really 【Name】?';
    expect(extractVariables(text)).toEqual(['Name']);
  });

  it('should handle empty brackets as a variable with empty label', () => {
    const text = 'Hello 【】';
    expect(extractVariables(text)).toEqual(['']);
  });
});

describe('Apply Variables to Text', () => {
  it('should replace variables with provided values', () => {
    const text = 'Hello 【Name】, you are 【Age】 years old.';
    const values = { Name: 'Alice', Age: '30' };
    expect(applyVariables(text, values)).toBe('Hello Alice, you are 30 years old.');
  });

  it('should replace all instances of a repeated variable', () => {
    const text = 'Hello 【Name】, are you really 【Name】?';
    const values = { Name: 'Alice' };
    expect(applyVariables(text, values)).toBe('Hello Alice, are you really Alice?');
  });

  it('should keep the original variable syntax if value is not provided', () => {
    const text = 'Hello 【Name】, you are 【Age】 years old.';
    const values = { Name: 'Alice' }; // Age is missing
    expect(applyVariables(text, values)).toBe('Hello Alice, you are 【Age】 years old.');
  });
});

describe('TXT File Parser (Equivalence Classes)', () => {
  it('should correctly parse a well-formatted TXT file', () => {
    const rawTxt = `
1、第一条提示词：
这是第一条的内容。
可以换行。

2. 第二条提示词:
这是第二条的内容。
`;
    const result = parseTxtToPrompts(rawTxt, 'compatibility');
    expect(result).toHaveLength(2);
    expect(result[0].title).toBe('第一条提示词');
    expect(result[0].content).toContain('这是第一条的内容。');
    expect(result[1].title).toBe('第二条提示词');
    expect(result[1].content).toContain('这是第二条的内容。');
  });

  it('should ignore empty or invalid headers before the first prompt', () => {
    const rawTxt = `
普通的废话不应该被当成提示词。

1、 正常的提示词:
正常内容
`;
    const result = parseTxtToPrompts(rawTxt);
    expect(result).toHaveLength(1);
    expect(result[0].title).toBe('正常的提示词');
  });

  it('should handle headers without colons', () => {
    const rawTxt = `
3、无冒号的提示词
直接写内容。
`;
    const result = parseTxtToPrompts(rawTxt, 'compatibility');
    expect(result).toHaveLength(1);
    expect(result[0].title).toBe('无冒号的提示词');
  });
});

describe('Export Prompts to TXT', () => {
  it('should format prompts correctly into a txt string', () => {
    // We test formatPromptsToTxt
    const prompts = [
      { id: '1', title: '提示词一', content: '这是内容一\n可以换行', tags: [], isFavorite: false },
      { id: '2', title: '提示词二', content: '内容二', tags: [], isFavorite: false }
    ];
    
    const expectedOutput = 
`1、提示词一：
这是内容一
可以换行

2、提示词二：
内容二`;

    expect(formatPromptsToTxt(prompts)).toBe(expectedOutput);
  });
  
  it('should return empty string for empty array', () => {
    expect(formatPromptsToTxt([])).toBe('');
  });
});
