import { describe, it, expect, beforeEach, vi } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import App from './App';
import * as storage from './utils/storage';
import { defaultPrompts } from './data/defaultPrompts';
import { copyToClipboard } from './utils/clipboard';

vi.mock('./utils/clipboard', () => ({
  copyToClipboard: vi.fn(),
}));

// Mock clipboard API
Object.assign(navigator, {
  clipboard: {
    writeText: vi.fn().mockImplementation(() => Promise.resolve()),
  },
});

describe('App Integration Tests', () => {
  beforeEach(() => {
    localStorage.clear();
    vi.clearAllMocks();
    vi.spyOn(storage, 'getPrompts').mockReturnValue(defaultPrompts.slice(0, 3)); // Use only 3 for easier testing
    vi.spyOn(window, 'alert').mockImplementation(() => {});
    (copyToClipboard as any).mockResolvedValue({ success: true, isFallback: false });
  });

  it('renders the header and a list of prompts', () => {
    render(<App />);
    expect(screen.getAllByText('Prompt Hub').length).toBeGreaterThan(0);
    expect(screen.getByPlaceholderText('搜索提示词名称或内容...')).toBeInTheDocument();
    
    // Check if the first prompt title is rendered
    expect(screen.getByText(defaultPrompts[0].title)).toBeInTheDocument();
  });

  it('filters prompts based on search input', () => {
    render(<App />);
    const searchInput = screen.getByPlaceholderText('搜索提示词名称或内容...');
    
    // Search for something that only matches the second prompt
    fireEvent.change(searchInput, { target: { value: defaultPrompts[1].title } });
    
    expect(screen.getByText(defaultPrompts[1].title)).toBeInTheDocument();
    expect(screen.queryByText(defaultPrompts[0].title)).not.toBeInTheDocument();
  });

  it('navigates to prompt details when a card is clicked', () => {
    render(<App />);
    const firstPromptCard = screen.getByText(defaultPrompts[0].title);
    fireEvent.click(firstPromptCard);
    
    // Detail view should now be visible
    expect(screen.getAllByText('返回').length).toBeGreaterThan(0);
    expect(screen.getByText('复制生成结果')).toBeInTheDocument();
  });

  it('can delete a prompt from detail view', () => {
    vi.spyOn(window, 'confirm').mockImplementation(() => true);
    const deleteSpy = vi.spyOn(storage, 'deletePrompt');
    render(<App />);
    
    const firstPromptCard = screen.getByText(defaultPrompts[0].title);
    fireEvent.click(firstPromptCard);
    
    const deleteButton = screen.getByText('删除此提示词');
    fireEvent.click(deleteButton);
    
    expect(window.confirm).toHaveBeenCalled();
    expect(deleteSpy).toHaveBeenCalledWith(defaultPrompts[0].id);
  });

  it('can open import modal and import txt', async () => {
    const appendSpy = vi.spyOn(storage, 'appendPrompts');
    render(<App />);
    
    // There should be an import button
    const importBtn = screen.getByText('导入 TXT');
    fireEvent.click(importBtn);
    
    // Modal should appear
    expect(screen.getByText('批量导入提示词')).toBeInTheDocument();
    
    const textarea = screen.getByPlaceholderText(/粘贴您的 txt/i);
    fireEvent.change(textarea, { target: { value: '1、测试导入：\n内容测试' } });
    
    // Preview should update
    expect(screen.getByText('待导入列表 (预览)')).toBeInTheDocument();
    expect(screen.getByText('1. 测试导入')).toBeInTheDocument();
    
    const confirmBtn = screen.getByText('确认追加导入 (1条)');
    expect(confirmBtn).toBeDisabled();
    fireEvent.click(screen.getByLabelText('我已核对标题边界和完整正文'));
    fireEvent.click(confirmBtn);
    
    expect(appendSpy).toHaveBeenCalled();
  });

  it('can open create modal and add a single new prompt', () => {
    const saveSpy = vi.spyOn(storage, 'savePrompt');
    render(<App />);
    
    // Find the FAB button (has a lucide-plus icon inside, but we can query by some role or class)
    // Since it's a button without text, we can add aria-label or just query by class/icon
    // Let's assume we add aria-label="新建提示词"
    const addBtn = screen.getByLabelText('新建提示词');
    fireEvent.click(addBtn);
    
    expect(screen.getByText('新建单个提示词')).toBeInTheDocument();
    
    // Fill the form
    fireEvent.change(screen.getByPlaceholderText('给您的提示词起个名字...'), { target: { value: '测试新建' } });
    fireEvent.change(screen.getByPlaceholderText('正文内容（支持【变量】语法）...'), { target: { value: '你好，【世界】' } });
    
    fireEvent.click(screen.getByText('保存提示词'));
    
    expect(saveSpy).toHaveBeenCalledWith(expect.objectContaining({
      title: '测试新建',
      content: '你好，【世界】'
    }));
  });

  it('can trigger export', () => {
    const createObjectURLSpy = vi.spyOn(window.URL, 'createObjectURL').mockReturnValue('blob:test');
    const revokeObjectURLSpy = vi.spyOn(window.URL, 'revokeObjectURL').mockImplementation(() => {});
    
    render(<App />);
    
    const exportBtn = screen.getByText('导出 TXT');
    fireEvent.click(exportBtn);
    
    expect(createObjectURLSpy).toHaveBeenCalled();
    expect(revokeObjectURLSpy).toHaveBeenCalled();
  });

  it('can enter edit mode and save changes to a prompt', () => {
    const saveSpy = vi.spyOn(storage, 'savePrompt');
    render(<App />);
    
    // Select a prompt to enter detail view
    const card = screen.getByText('钢人论证');
    fireEvent.click(card);
    
    // Enter edit mode
    const editBtn = screen.getByLabelText('编辑提示词');
    fireEvent.click(editBtn);
    
    // Check if input fields are present with correct initial values
    const titleInput = screen.getByDisplayValue('钢人论证');
    const contentTextarea = screen.getByPlaceholderText('输入提示词正文...');
    expect(titleInput).toBeInTheDocument();
    expect(contentTextarea).toBeInTheDocument();
    
    // Change values
    fireEvent.change(titleInput, { target: { value: '钢人论证(修改版)' } });
    fireEvent.change(contentTextarea, { target: { value: '修改后的正文，保留【变量】' } });
    
    // Save
    const saveBtn = screen.getByText('保存修改');
    fireEvent.click(saveBtn);
    
    // Assert storage was called
    expect(saveSpy).toHaveBeenCalledWith(expect.objectContaining({
      title: '钢人论证(修改版)',
      content: '修改后的正文，保留【变量】'
    }));
    
    // Should exit edit mode
    expect(screen.getByText('钢人论证(修改版)')).toBeInTheDocument();
  });

  it('shows manual copy modal when copyToClipboard uses fallback', async () => {
    // Override the mock for this specific test
    (copyToClipboard as any).mockResolvedValue({ success: true, isFallback: true });
    
    render(<App />);
    
    // Open detail
    const card = screen.getByText(defaultPrompts[0].title);
    fireEvent.click(card);
    
    // Click copy
    const copyBtn = screen.getByText('复制生成结果');
    fireEvent.click(copyBtn);
    
    // Assert modal is shown (since state update is async, use findByText or wait)
    const modalTitle = await screen.findByText('手动复制兜底');
    expect(modalTitle).toBeInTheDocument();
    
    // Assert the textarea is pre-filled and readonly
    const textarea = document.querySelector('.modal-textarea');
    expect(textarea).toBeInTheDocument();
    expect(textarea).toHaveAttribute('readonly');
    
    // Close the modal
    const closeBtn = screen.getByText('我已复制完毕');
    fireEvent.click(closeBtn);
    
    expect(screen.queryByText('手动复制兜底')).not.toBeInTheDocument();
  });
});
