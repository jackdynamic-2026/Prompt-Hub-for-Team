import { useCallback, useEffect, useRef, useState } from 'react';
import { APIError } from './model';
import type { DeletedEntry, Entry, EntryInput, Filters, Kind, ManagedMember, Member, Preview, Revision } from './model';
import { clearPending, exportText, intent, mutate, rememberOperation, operationStatus, readText, request, saveText, chooseSaveTarget, writeTarget, localSaveEvent, sessionContext, rebindSessionContext } from './api';
import { applyVariables } from '../utils/parser';

const blank = (): Filters => ({name: '', tag_ids: '', owner_id: '', updated_from: '', updated_to: '', favorite: ''});
export function useTeamViewModel() {
  const [user, setUser] = useState<Member | null>(null);
  const [ready, setReady] = useState(false);
  const [identityEpoch, setIdentityEpoch] = useState(0);
  const [githubFailure, setGithubFailure] = useState('');
  const [githubNotice, setGithubNotice] = useState('');
  const [githubRefreshingId, setGithubRefreshingId] = useState<number | null>(null);
  const [githubWaitUntil, setGithubWaitUntil] = useState<Record<number, number>>({});
  const [githubWaitStartedAt, setGithubWaitStartedAt] = useState(0);
  const githubInFlight = useRef(false); const githubSequence = useRef(0);
  const [entries, setEntries] = useState<Entry[]>([]);
  const [total, setTotal] = useState(0);
  const [facets, setFacets] = useState<{tags: {id: number; name: string}[]; owners: Member[]}>({tags: [], owners: []});
  const [selected, setSelected] = useState<Entry | null>(null);
  const selectedRef = useRef(selected); selectedRef.current = selected;
  const [kind, setKind] = useState<Kind>('PROMPT');
  const [filterState, setFilterState] = useState<Record<Kind, Filters>>({PROMPT: blank(), SKILL: blank()});
  const [pages, setPages] = useState<Record<Kind, number>>({PROMPT: 1, SKILL: 1});
  const [error, setError] = useState(''); const [busy, setBusy] = useState(false); const [message, setMessage] = useState('');
  const [conflict, setConflict] = useState<Entry | null>(null);
  const [noteConflict, setNoteConflict] = useState<number | null>(null);
  const [pendingOperation, setPendingOperation] = useState('');
  const [importResolving, setImportResolving] = useState(false);
  const [importRetryReady, setImportRetryReady] = useState(false);
  const [importFailure, setImportFailure] = useState('');
  const importInFlight = useRef(false);
  const pendingImport = useRef<{payload: object; id: string; sequence: number; started: number} | null>(null);
  const [history, setHistory] = useState<{notes: Revision[]; bodies: Revision[]} | null>(null);
  const [members, setMembers] = useState<ManagedMember[]>([]); const [recycle, setRecycle] = useState<DeletedEntry[]>([]);
  const [importText, setImportTextRaw] = useState(''); const [importMode, setImportModeRaw] = useState('full');
  const [preview, setPreview] = useState<Preview | null>(null); const [importConfirmed, setImportConfirmed] = useState(false);
  const [exported, setExportedRaw] = useState('');
  const artifact = useRef<{id: string; text: string; actor: number; name: string; context: string} | null>(null);
  const exportSequence = useRef(0);
  const [saving, setSaving] = useState(false);
  function setExported(value: string) { ++exportSequence.current; artifact.current = null; setExportedRaw(value); } const [introCandidate, setIntroCandidate] = useState<{text: string; entryId: number; sourceVersion: number; actorId: number} | null>(null);
  const candidateIntro = introCandidate && selected?.id === introCandidate.entryId && selected.source_version === introCandidate.sourceVersion && user?.id === introCandidate.actorId ? introCandidate.text : '';
  const [copyText, setCopyText] = useState('');
  const [theme, setTheme] = useState<'dark' | 'light'>(() => localStorage.getItem('prompt-hub-theme') === 'light' ? 'light' : 'dark');
  const querySequence = useRef(0); const selectionSequence = useRef(0); const importSequence = useRef(0); const importIntent = useRef(intent()); const listScroll = useRef(0);
  const activeEntry = useRef<number | null>(null);
  const actor = useRef<number | null>(null);
  const noteDrafts = useRef(new Map<number,{text: string; base: Entry}>());
  function getNoteDraft(id: number) { return noteDrafts.current.get(id); }
  function keepNoteDraft(id: number, draft: {text: string; base: Entry} | null) { if(draft) noteDrafts.current.set(id,draft); else noteDrafts.current.delete(id); }
  const filters = filterState[kind]; const page = pages[kind];
  const filterError = filters.updated_from && filters.updated_to && filters.updated_from > filters.updated_to ? '起日不能晚于止日' : '';

  const fail = useCallback((error: unknown) => {
    if (error instanceof APIError) {
      setError(error.message + (error.requestId ? `（关联号 ${error.requestId}）` : ''));
      setPendingOperation(error.operationId);
      if (error.status === 409 && error.current) setConflict(error.current);
      if (error.status === 401 && error.code === 'unauthenticated') { ++selectionSequence.current; activeEntry.current = null; setUser(null); setSelected(null); setEntries([]); setNoteConflict(null); }
    } else setError('操作失败，请保留输入并核对结果。');
  }, []);
  async function run(action: () => Promise<void>) {
    setError(''); setMessage(''); setPendingOperation(''); setBusy(true);
    try { await action(); } catch (e) { fail(e); } finally { setBusy(false); }
  }
  function params() {
    const p = new URLSearchParams({kind, page: String(page), page_size: '20'});
    Object.entries(filters).forEach(([key, value]) => { if (value) p.set(key, value); });
    return p;
  }
  const load = useCallback(async () => {
    const sequence = ++querySequence.current;
    const p = new URLSearchParams({kind, page: String(page), page_size: '20'});
    Object.entries(filters).forEach(([key, value]) => { if (value) p.set(key, value); });
    const data = await request<{entries: Entry[]; total: number; facets: {tags: {id: number; name: string}[]; owners: Member[]}}>('entries/?' + p);
    if (sequence === querySequence.current) { setEntries(data.entries); setTotal(data.total); setFacets(data.facets); }
  }, [kind, page, filters]);
  const invalidateQueries = useCallback(() => { ++querySequence.current; }, []);
  function setFilter(key: keyof Filters, value: string) {
    setExported(''); setFilterState(prev => ({...prev, [kind]: {...prev[kind], [key]: value}})); setPages(prev => ({...prev, [kind]: 1}));
  }
  function clearFilters() { setExported(''); setFilterState(prev => ({...prev, [kind]: blank()})); setPages(prev => ({...prev, [kind]: 1})); }
  function changeKind(value: Kind) { setExported(''); setKind(value); }
  function setPage(value: number) { setPages(prev => ({...prev, [kind]: value})); }
  useEffect(() => { document.documentElement.dataset.theme = theme; localStorage.setItem('prompt-hub-theme', theme); }, [theme]);
  useEffect(() => {
    if (!user?.id) return;
    let interacted = false, sending = false;
    const mark = (event: Event) => { if (event.isTrusted) interacted = true; };
    const events = ['pointerdown', 'keydown', 'touchstart', 'scroll'];
    events.forEach(name => window.addEventListener(name, mark, {passive: true}));
    const timer = setInterval(() => {
      if (!interacted || sending || document.hidden) return;
      interacted = false; sending = true;
      const who = actor.current;
      const renew = async () => { if (who === actor.current) await request('activity/', 'POST', {}); };
      const task = navigator.locks ? navigator.locks.request('prompt-hub-activity', renew) : renew();
      void task.catch(fail).finally(() => { sending = false; });
    }, 60000);
    return () => { clearInterval(timer); events.forEach(name => window.removeEventListener(name, mark)); };
  }, [user?.id, fail]);
  useEffect(() => {
    let alive = true;
    request<{user: Member | null}>('session/').then(data => { if (alive) { actor.current = data.user?.id ?? null; setUser(data.user); } }).catch(fail).finally(() => { if (alive) setReady(true); });
    return () => { alive = false; invalidateQueries(); };
  }, [fail, invalidateQueries]);
  useEffect(() => {
    if (!user || filterError) return;
    const timer = setTimeout(() => { void load().catch(fail); }, 180);
    return () => { clearTimeout(timer); invalidateQueries(); };
  }, [load, user, fail, invalidateQueries, filterError]);
  async function login(username: string, password: string) {
    await run(async () => { rebindSessionContext(); await request('session/'); const data = await request<{user: Member}>('login/', 'POST', {username, password}); await request('session/'); if (actor.current !== null && actor.current !== data.user.id) clearPrivateState(); actor.current = data.user.id; setUser(data.user); });
  }
  function clearPrivateState() { ++githubSequence.current; githubInFlight.current=false; setGithubRefreshingId(null); setGithubFailure(''); setGithubNotice(''); setGithubWaitUntil({}); setGithubWaitStartedAt(0); pendingImport.current=null; setImportResolving(false); setImportRetryReady(false); noteDrafts.current.clear(); invalidateQueries(); ++selectionSequence.current; activeEntry.current = null; setNoteConflict(null); setIdentityEpoch(value => value + 1); setEntries([]); setSelected(null); setMembers([]); setRecycle([]); setHistory(null); setExported(''); setImportTextRaw(''); invalidateImport(); setIntroCandidate(null); setCopyText(''); setConflict(null); setFilterState({PROMPT: blank(), SKILL: blank()}); setPages({PROMPT: 1, SKILL: 1}); setFacets({tags: [], owners: []}); clearPending(); }
  async function logout() {
    await run(async () => { await request('logout/', 'POST', {}); setUser(null); clearPrivateState(); actor.current = null; await request('session/'); });
  }
  async function changePassword(old_password: string, new_password: string) {
    let success = false;
    await run(async () => { const data = await mutate<{user: Member}>('password/', 'POST', {old_password, new_password}); setUser(data.user); success = true; setMessage('密码已更新，旧会话已撤销'); await request('session/'); });
    return success;
  }
  async function select(id: number) {
    if (activeEntry.current === id) return;
    const sequence = ++selectionSequence.current; activeEntry.current = id;
    setGithubFailure(''); setGithubNotice('');
    listScroll.current = window.scrollY; setSelected(null); setHistory(null); setIntroCandidate(null);
    setError(''); setBusy(true);
    try { const result = await request<{entry: Entry}>(`entries/${id}/`); if (sequence === selectionSequence.current) { setSelected(result.entry); setConflict(null); setNoteConflict(null); } }
    catch (e) { if (sequence === selectionSequence.current) { activeEntry.current = null; fail(e); } }
    finally { if (sequence === selectionSequence.current) setBusy(false); }
  }
  function back() { ++selectionSequence.current; activeEntry.current = null; setSelected(null); setNoteConflict(null); setConflict(null); setHistory(null); requestAnimationFrame(() => window.scrollTo({top: listScroll.current})); }
  function merge(value: Entry) { setSelected(prev => {
    if (!prev || prev.id !== value.id) return value;
    return {...value, ...(prev.body_version > value.body_version ? {title: prev.title, content: prev.content, intro: prev.intro, body_version: prev.body_version} : {}), ...(prev.note_version > value.note_version ? {shared_note: prev.shared_note, note_version: prev.note_version, note_updated_at: prev.note_updated_at, note_updated_by: prev.note_updated_by} : {}), ...(prev.tag_version > value.tag_version ? {tags: prev.tags, tag_version: prev.tag_version} : {}), is_favorite: value.is_favorite ?? prev.is_favorite};
  }); }
  async function refreshAfterWrite() {
    try { await load(); } catch { setError('保存已成功，但列表读取失败。请重试读取列表，不要重复提交。'); }
  }
  async function save(input: EntryInput, editing: Entry | null, onFailure?: (message: string) => void) {
    let success = false;
    await run(async () => {
      const {kind: _kind, tags: _tags, ...body} = input;
      const value = editing ? {...body, body_version: editing.body_version} : input;
      let result: {entry: Entry};
      try {
        result = await mutate<{entry: Entry}>(editing ? `entries/${editing.id}/` : 'entries/', editing ? 'PATCH' : 'POST', value);
      } catch (error) {
        onFailure?.(error instanceof APIError ? error.message + (error.requestId ? `（关联号 ${error.requestId}）` : '') + (error.operationId ? '\n写入结果未确认，请先查询上次操作结果，不要重复提交。' : '') : '操作失败，请保留输入并核对结果。');
        throw error;
      }
      activeEntry.current = result.entry.id; merge(result.entry); setConflict(null); setMessage('内容已保存'); success = true; await refreshAfterWrite();
    }); return success;
  }
  async function saveNote(text: string, base: Entry) {
    let success = false;
    const sequence = selectionSequence.current;
    await run(async () => {
      try {
        const result = await mutate<{entry: Entry}>(`entries/${base.id}/note/`, 'PATCH', {text, note_version: base.note_version});
        if (sequence !== selectionSequence.current || activeEntry.current !== base.id) return;
        merge(result.entry); setConflict(null); setNoteConflict(null); setMessage('共同备注已保存'); success = true; await refreshAfterWrite();
      } catch (e) {
        if (sequence !== selectionSequence.current) return;
        if (e instanceof APIError && e.code === 'conflict' && e.status === 409) setNoteConflict(base.id);
        throw e;
      }
    });
    return success;
  }
  async function readLatestNote(id: number) {
    const sequence = selectionSequence.current;
    const controller = new AbortController(); const timer = setTimeout(() => controller.abort(), 15000);
    try {
      const result = await request<{entry: Entry}>(`entries/${id}/`, 'GET', undefined, controller.signal);
      if (sequence !== selectionSequence.current || activeEntry.current !== id) return null;
      return result.entry;
    } catch (e) { if (sequence === selectionSequence.current) fail(e); return null; }
    finally { clearTimeout(timer); }
  }
  function clearNoteConflict() { setNoteConflict(null); setConflict(null); }
  async function deleteEntry() {
    if (!selected) return;
    await run(async () => { await mutate(`entries/${selected.id}/`, 'DELETE', {body_version: selected.body_version, note_version: selected.note_version}); setSelected(null); setHistory(null); await load(); setMessage('条目已移入回收站'); });
  }
  async function loadHistory() { if (selected) await run(async () => setHistory(await request(`entries/${selected.id}/history/`))); }
  async function restoreRevision(revision: Revision) {
    if (!selected) return;
    await run(async () => { const data = await mutate<{entry: Entry}>(`entries/${selected.id}/restore/`, 'POST', {domain: revision.domain, revision_id: revision.id, version: revision.domain === 'body' ? selected.body_version : selected.note_version}); merge(data.entry); setHistory(null); await load(); setMessage('已恢复为新版本'); });
  }
  async function favorite(entry: Entry) {
    await run(async () => { const value = await request<{favorite: boolean}>(`entries/${entry.id}/favorite/`, 'POST', {favorite: !entry.is_favorite}); if (selected?.id === entry.id) setSelected({...selected, is_favorite: value.favorite}); await load(); });
  }
  async function github() {
    if (!selected || githubInFlight.current || (githubWaitUntil[selected.id] || 0)>Date.now()) return;
    const base=selected, who=actor.current, context=sessionContext(), sequence=selectionSequence.current, job=++githubSequence.current;
    const sameActor=()=>actor.current===who && sessionContext()===context;
    const current=()=>sameActor() && sequence===selectionSequence.current && activeEntry.current===base.id && selectedRef.current?.source_version===base.source_version;
    const discarded=()=>console.info('prompt-hub.github',{stage:'result_discarded',entry_id:base.id});
    githubInFlight.current=true;setGithubRefreshingId(base.id);setGithubFailure('');setGithubNotice('');setError('');setMessage('');
    try {
      const data=await request<{entry:Entry;candidate_intro:string;refresh:{outcome:string;attempts:number;checked_at:string|null}}>(`entries/${base.id}/github/`,'POST',{});
      if(!current() || data.entry.source_version!==base.source_version){discarded();return;}
      merge(data.entry);setIntroCandidate({text:data.candidate_intro,entryId:base.id,sourceVersion:base.source_version,actorId:who!});setGithubWaitUntil(value=>({...value,[base.id]:0}));
      const text=data.refresh.outcome==='cached'?'仓库资料已使用刚核验的缓存；核验时间未改变':'仓库资料已更新；人工介绍及备注未改';
      setMessage(text);setGithubNotice(text+(data.candidate_intro.trim()?'':'；仓库暂无可追加的介绍。'));console.info('prompt-hub.github',{stage:'result_applied',entry_id:base.id,outcome:data.refresh.outcome});
      try{await load();}catch{if(current())setError('仓库资料已更新，但列表暂未刷新。请重新读取列表，不要重复刷新GitHub。');}
    } catch(error) {
      if(!sameActor()){discarded();return;}
      if(error instanceof APIError && error.status===401 && error.code==='unauthenticated'){
        setGithubFailure(error.message+(error.requestId?`（关联号 ${error.requestId}）`:''));fail(error);return;
      }
      if(!current()){discarded();return;}
      const message=error instanceof APIError ? (error.status===0?'网络中断，本次刷新结果未确认；可先重新读取该条目资料。':error.message)+(error.requestId?`（关联号 ${error.requestId}）`:'')+(error.retryAfterSeconds?`\n${Math.ceil(error.retryAfterSeconds)}秒后可重试；到期不会自动刷新。`:'')+(error.cachedDataAvailable===true?'\n已保留上次的Star资料，核验时间不变。':error.cachedDataAvailable===false?'\n尚无已核验的Star，本次不会填入0。':'') : '仓库刷新失败，请保留旧资料并检查服务日志。';
      if(error instanceof APIError && error.retryAfterSeconds){const receivedAt=Date.now();setGithubWaitStartedAt(receivedAt);setGithubWaitUntil(value=>({...value,[base.id]:receivedAt+error.retryAfterSeconds*1000}));}
      setGithubNotice(message);setGithubFailure(message);console.warn('prompt-hub.github',{stage:'feedback_shown',entry_id:base.id,error_code:error instanceof APIError?error.code:'unknown'});
    } finally {if(job===githubSequence.current){githubInFlight.current=false;setGithubRefreshingId(null);}}
  }
  function invalidateImport() { ++importSequence.current; setPreview(null); setImportConfirmed(false); setImportFailure(''); importIntent.current = intent(); if(importInFlight.current) { importInFlight.current=false; setBusy(false); } }
  function setImportText(value: string) { setImportTextRaw(value); invalidateImport(); }
  function setImportMode(value: string) { setImportModeRaw(value); invalidateImport(); }
  async function importFile(file: File) {
    invalidateImport(); const seq = importSequence.current, who = actor.current;
    setError(''); setBusy(true); importInFlight.current=true;
    try { const value = await readText(file); if (seq === importSequence.current && who === actor.current) setImportTextRaw(value); }
    catch(e) { if(seq === importSequence.current && who === actor.current) importFailed(e); }
    finally { if(seq === importSequence.current) { importInFlight.current=false; setBusy(false); } }
  }
  function importFailed(error: unknown) {
    if (error instanceof APIError) error.operationId=''; // Preview/read never writes.
    const location=error instanceof APIError ? error.line ? `第${error.line}行` : error.entryIndex ? `第${error.entryIndex}条` : '' : '';
    const message=error instanceof APIError ? (location && !error.message.includes(location) ? location+'：' : '')+error.message+(error.requestId ? `（关联号 ${error.requestId}）` : '') : '预览未完成，请保留输入并稍后重试。';
    setImportFailure(message); fail(error);
  }
  async function previewImport() {
    const seq = ++importSequence.current, who = actor.current;
    setPreview(null); setImportConfirmed(false); setImportFailure(''); setError(''); setMessage(''); setPendingOperation(''); setBusy(true); importInFlight.current=true;
    try {
      const data = await request<Preview>('exchange/preview/', 'POST', {text: importText, mode: importMode, ...importIntent.current});
      if (seq === importSequence.current && who === actor.current) setPreview(data);
    } catch (e) {
      if(seq !== importSequence.current || who !== actor.current) return;
      if (e instanceof APIError && e.status === 0) e.message='预览未完成，请保留输入，恢复连接后重试。';
      // This bounded suggestion never replaces authoritative server validation.
      if (e instanceof APIError && e.code === 'invalid_json' && importMode === 'full' && /^\d+[、.]/.test(importText.trimStart().slice(0,512))) e.message = '当前内容可能是旧版Prompt TXT，请切换旧格式后重新解析预览。';
      importFailed(e);
    } finally { if(seq === importSequence.current) { importInFlight.current=false; setBusy(false); } }
  }
  function imported(result: {entry_count: number}, sequence: number) {
    if(sequence === importSequence.current) { setImportTextRaw(''); invalidateImport(); }
    pendingImport.current=null; setImportResolving(false); setImportRetryReady(false); setPendingOperation('');
    setMessage(`已新建 ${result.entry_count} 条，原内容未覆盖`);
  }
  async function submitImport(value: NonNullable<typeof pendingImport.current>) {
    try {
      const result=await request<{entry_count:number}>('exchange/commit/','POST',value.payload);
      imported(result,value.sequence); await refreshAfterWrite(); return true;
    } catch(error) {
      if(error instanceof APIError && !error.operationId) { pendingImport.current=null;setImportResolving(false); }
      throw error;
    }
  }
  async function commitImport() {
    if(!preview || !importConfirmed || pendingImport.current) return false;
    const value={payload:{text:importText,mode:importMode,preview_token:preview.preview_token,confirmed:true,...importIntent.current},id:importIntent.current.operation_id,sequence:importSequence.current,started:Date.now()};
    pendingImport.current=value;setImportResolving(true);setImportRetryReady(false);rememberOperation(importIntent.current);
    let ok=false;await run(async()=>{ok=await submitImport(value);});return ok;
  }
  async function retryPendingImport() {
    const value=pendingImport.current;if(!value || !importRetryReady) return;
    if(Date.now()-value.started>=24*3600*1000) {setError('原操作已超出24小时核对窗口，请人工核对内容，不自动重导。');return;}
    await run(async()=>{await submitImport(value);});
  }
  function abandonPendingImport() {
    pendingImport.current=null;setImportResolving(false);setImportRetryReady(false);setPendingOperation('');invalidateImport();
    setMessage('已结束本页核对状态。旧操作不代表已撤销；请先人工核对，再预览新导入。');
  }
  async function generateExport(scope: string, format: string) {
    setExported(''); const sequence = exportSequence.current; const who = actor.current; const context = sessionContext();
    await run(async () => { const p = scope === 'all' ? new URLSearchParams({scope, format}) : scope === 'selected' || scope === 'kind' ? new URLSearchParams({scope, format, kind}) : params(); p.set('scope', scope); p.set('format', format); if (scope === 'selected') { if (!selected) throw new APIError(422, {message: '请先选择一个条目'}); p.set('ids', String(selected.id)); }
      const text = await exportText(p);
      if (sequence !== exportSequence.current || who !== actor.current || who === null || context !== sessionContext()) return;
      artifact.current = {id: crypto.randomUUID(), text, actor: who, context, name: `prompt-hub-${kind.toLowerCase()}-${format}-${Date.now()}.txt`};
      setExportedRaw(text); setMessage('文件已生成，请核对范围和内容后保存');
    });
  }
  async function saveExport(asFile: boolean) {
    const captured = artifact.current; if (!captured || saving) return;
    setSaving(true); setError(''); setMessage(''); localSaveEvent(captured.id,asFile ? 'picker' : 'download','started');
    try {
      const handle = asFile ? await chooseSaveTarget(captured.name) : null;
      const session = await request<{user: Member | null; session_context: string | null}>('session/');
      if (artifact.current !== captured || actor.current !== captured.actor || session.user?.id !== captured.actor || session.session_context !== captured.context) {
        setExported(''); if(!session.user) setUser(null);
        throw new APIError(409,{message:'登录或导出范围已变化，请重新生成导出文件。'});
      }
      if (handle) { await writeTarget(handle, captured.text, captured.id); setMessage('文件已保存'); }
      else { saveText(captured.text, captured.name); localSaveEvent(captured.id,'download','initiated'); setMessage('已发起下载，请在浏览器查看结果'); }
    } catch (error) {
      if(error instanceof APIError && error.status===401) { setUser(null); setExported(''); }
      localSaveEvent(captured.id,'save',error instanceof DOMException && error.name === 'AbortError' ? 'aborted' : 'failed',error);
      if (error instanceof DOMException && error.name === 'AbortError') setMessage('未保存，预览仍保留');
      else setError(error instanceof APIError && (error.status === 409 || error.status === 401) ? error.message : '未确认保存。请核对登录、导出范围及目标文件后重试；预览仍保留。');
    } finally { setSaving(false); }
  }
  async function readSelected() {
    if (!selected) return;
    const id = selected.id, who = actor.current;
    const data = await request<{entry: Entry}>(`entries/${id}/`);
    if (who === actor.current && activeEntry.current === id) merge(data.entry);
  }
  async function recommend(entry: Entry) {
    const who = actor.current;
    await run(async () => {
      await mutate(`entries/${entry.id}/recommendation/`, 'POST', {recommended: !entry.is_recommended});
      if (who !== actor.current) return;
      await readSelected(); await load();
    });
  }
  async function changeTags(base: Entry, change: object) {
    let success=false; const who = actor.current;
    await run(async () => {
      await mutate(`entries/${base.id}/tags/`, 'POST', change); success=true;
      if (who !== actor.current) return;
      await readSelected(); await refreshAfterWrite(); setMessage('标签已更新');
    }); return success;
  }
  async function preferences(change: object) {
    await run(async () => {
      await mutate<{user: Member}>('preferences/', 'POST', change);
      const latest = await request<{user: Member}>('session/'); setUser(latest.user); setMessage('登录设置已保存');
    });
  }
  async function loadMembers() { await run(async () => { setMembers((await request<{members: ManagedMember[]}>('members/')).members); }); }
  async function createMember(username: string, display_name: string, temporary_password: string) {
    let ok = false;
    await run(async () => { await mutate('members/', 'POST', {username, display_name, temporary_password, is_admin: false}); await loadMembers(); setMessage('成员已创建，首次登录可选择修改密码'); ok = true; }); return ok;
  }
  async function updateMember(member: ManagedMember, changes: object) { await run(async () => { await mutate(`members/${member.id}/`, 'PATCH', changes); await loadMembers(); setMessage('成员已更新，权限变更会撤销旧会话'); }); }
  async function loadRecycle() { await run(async () => setRecycle((await request<{entries: DeletedEntry[]}>('recycle/')).entries)); }
  async function undelete(id: number) { await run(async () => { await mutate(`entries/${id}/undelete/`, 'POST', {}); await loadRecycle(); await load(); setMessage('条目已恢复，旧编辑版本已失效'); }); }
  async function copy(variables: Record<string, string>) {
    if (!selected) return;
    const value = selected.kind === 'PROMPT' ? applyVariables(selected.content, variables) : [selected.title, selected.intro, selected.skill_source?.source_url, selected.skill_source?.skill_path ? '仓库路径：'+selected.skill_source.skill_path : ''].filter(Boolean).join('\n');
    try { await navigator.clipboard.writeText(value); setMessage('已复制'); } catch { setCopyText(value); }
  }
  async function checkPending() {
    const operation=pendingOperation;
    await run(async()=>{
      try {
        const value=await operationStatus(operation);
        const waiting=pendingImport.current;
        if(waiting?.id===operation && value.result && typeof value.result==='object' && 'entry_count' in value.result && typeof value.result.entry_count==='number') imported({entry_count:value.result.entry_count},waiting.sequence);
        else setMessage('服务器已确认该次操作成功，正在读取当前状态。');
        await refreshAfterWrite();await readSelected();
      } catch(error) {
        if(error instanceof APIError) {error.operationId=operation;setImportRetryReady(error.code==='receipt_unknown');}throw error;
      }
    });
  }
  return {importFailure, dismissImportFailure: () => setImportFailure(''), githubFailure, dismissGithubFailure: () => setGithubFailure(''), githubNotice, githubRefreshingId, githubWaitUntil, githubWaitStartedAt, identityEpoch, getNoteDraft, keepNoteDraft, user, ready, entries, selected, setSelected, kind, setKind: changeKind, filters, setFilter, clearFilters, facets, total, page, setPage, error: filterError || error, busy, message, conflict, noteConflict, clearNoteConflict, readLatestNote, pendingOperation, retryList: () => run(load), login, logout, changePassword, select, back, save, saveNote, deleteEntry, history, loadHistory, restoreRevision, favorite, github, candidateIntro, importText, setImportText, importMode, setImportMode, importFile, preview, importConfirmed, setImportConfirmed, importResolving, importRetryReady, retryPendingImport, abandonPendingImport, previewImport, commitImport, exported, setExported, generateExport, saving, saveAs: () => saveExport(true), download: () => saveExport(false), recommend, changeTags, refreshSelected: () => run(readSelected), preferences, members, loadMembers, createMember, updateMember, recycle, loadRecycle, undelete, copy, copyText, setCopyText, theme, changeTheme: () => setTheme(theme === 'dark' ? 'light' : 'dark'), checkPending};
}
