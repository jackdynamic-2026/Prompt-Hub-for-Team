import { useState } from 'react';
import type { useTeamViewModel } from './useTeamViewModel';

export default function PersonalSettings({vm, onClose}: {vm: ReturnType<typeof useTeamViewModel>; onClose: () => void}) {
  const [minutes, setMinutes] = useState(String(vm.user?.idle_timeout_minutes ?? 60));
  const [old, setOld] = useState(''); const [password, setPassword] = useState(''); const [repeat, setRepeat] = useState('');
  const [error, setError] = useState('');
  return <section className="team-panel" aria-label="个人设置"><h2>个人设置</h2><button onClick={onClose}>返回列表</button>
    <form onSubmit={e => { e.preventDefault(); void vm.preferences({idle_timeout_minutes: Number(minutes)}); }}>
      <label>无操作超时分钟数<input type="number" min={5} max={10080} step={1} required value={minutes} onChange={e => setMinutes(e.target.value)} /></label>
      <p>默认60分钟。实际活动会续期，后台查询不会续期。保存影响当前会话及今后登录，其他已登录设备保留原窗口。允许5至10080分钟。</p>
      {!navigator.locks && <p>当前浏览器建议只打开一个分享库页面后修改登录设置。</p>}<button disabled={vm.busy}>保存登录设置</button>
    </form>
    <form onSubmit={e => { e.preventDefault(); setError(''); if (Array.from(password).length < 8) {setError('新密码至少8位');return;} if (password !== repeat) {setError('两次新密码不一致');return;} void vm.changePassword(old,password).then(ok => {if(ok){setOld('');setPassword('');setRepeat('');}}); }}>
      <h3>修改密码 · 可选</h3><label>当前密码<input required type="password" autoComplete="current-password" value={old} onChange={e=>setOld(e.target.value)} /></label>
      <label>新密码 · 至少8位<input required type="password" autoComplete="new-password" value={password} onChange={e=>setPassword(e.target.value)} /></label>
      <label>确认新密码<input required type="password" autoComplete="new-password" value={repeat} onChange={e=>setRepeat(e.target.value)} /></label>
      {error && <p role="alert">{error}</p>}<button disabled={vm.busy}>更新密码</button>
    </form>
  </section>;
}
