import { useEffect, useRef, useState } from 'react';
import type { FormEvent, MouseEvent } from 'react';
import type { Entry, EntryInput, Kind, SkillSource } from './model';
import { useTeamViewModel } from './useTeamViewModel';
import Detail from './Detail';
import { appendRepositoryIntro } from './skillIntro';
import ExchangePanel from './ExchangePanel';
import PersonalSettings from './PersonalSettings';
import { MembersPanel, RecyclePanel } from './ManagementPanels';
import './team.css';

export default function TeamApp() {
  const vm = useTeamViewModel();
  return <TeamWorkspace key={vm.identityEpoch} vm={vm} />;
}

function TeamWorkspace({vm}: {vm: ReturnType<typeof useTeamViewModel>}) {
  const [username, setUsername] = useState(''); const [password, setPassword] = useState('');
  const [panel, setPanel] = useState<'browse' | 'edit' | 'import' | 'export' | 'members' | 'recycle' | 'settings'>('browse');
  const [editing, setEditing] = useState<Entry | null>(null);
  const [title, setTitle] = useState(''); const [content, setContent] = useState(''); const [tags, setTags] = useState('');
  const [source, setSource] = useState(''); const [path, setPath] = useState(''); const [formError, setFormError] = useState('');
  const [saveFailure, setSaveFailure] = useState('');
  const [dirty, setDirty] = useState(false); const [noteDirty, setNoteDirty] = useState(false); const [expanded, setExpanded] = useState(false);
  const unsaved = dirty || noteDirty || (panel === 'import' && !!vm.importText);
  const pointerStart = useRef<{id: number; x: number; y: number} | null>(null);
  function selectEntry(id: number) { if (vm.selected?.id === id) return; if (!vm.selected && !dirty && vm.getNoteDraft(id)) { void vm.select(id); return; } if (leave()) void vm.select(id); }
  function clickCard(event: MouseEvent<HTMLElement>, id: number) {
    if ((event.target as HTMLElement).closest('button,a,input,textarea,select,[role=button]')) return;
    const start = pointerStart.current; pointerStart.current = null;
    if (start?.id === id && Math.hypot(event.clientX - start.x, event.clientY - start.y) > 8) return;
    const selection = window.getSelection();
    if (selection?.toString() && ((selection.anchorNode && event.currentTarget.contains(selection.anchorNode)) || (selection.focusNode && event.currentTarget.contains(selection.focusNode)))) return;
    selectEntry(id);
  }
  function importCompleted() { setDirty(false); setNoteDirty(false); setPanel('browse'); setFormError(''); }
  useEffect(() => {
    if (!unsaved) return;
    const guard = (event: BeforeUnloadEvent) => { event.preventDefault(); event.returnValue = ''; };
    window.addEventListener('beforeunload', guard); return () => window.removeEventListener('beforeunload', guard);
  }, [unsaved]);
  function leave() { if (unsaved && !window.confirm('有未保存的输入，确认离开？')) return false; if(noteDirty && vm.selected) vm.keepNoteDraft(vm.selected.id,null); setDirty(false); setNoteDirty(false); return true; }
  function open(next: typeof panel) { if (leave()) { setPanel(next); setFormError(''); } }
  function edit(entry: Entry | null, intro?: string) {
    let initial = entry?.kind === 'SKILL' ? entry.intro : entry?.content || '';
    if (intro !== undefined && entry?.kind === 'SKILL') {
      if (vm.selected?.id !== entry.id || vm.selected.source_version !== entry.source_version || vm.candidateIntro !== intro) {
        reportSaveFailure('仓库介绍来源已变化，请重新刷新仓库资料。'); return;
      }
      const result = appendRepositoryIntro(entry.intro, intro);
      if (result.status !== 'appended') {
        reportSaveFailure(result.status === 'duplicate' ? '该仓库介绍已包含在当前介绍中。' : result.status === 'empty' ? '仓库暂无可追加的介绍。' : '合并后介绍超出5000字符上限，请先精简原介绍或手工选择候选内容。'); return;
      }
      initial = result.text;
    }
    if (!leave()) return;
    setEditing(entry); setTitle(entry?.title || ''); setContent(initial); setTags(entry?.tags.map(t => t.name).join('、') || ''); setSource(entry?.skill_source?.source_url || ''); setPath(entry?.skill_source?.skill_path || ''); setFormError(''); setPanel('edit'); setDirty(intro !== undefined);
  }
  async function save(event: FormEvent) {
    event.preventDefault(); setFormError('');
    let skill_source: SkillSource | null = null;
    const kind = editing?.kind || vm.kind;
    if (kind === 'SKILL' && Array.from(content).length > 5000) { reportSaveFailure('Skill介绍超过5000字符，请精简后保存。'); return; }
    if (kind === 'SKILL' && source) {
      try {
        const url = new URL(source.trim()); const parts = url.pathname.split('/').filter(Boolean);
        if (Array.from(source).length > 2048 || /\\/.test(source) || !/^https:\/\/github\.com\//i.test(source.trim()) || Array.from(source).some(c => c.charCodeAt(0) < 32 || c.charCodeAt(0) === 127) || url.protocol !== 'https:' || url.host !== 'github.com' || url.username || url.password || parts.length < 2) throw new Error();
        skill_source = {provider: 'github', owner: parts[0], repo: parts[1], skill_path: path, source_url: source.trim()};
      } catch { reportSaveFailure('请填写包含所有者和仓库名的GitHub HTTPS链接，支持仓库首页、分支页或文件页。'); return; }
    } else if (kind === 'SKILL' && path) { reportSaveFailure('填写Skill路径前，请先填写仓库地址。'); return; }
    const input: EntryInput = {kind, title, content: kind === 'PROMPT' ? content : '', intro: kind === 'SKILL' ? content : '', tags: tags.split(/[、,，\n]/).map(t => t.trim()).filter(Boolean), skill_source};
    if (await vm.save(input, editing, reportSaveFailure)) { setDirty(false); setPanel('browse'); }
  }
  function reportSaveFailure(message: string) { setFormError(message); setSaveFailure(message); }
  function switchKind(kind: Kind) { if (leave()) { setPanel('browse'); vm.back(); vm.setKind(kind); } }
  const date = (value: string) => new Date(value).toLocaleString('zh-CN', {timeZone: 'Asia/Shanghai'});
  return <main id="team-root">
    <SaveFailureDialog title={vm.importFailure ? '导入预览未完成' : vm.githubFailure ? '仓库刷新未完成' : '保存未完成'} message={vm.importFailure || vm.githubFailure || saveFailure} onDismiss={() => { setSaveFailure(''); vm.dismissGithubFailure(); vm.dismissImportFailure(); }} />
    <header className="team-brand"><div><strong>PromptHub</strong><h1>提示词与技能分享库</h1><p>团队共享 · 标签查找 · 共同备注</p></div><button onClick={vm.changeTheme}>{vm.theme === 'dark' ? '浅色模式' : '深色模式'}</button>{vm.user && <><button onClick={() => open('settings')}>个人设置</button><span>{vm.user.display_name}</span><button disabled={vm.busy} onClick={async () => { if (leave()) { await vm.logout(); setPanel('browse'); setPassword('');  setContent(''); setTitle(''); } }}>退出登录</button></>}</header>
    {vm.error && <div className="team-alert" role="alert">{vm.error}{vm.pendingOperation && <><p>该次写入结果未确认，请先核对，再决定是否重试。</p><button disabled={vm.busy} onClick={() => void vm.checkPending()}>查询上次操作结果</button></>}{vm.error.startsWith("保存已成功") && <button disabled={vm.busy} onClick={() => void vm.retryList()}>重试读取列表</button>}</div>}
    {vm.message && <p role="status" className="team-alert">{vm.message}</p>}
    {!vm.ready ? <p>正在检查登录状态…</p> : !vm.user ? <form className="team-panel team-login" onSubmit={e => { e.preventDefault(); void vm.login(username, password).then(() => setPassword('')); }}><h2>登录分享库</h2><label>用户名<input autoComplete="username" required value={username} onChange={e => setUsername(e.target.value)} /></label><label>密码<input type="password" autoComplete="current-password" required value={password} onChange={e => setPassword(e.target.value)} /></label><button className="primary" disabled={vm.busy}>登录</button><small>账号由管理员创建。个人版仍可从网站首页访问。</small></form> : <>
      {vm.user.password_change_suggested && <aside className="team-alert"><p>建议修改初始密码，你可以选择稍后修改。</p><button onClick={() => open('settings')}>现在修改密码</button><button disabled={vm.busy} onClick={() => void vm.preferences({dismiss_password_suggestion: true})}>暂不修改</button></aside>}
      <nav className="team-types" aria-label="内容大类"><button aria-pressed={vm.kind === 'PROMPT'} onClick={() => switchKind('PROMPT')}>提示词</button><button aria-pressed={vm.kind === 'SKILL'} onClick={() => switchKind('SKILL')}>Skills</button></nav>
      <div className="team-actions"><button className="primary" onClick={() => edit(null)}>+ 分享{vm.kind === 'PROMPT' ? '提示词' : 'Skill'}</button><button onClick={() => open('import')}>导入 TXT</button><button onClick={() => open('export')}>导出 TXT</button>{vm.user.is_admin && <><button onClick={() => { if (leave()) { setPanel('members'); void vm.loadMembers(); } }}>成员管理</button><button onClick={() => { if (leave()) { setPanel('recycle'); void vm.loadRecycle(); } }}>回收站</button></>}</div>
      {panel === 'settings' ? <PersonalSettings vm={vm} onClose={() => open('browse')} /> : panel === 'edit' ? <form className="team-panel" onInvalid={e => { e.preventDefault(); reportSaveFailure((e.target as HTMLInputElement).validationMessage || '请检查必填项。'); }} onSubmit={e => void save(e)} onChange={() => setDirty(true)}><div className="team-actions"><h2>{editing ? '编辑内容' : '分享新条目'} · {vm.kind === 'PROMPT' ? '提示词' : 'Skill'}</h2><button type="button" onClick={() => open('browse')}>返回列表</button></div><label>名称<input required maxLength={120} value={title} onChange={e => setTitle(e.target.value)} /></label><label>{vm.kind === 'PROMPT' ? '提示词正文' : 'Skill介绍'}<textarea required={vm.kind === 'PROMPT'} maxLength={vm.kind === 'PROMPT' ? 50000 : undefined} value={content} onChange={e => setContent(e.target.value)} /></label>{!editing ? <label>标签 · 用顿号或逗号分隔，最多10个<input value={tags} onChange={e => setTags(e.target.value)} /></label> : <p>标签在详情中单独管理；保存正文保留当前协作标签。</p>}{vm.kind === 'SKILL' && <><label>GitHub仓库地址 · 可选<input type="url" value={source} onChange={e => setSource(e.target.value)} /></label><label>Skill在仓库中的路径 · 可选<input value={path} onChange={e => setPath(e.target.value)} /></label><p>支持GitHub仓库首页、分支页或文件页；保留完整链接，单独识别仓库以同步Star数，不校验Skill文件是否存在。链接请勿包含私人凭据。保存资料不受GitHub网络影响；Star数通过详情中的同步入口获取。</p></>}{formError && <p role="alert" className="team-alert">{formError}</p>}{vm.conflict && editing && <section className="team-alert"><p>服务器内容已更新。请核对后手工合并，输入仍保留。</p><pre>{vm.conflict.title + '\n' + (vm.conflict.content || vm.conflict.intro) + '\n标签：' + vm.conflict.tags.map(t => t.name).join('、')}</pre><button type="button" onClick={() => setEditing(vm.conflict)}>已核对，使用服务器版本继续保存</button></section>}<button disabled={vm.busy} className="primary">{vm.busy ? '正在保存…' : '保存内容'}</button></form> : panel === 'import' || panel === 'export' ? <ExchangePanel key={panel} vm={vm} mode={panel} onClose={() => open('browse')} onImported={importCompleted} /> : panel === 'members' ? <MembersPanel vm={vm} onClose={() => open('browse')} /> : panel === 'recycle' ? <RecyclePanel vm={vm} onClose={() => open('browse')} /> : <>
      <section className="team-filters" aria-label="筛选条目"><div className="team-search"><label>按名称查找<input type="search" value={vm.filters.name} onChange={e => vm.setFilter('name', e.target.value)} placeholder="输入名称" /></label><button onClick={() => setExpanded(!expanded)} aria-expanded={expanded}>更多筛选</button><button onClick={vm.clearFilters}>清空</button></div><div className={'team-filter-extra' + (expanded ? ' expanded' : '')}><label>分享人<select value={vm.filters.owner_id} onChange={e => vm.setFilter('owner_id', e.target.value)}><option value="">所有分享人</option>{vm.facets.owners.map(m => <option key={m.id} value={m.id}>{m.display_name}</option>)}</select></label><label>收藏<select value={vm.filters.favorite} onChange={e => vm.setFilter('favorite', e.target.value)}><option value="">全部条目</option><option value="1">我的收藏</option></select></label><label>更新时间从 · 北京时间<input type="date" value={vm.filters.updated_from} onChange={e => vm.setFilter('updated_from', e.target.value)} /></label><label>更新时间至 · 含当天<input type="date" value={vm.filters.updated_to} onChange={e => vm.setFilter('updated_to', e.target.value)} /></label><div className="team-tags" aria-label="多选标签"><span>标签 · 任一匹配</span>{vm.facets.tags.map(t => <button key={t.id} aria-pressed={vm.filters.tag_ids.split(',').includes(String(t.id))} onClick={() => { const selected = new Set(vm.filters.tag_ids.split(',').filter(Boolean)); if (selected.has(String(t.id))) selected.delete(String(t.id)); else selected.add(String(t.id)); vm.setFilter('tag_ids', [...selected].join(',')); }}>{t.name}</button>)}{!vm.facets.tags.length && <small>暂无标签</small>}</div></div></section>
      <div className="team-actions" aria-label="已选筛选条件">{(Object.entries(vm.filters) as [keyof typeof vm.filters, string][]).filter(([, value]) => value).map(([key, value]) => <button key={key} onClick={() => vm.setFilter(key as keyof typeof vm.filters, '')}>{key === 'name' ? '名称：' + value : key === 'tag_ids' ? '已选标签：' + value.split(',').map(id => vm.facets.tags.find(t => t.id === Number(id))?.name || id).join('、') : key === 'owner_id' ? '分享人：' + (vm.facets.owners.find(m => m.id === Number(value))?.display_name || value) : key === 'favorite' ? '我的收藏' : (key === 'updated_from' ? '从 ' : '至 ') + value} ×</button>)}</div><div className={'team-browse' + (vm.selected ? ' has-detail' : '')}><section className="team-list-area" aria-label="条目列表"><p>共 {vm.total} 条 · 按更新时间排序</p><div className="team-list">{vm.entries.map(entry => <article className={'team-card team-entry-card' + (vm.selected?.id === entry.id ? ' current' : '')} key={entry.id} onPointerDown={e => { pointerStart.current = {id: entry.id, x: e.clientX, y: e.clientY}; }} onClick={e => clickCard(e, entry.id)}><button className="team-title" aria-pressed={vm.selected?.id === entry.id} onClick={e => { e.stopPropagation(); selectEntry(entry.id); }}>{entry.title}</button><p className="team-summary">{entry.content || entry.intro}</p><div className="team-tags">{entry.tags.map(t => <span key={t.id}>{t.name}</span>)}</div><button disabled={vm.busy} aria-pressed={entry.is_recommended} onClick={e=>{e.stopPropagation();void vm.recommend(entry);}}>{entry.is_recommended ? "★ 取消推荐" : "☆ 团队推荐"} {entry.recommendation_count}</button><p className="team-summary">共同备注：{entry.shared_note || "暂无备注"}</p><small>{entry.owner.display_name} · {date(entry.updated_at)}{entry.is_favorite ? ' · 已收藏' : ''}</small></article>)}</div>{!vm.entries.length && <p>当前条件没有条目。可清空筛选或分享新内容。</p>}<div className="team-actions"><button disabled={vm.page <= 1} onClick={() => vm.setPage(vm.page - 1)}>上一页</button><span>第 {vm.page} 页</span><button disabled={vm.page * 20 >= vm.total} onClick={() => vm.setPage(vm.page + 1)}>下一页</button></div></section>{vm.selected && <Detail key={vm.selected.id} vm={vm} onEdit={edit} onDirty={setNoteDirty} onBack={() => { if (leave()) vm.back(); }} />}</div>
      </>}
      {vm.copyText && <section className="team-panel"><h2>请手动复制</h2><p>当前浏览器未允许自动复制。长按或全选以下文本。</p><textarea readOnly value={vm.copyText} /><button onClick={() => vm.setCopyText('')}>关闭</button></section>}
    </>}
  </main>;
}

function SaveFailureDialog({message, onDismiss, title}: {message: string; onDismiss: () => void; title: string}) {
  const dialog = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    if (message && !dialog.current?.open) dialog.current?.showModal();
    if (!message && dialog.current?.open) dialog.current.close();
  }, [message]);
  return <dialog ref={dialog} className="team-save-failure" role="alertdialog" aria-labelledby="save-failure-title" aria-describedby="save-failure-reason" onCancel={onDismiss} onClose={onDismiss}>
    <h2 id="save-failure-title">{title}</h2><p id="save-failure-reason">{message}</p><p>请保留当前输入，处理上述原因后再操作。</p><button type="button" autoFocus onClick={onDismiss}>知道了</button>
  </dialog>;
}
