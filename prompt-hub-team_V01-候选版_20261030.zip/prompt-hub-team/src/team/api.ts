import { APIError } from './model';
let token = '';
let epoch = '';
let contextId = '';
export function sessionContext() { return contextId; }
export function rebindSessionContext() { contextId=''; }
const pending = new Map<string, {operation_id: string; operation_epoch: string}>();
let lastOperation = '';
async function performRequest<T>(path: string, method = 'GET', body?: unknown, signal?: AbortSignal): Promise<T> {
  const uncertain = (error: APIError) => {
    if (body && typeof body === 'object' && 'operation_id' in body && typeof body.operation_id === 'string') error.operationId = body.operation_id;
    return error;
  };
  const controller = new AbortController();
  const abort = () => controller.abort();
  if(signal?.aborted) controller.abort(); else signal?.addEventListener('abort',abort,{once:true});
  const deadline = setTimeout(abort,30000);
  try {
    let response: Response;
    try {
      response = await fetch('/api/' + path, {method, signal: controller.signal, credentials: 'same-origin', headers: {'Content-Type': 'application/json', ...(contextId ? {'X-Session-Context':contextId} : {}), ...(method !== 'GET' ? {'X-CSRFToken': token} : {})}, ...(body !== undefined ? {body: JSON.stringify(body)} : {})});
    } catch { throw uncertain(new APIError(0, {error: 'unconfirmed', message: '网络中断，请保留输入，恢复连接后核对。'})); }
    let data;
    try { data = await response.json(); } catch { throw uncertain(new APIError(response.status, {error: 'invalid_response', message: '服务器响应异常，请保留输入。'})); }
    if (!response.ok) { const error = new APIError(response.status, data); throw response.status >= 500 ? uncertain(error) : error; }
    if ('session_context' in data) {
      const next=typeof data.session_context === 'string' ? data.session_context : '';
      if(contextId && next!==contextId && !['login/','password/','logout/'].includes(path)) throw new APIError(401,{error:'unauthenticated',message:'登录上下文已变化，请重新登录并重新生成导出文件。'});
      contextId=next;
    }
    if (data.csrf_token) token = data.csrf_token;
    if (data.operation_epoch) epoch = data.operation_epoch;
    return data as T;
  } finally { clearTimeout(deadline); signal?.removeEventListener('abort',abort); }

}
let writeQueue: Promise<unknown> = Promise.resolve();
export async function request<T>(path: string, method = 'GET', body?: unknown, signal?: AbortSignal): Promise<T> {
  const execute = () => performRequest<T>(path,method,body,signal);
  if(method === 'GET') return execute();
  if(navigator.locks) return navigator.locks.request('prompt-hub-session-write',execute);
  // Older browsers still serialize this page; server leases remain authoritative across pages.
  const task=writeQueue.then(execute,execute);writeQueue=task.then(()=>undefined,()=>undefined);return task;
}
export function intent() { return {operation_id: crypto.randomUUID(), operation_epoch: epoch}; }
export function rememberOperation(operation: {operation_id: string}) { lastOperation = operation.operation_id; }
export async function mutate<T>(path: string, method: string, body: object): Promise<T> {
  const key = JSON.stringify([path, method, body]);
  let operation = pending.get(key);
  if (!operation) { operation = intent(); pending.set(key, operation); }
  lastOperation = operation.operation_id;
  try { const result = await request<T>(path, method, {...body, ...operation}); pending.delete(key); return result; }
  catch (error) {
    if (error instanceof APIError && error.status !== 0 && error.status !== 401 && error.status < 500 && !['stale_epoch', 'receipt_expired', 'invalid_response'].includes(error.code)) pending.delete(key);
    throw error;
  }
}
export function clearPending() { pending.clear(); lastOperation = ''; }
export async function operationStatus(operationId = lastOperation) {
  if (!operationId) throw new APIError(404, {message: '当前没有待确认操作。'});
  return request<{result: unknown}>(`operations/${operationId}/`);
}
export async function readText(file: File) {
  if (file.size > 20 * 1024 * 1024) throw new APIError(413, {message: '文件超过20MiB'});
  try { return new TextDecoder('utf-8', {fatal: true}).decode(await file.arrayBuffer()); }
  catch { throw new APIError(422, {message: '文件不是有效UTF-8，或读取失败。'}); }
}
export async function exportText(params: URLSearchParams) {
  let response;
  try { response = await fetch('/api/exchange/export/?' + params, {credentials: 'same-origin', headers: contextId ? {'X-Session-Context':contextId} : {}}); }
  catch { throw new APIError(0, {message: '导出连接中断，请重新生成。'}); }
  if (!response.ok) throw new APIError(response.status, await response.json());
  return response.text();
}
export function saveText(text: string, name = 'prompt-hub-export.txt') {
  const url = URL.createObjectURL(new Blob([text], {type: 'text/plain;charset=utf-8'}));
  const a = document.createElement('a'); a.href = url; a.download = name; document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30000);
}

export function canChooseSaveTarget() { return window.isSecureContext && 'showSaveFilePicker' in window; }
export async function chooseSaveTarget(name: string) {
  const picker = (window as unknown as {showSaveFilePicker?: (options: object) => Promise<FileSystemFileHandle>}).showSaveFilePicker;
  if (!window.isSecureContext || !picker) throw new DOMException('当前环境不支持选择保存位置，请使用普通下载', 'SecurityError');
  return picker.call(window, {suggestedName: name, types: [{description: 'TXT文件', accept: {'text/plain': ['.txt']}}]});
}
export async function writeTarget(handle: FileSystemFileHandle, text: string, artifactId = '') {
  localSaveEvent(artifactId,'open','started');
  const stream = await handle.createWritable();
  try { localSaveEvent(artifactId,'write','started'); await stream.write(new Blob([text], {type:'text/plain;charset=utf-8'})); localSaveEvent(artifactId,'close','started'); await stream.close(); localSaveEvent(artifactId,'close','completed'); }
  catch (error) { try { await stream.abort(); } catch { /* Original write failure remains authoritative. */ } throw error; }
}

export function localSaveEvent(artifactId: string, stage: string, result: string, error?: unknown) {
  console.info(JSON.stringify({event:'export.local',artifact_id:artifactId,stage,result,...(error ? {error_type:error instanceof DOMException ? error.name : 'Error'} : {})}));
}
