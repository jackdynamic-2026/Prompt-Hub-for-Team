export type Kind = 'PROMPT' | 'SKILL';
export interface Member { id: number; username: string; display_name: string; is_admin: boolean; must_change_password: boolean; password_change_suggested: boolean; idle_timeout_minutes: number }
export interface Entry {
  source_version: number;
  id: number; kind: Kind; title: string; content: string; intro: string;
  tag_version: number; recommendation_count: number; is_recommended: boolean; source_recommendation_snapshot?: {count: number; captured_at: string} | null; tags: {id: number; name: string}[]; owner: Member; body_version: number;
  shared_note: string; note_version: number; note_updated_by: string;
  note_updated_at: string; created_at: string; updated_at: string;
  skill_source?: SkillSource | null; github_snapshot?: {stars: number | null; fetched_at: string | null; state: string} | null;
  repository_verified?: boolean; skill_path_verified?: boolean; is_favorite?: boolean;
}
export interface SkillSource { provider: 'github'; owner: string; repo: string; skill_path: string; source_url: string }
export interface EntryInput { kind: Kind; title: string; content: string; intro: string; tags: string[]; skill_source?: SkillSource | null }
export interface PortableEntry {kind: Kind; title: string; content: string; intro: string; shared_note: string; tags: string[]; origin: {source_author?: string}; skill_source: SkillSource | null; github_snapshot?: {stars: number | null; fetched_at: string | null}; recommendation_snapshot?: {count: number; captured_at: string} | null}
export interface Preview { preview_token: string; entry_count: number; entries: PortableEntry[]; tag_mapping: {source: string; target: string; existing_tag_id: number | null}[]; warning: string }
export interface Revision { id: number; domain: 'body' | 'note'; version: number; snapshot: string | EntryInput; created_at: string }
export interface ManagedMember extends Member {is_active: boolean}
export interface DeletedEntry {id: number; kind: Kind; title: string; owner_id: number; deleted_at: string}
export interface Filters { name: string; tag_ids: string; owner_id: string; updated_from: string; updated_to: string; favorite: string }
export class APIError extends Error {
  line?: number;
  entryIndex?: number;
  operationId = '';
  retryAfterSeconds = 0;
  retryAt = '';
  cachedDataAvailable?: boolean;
  status: number; code: string; requestId: string; current?: Entry;
  constructor(status: number, body: {message?: string; error?: string; request_id?: string; current?: Entry; retry_after_seconds?: number; retry_at?: string; cached_data_available?: boolean; line?: number; entry_index?: number}) {
    super(body.message || '请求失败'); this.status = status; this.code = body.error || 'request_failed'; this.requestId = body.request_id || ''; this.current = body.current;
    this.retryAfterSeconds = typeof body.retry_after_seconds === 'number' && Number.isFinite(body.retry_after_seconds) ? Math.max(0, body.retry_after_seconds) : 0;
    this.retryAt = body.retry_at || '';
    this.cachedDataAvailable = body.cached_data_available;
    this.line = typeof body.line === 'number' && Number.isSafeInteger(body.line) && body.line > 0 ? body.line : undefined;
    this.entryIndex = typeof body.entry_index === 'number' && Number.isSafeInteger(body.entry_index) && body.entry_index > 0 ? body.entry_index : undefined;
  }
}
