import { describe, it, expect } from 'vitest';
import { appendRepositoryIntro } from './skillIntro';

describe('repository introduction append contract', () => {
  it('keeps original text exactly and appends normalized candidate', () => {
    expect(appendRepositoryIntro('  人工\r\n  缩进', ' \r\nGitHub\r\n  多行\r\n\r\n第二段 \r\n'))
      .toEqual({status:'appended', text:'  人工\r\n  缩进\n\nGitHub\n  多行\n\n第二段'});
  });
  it('does not stack separator blank lines', () => {
    expect(appendRepositoryIntro('原文\n\n', '候选')).toEqual({status:'appended',text:'原文\n\n候选'});
    expect(appendRepositoryIntro('原文\n', '候选')).toEqual({status:'appended',text:'原文\n\n候选'});
  });
  it('treats empty originals and candidates explicitly', () => {
    expect(appendRepositoryIntro(' \n ', ' 候选 ')).toEqual({status:'appended',text:'候选'});
    for(const candidate of ['', ' \n', null])expect(appendRepositoryIntro('原文',candidate)).toEqual({status:'empty',text:'原文'});
  });
  it('deduplicates full consecutive paragraphs anywhere including CRLF', () => {
    for(const original of ['候选','候选\n\n心得','原文\n\n候选','原文\r\n\r\n候选\r\n\r\n心得'])
      expect(appendRepositoryIntro(original,'候选')).toEqual({status:'duplicate',text:original});
    expect(appendRepositoryIntro('开头\n\n第一段\n\n第二段\n\n心得','第一段\n\n第二段').status).toBe('duplicate');
  });
  it('does not confuse words, partial paragraphs, spacing or case', () => {
    for(const [a,b] of [['skillful','skill'],['原文\n候选','候选'],['Hello','hello'],['a  b','a b'],['第一段\n\n心得','第一段\n\n第二段']])
      expect(appendRepositoryIntro(a,b).status).toBe('appended');
  });
  it('accepts 4999/5000 Unicode code points but never truncates overlong input', () => {
    for(const length of [4999,5000]){
      const candidate='😀'.repeat(length-3);
      expect(appendRepositoryIntro('甲',candidate)).toEqual({status:'appended',text:'甲\n\n'+candidate});
    }
    const original='😀'.repeat(4998);
    expect(appendRepositoryIntro(original,'乙')).toEqual({status:'too_long',text:original});
  });
});
