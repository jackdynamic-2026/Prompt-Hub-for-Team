import { useState } from 'react';
import type { FormEvent } from 'react';
import type { useTeamViewModel } from './useTeamViewModel';
type VM = ReturnType<typeof useTeamViewModel>;

export function MembersPanel({vm, onClose}: {vm: VM; onClose: () => void}) {
  const [name, setName] = useState(''); const [display, setDisplay] = useState(''); const [password, setPassword] = useState('');
  async function create(e: FormEvent) { e.preventDefault(); if (await vm.createMember(name, display, password)) { setName(''); setDisplay(''); setPassword(''); } }
  return <section className="team-panel"><div className="team-actions"><h1>成员管理</h1><button onClick={onClose}>返回列表</button></div><form className="team-panel" onSubmit={e => void create(e)}><h2>创建成员</h2><label>新成员用户名<input required value={name} onChange={e => setName(e.target.value)} /></label><label>显示名<input required value={display} onChange={e => setDisplay(e.target.value)} /></label><label>初始口令 · 至少8位<input type="password" autoComplete="new-password" minLength={8} required value={password} onChange={e => setPassword(e.target.value)} /></label><p>通过可信渠道交付口令。新成员首次登录可选择修改密码，也可稍后在个人设置中修改。</p><button disabled={vm.busy} className="primary">创建成员</button></form>{vm.members.map(member => <article className="team-card" key={member.id}><h3>{member.display_name} · {member.username}</h3><p>{member.is_admin ? '管理员' : '成员'} · {member.is_active ? '有效' : '已停用'}{member.password_change_suggested ? ' · 建议修改初始密码' : ''}</p><div className="team-actions"><button disabled={vm.busy || member.id === vm.user?.id} onClick={() => { if (window.confirm(`确认${member.is_active ? '停用' : '启用'} ${member.display_name}？`)) void vm.updateMember(member, {is_active: !member.is_active}); }}>{member.is_active ? '停用' : '启用'}</button><button disabled={vm.busy} onClick={() => { if (window.confirm('变更权限会撤销该成员旧会话，确认继续？')) void vm.updateMember(member, {is_admin: !member.is_admin}); }}>{member.is_admin ? '改为普通成员' : '设为管理员'}</button></div></article>)}</section>;
}
export function RecyclePanel({vm, onClose}: {vm: VM; onClose: () => void}) {
  return <section className="team-panel"><div className="team-actions"><h1>回收站</h1><button onClick={onClose}>返回列表</button></div><p>管理员可在删除后30天内恢复；恢复不会重新添加收藏。</p>{vm.recycle.map(entry => <article className="team-card" key={entry.id}><h3>{entry.title}</h3><p>{entry.kind} · 删除时间 {new Date(entry.deleted_at).toLocaleString('zh-CN')}</p><button disabled={vm.busy} onClick={() => { if (window.confirm('确认恢复此条目？')) void vm.undelete(entry.id); }}>恢复条目</button></article>)}{!vm.recycle.length && <p>暂无删除条目。</p>}</section>;
}
