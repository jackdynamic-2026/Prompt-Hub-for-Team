import { useEffect, useRef, useState } from 'react';
import type { Entry, Revision } from './model';
import { applyVariables, extractVariables } from '../utils/parser';
import type { useTeamViewModel } from './useTeamViewModel';
type VM = ReturnType<typeof useTeamViewModel>;
const date = (s: string) => new Date(s).toLocaleString('zh-CN', {timeZone: 'Asia/Shanghai'});

export default function Detail({vm, onEdit, onBack, onDirty}: {vm: VM; onEdit: (entry: Entry, intro?: string) => void; onBack: () => void; onDirty: (dirty: boolean) => void}) {
  const entry = vm.selected!;
  const canEdit = vm.user?.is_admin || entry.owner.id === vm.user?.id;
  const [githubClock,setGithubClock]=useState(()=>Date.now());
  const until=vm.githubWaitUntil[entry.id] || 0;
  useEffect(()=>{if(!until)return;const timer=setInterval(()=>{const now=Date.now();setGithubClock(now);if(now>=until)clearInterval(timer);},1000);return()=>clearInterval(timer);},[until]);
  const remaining=Math.max(0,Math.ceil((until-Math.max(githubClock,vm.githubWaitStartedAt))/1000));
  const [newTag, setNewTag] = useState('');
  const [note, setNote] = useState(() => vm.getNoteDraft(entry.id)?.text ?? ''); const [base, setBase] = useState<Entry | null>(()=>vm.getNoteDraft(entry.id)?.base ?? null);
  const [variables, setVariables] = useState<Record<string, string>>({});
  const [revision, setRevision] = useState<Revision | null>(null);
  const [latest, setLatest] = useState<Entry | null>(null);
  const [draft, setDraft] = useState(''); const [reading, setReading] = useState(false);
  const [reviewing, setReviewing] = useState(false); const [confirmed, setConfirmed] = useState(false);
  const noteSession = useRef(0);
  useEffect(() => { if(base) onDirty(true); },[base,onDirty]);
  const {keepNoteDraft} = vm;
  useEffect(() => { if(base) keepNoteDraft(entry.id,{text:note,base}); },[note,base,entry.id,keepNoteDraft]);
  useEffect(() => () => { ++noteSession.current; }, []);
  const blocked = vm.noteConflict === entry.id;
  const closeNote = () => { vm.keepNoteDraft(entry.id,null); ++noteSession.current; setBase(null); setLatest(null); setReviewing(false); setConfirmed(false); setReading(false); vm.clearNoteConflict(); onDirty(false); };
  async function readLatest() {
    const session = ++noteSession.current; setReading(true); setLatest(null);
    const value = await vm.readLatestNote(entry.id);
    if (session === noteSession.current) { setReading(false); setLatest(value); }
  }
  const snapshot = revision ? typeof revision.snapshot === 'string' ? revision.snapshot : `${revision.snapshot.title}\n\n${revision.snapshot.content || revision.snapshot.intro}\n\n标签：${revision.snapshot.tags.join('、')}` : '';
  return <section className="team-panel team-detail" aria-label="条目详情">
    <button className="team-back" onClick={onBack}>← 返回列表</button>
    <h2>{entry.title}</h2><small>分享人 {entry.owner.display_name} · 更新 {date(entry.updated_at)}</small>
    <div className="team-tags">{entry.tags.map(t => <span key={t.id}>{t.name}{canEdit && <button disabled={vm.busy} aria-label={'删除标签 '+t.name} onClick={() => { if(window.confirm('确认删除本条目的标签“'+t.name+'”？')) void vm.changeTags(entry,{remove_ids:[t.id],tag_version:entry.tag_version}); }}>×</button>}</span>)}</div>
    <div className="team-actions"><label>新增标签<input maxLength={30} value={newTag} onChange={e=>setNewTag(e.target.value)} /></label><button disabled={vm.busy || !newTag.trim()} onClick={() => { void vm.changeTags(entry,{add:[newTag]}).then(ok=>{if(ok)setNewTag('');}); }}>添加标签</button><button disabled={vm.busy} onClick={() => void vm.refreshSelected()}>刷新标签</button></div>
    {entry.kind === 'PROMPT' && extractVariables(entry.content).map(key => <label key={key}>{key}<input value={variables[key] || ''} onChange={e => setVariables({...variables, [key]: e.target.value})} /></label>)}
    <pre>{entry.kind === 'PROMPT' ? applyVariables(entry.content, variables) : entry.intro}</pre>
    {entry.kind === 'SKILL' && <section><p>仓库 Star：{entry.github_snapshot?.stars ?? '未知'} · {entry.repository_verified ? '仓库已核验' : '未重新核验'}</p><small>核验时间：{entry.github_snapshot?.fetched_at ? date(entry.github_snapshot.fetched_at) : '暂无'}；Skill路径未核验</small>{entry.skill_source && <p className="team-link"><a href={entry.skill_source.source_url} target="_blank" rel="noopener noreferrer">{entry.skill_source.source_url}</a>{entry.skill_source.skill_path && <span> · {entry.skill_source.skill_path}</span>}</p>}<button disabled={vm.busy || vm.githubRefreshingId!==null || remaining>0 || !entry.skill_source} onClick={() => void vm.github()}>{vm.githubRefreshingId===entry.id ? '正在刷新仓库资料…' : remaining>0 ? `${remaining}秒后可刷新` : '刷新仓库资料'}</button>{vm.githubNotice && <p className="team-alert">{vm.githubNotice}</p>}{vm.candidateIntro && canEdit && <div><p>GitHub仓库介绍候选（不代表该Skill专属介绍）：</p><p>只修改编辑草稿，保存后生效。</p><pre>{vm.candidateIntro}</pre><button onClick={() => onEdit(entry, vm.candidateIntro)}>追加到原介绍后，核对保存</button></div>}</section>}
    <div className="team-actions"><button disabled={vm.busy} aria-pressed={entry.is_recommended} onClick={() => void vm.recommend(entry)}>{entry.is_recommended ? "★ 取消推荐" : "☆ 团队推荐"} {entry.recommendation_count}</button><button className="primary" onClick={() => void vm.copy(variables)}>复制{entry.kind === 'PROMPT' ? '正文' : '资料'}</button><button disabled={vm.busy} onClick={() => void vm.favorite(entry)}>{entry.is_favorite ? '取消收藏' : '收藏'}</button>{canEdit && <button onClick={() => onEdit(entry)}>编辑内容</button>}<button disabled={vm.busy} onClick={() => void vm.loadHistory()}>查看历史</button>{canEdit && <button disabled={vm.busy || base !== null} onClick={() => { if (window.confirm('确认将条目移入回收站？')) void vm.deleteEntry(); }}>删除条目</button>}</div>
    {entry.source_recommendation_snapshot && <p>来源团队推荐：{entry.source_recommendation_snapshot.count}（导出快照，未核验；不计入本站推荐）</p>}
    <section className="team-note"><div className="team-actions"><h3>共同备注</h3><span>所有成员可编辑</span>{!base && <button onClick={() => { vm.clearNoteConflict(); setNote(entry.shared_note); setBase(entry); onDirty(true); }}>编辑备注</button>}</div>
      {base ? <>
        <label>备注内容<textarea aria-label="备注内容" maxLength={10000} readOnly={blocked || reading} disabled={vm.busy} value={note} onChange={e => { setNote(e.target.value); setConfirmed(false); }} /></label>
        {blocked && <div role="alert"><p>其他成员已更新共同备注，本次修改未保存。请先读取最新备注，再核对修改。你的草稿仍保留在此页。</p><button disabled={reading || vm.busy} onClick={() => void readLatest()}>读取最新备注</button>{reading && <p role="status">正在读取最新备注，请稍候…</p>}</div>}
        {(blocked || reviewing) && <section className="team-note-review"><label>我的未提交草稿<textarea readOnly value={draft} /></label><button onClick={async () => { try { await navigator.clipboard.writeText(draft); } catch { vm.setCopyText(draft); } }}>复制我的草稿</button><small>草稿仅保留在当前页面。刷新或关闭前请先复制。</small></section>}
        {blocked && latest && <section><h4>最新备注</h4><pre>{latest.shared_note || '空备注'}</pre><small>{latest.note_updated_by} · {date(latest.note_updated_at)} · 版本 {latest.note_version}</small><button onClick={() => { setBase(latest); setNote(latest.shared_note); setReviewing(true); setConfirmed(false); vm.clearNoteConflict(); }}>基于最新备注继续编辑</button></section>}
        {reviewing && !blocked && <label className="team-check"><input type="checkbox" checked={confirmed} onChange={e => setConfirmed(e.target.checked)} />已核对最新备注及本次修改</label>}
        <div className="team-actions"><button disabled={vm.busy || reading || blocked || (reviewing && !confirmed)} className="primary" onClick={async () => { if (!note && !window.confirm('确认清空共同备注吗？')) return; if (await vm.saveNote(note, base)) closeNote(); else { setDraft(note); setLatest(null); setReviewing(false); setConfirmed(false); } }}>保存备注</button><button disabled={vm.busy} onClick={() => { if (window.confirm('确认取消编辑并丢弃当前备注草稿？')) closeNote(); }}>取消</button></div>
      </> : <pre>{entry.shared_note || '暂无备注'}</pre>}
      <small>最近修改：{entry.note_updated_by} · {date(entry.note_updated_at)} · 版本 {entry.note_version}</small>
    </section>
    {vm.history && <section aria-label="历史快照"><h3>最近保留的历史快照</h3>{[...vm.history.bodies, ...vm.history.notes].map(r => <div className="team-actions" key={r.id}><span>{r.domain === 'body' ? '内容' : '备注'} v{r.version} · {date(r.created_at)}</span><button onClick={() => setRevision(r)}>查看快照</button></div>)}{!vm.history.bodies.length && !vm.history.notes.length && <p>暂无历史快照。</p>}{revision && <section><h3>恢复预览</h3><pre>{snapshot}</pre>{(vm.user?.is_admin || (revision.domain === 'body' && canEdit)) && <button disabled={vm.busy || base !== null} onClick={async () => { if (window.confirm('确认将这个快照恢复为一个新版本？')) { await vm.restoreRevision(revision); setRevision(null); } }}>恢复为新版本</button>}<button onClick={() => setRevision(null)}>关闭快照</button></section>}</section>}
  </section>;
}
