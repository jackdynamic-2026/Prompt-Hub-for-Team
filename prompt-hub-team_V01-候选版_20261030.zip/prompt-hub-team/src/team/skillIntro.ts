type AppendResult = {status: 'appended' | 'empty' | 'duplicate' | 'too_long'; text: string};
const normalized = (value: string) => value.replace(/\r\n?/g, '\n');

export function appendRepositoryIntro(original: string, candidate: string | null): AppendResult {
  const incoming = normalized(candidate || '').trim();
  if (!incoming) return {status: 'empty', text: original};
  const comparable = normalized(original).trim();
  let at = comparable.indexOf(incoming);
  while (at !== -1) {
    const end = at + incoming.length;
    if ((at === 0 || /\n[ \t]*\n$/.test(comparable.slice(0, at))) &&
        (end === comparable.length || /^\n[ \t]*\n/.test(comparable.slice(end))))
      return {status: 'duplicate', text: original};
    at = comparable.indexOf(incoming, at + 1);
  }
  const tail = normalized(original).match(/(?:\n[ \t]*)+$/)?.[0] || '';
  const breaks = (tail.match(/\n/g) || []).length;
  const separator = '\n'.repeat(Math.max(0, 2 - breaks));
  const text = original.trim() ? original + separator + incoming : incoming;
  return Array.from(text).length > 5000 ? {status: 'too_long', text: original} : {status: 'appended', text};
}
