import { beforeEach, describe, expect, it } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import App from './App';
import { getPrompts } from './utils/storage';

function openImport() {
  render(<App />);
  fireEvent.click(screen.getByText('导入 TXT'));
  return screen.getByLabelText('导入原文');
}

describe('Import review and persistence without mocks', () => {
  beforeEach(() => localStorage.clear());

  it('previews complete content, requires review, then really persists it', () => {
    const input = openImport();
    const before = getPrompts();
    fireEvent.change(input, { target: { value: '1、测试标题：\n正文\n\n1.正文列表\n继续正文' } });
    expect(screen.getByText(/第 1 行/)).toBeInTheDocument();
    fireEvent.click(screen.getByText(/1. 测试标题/));
    expect(screen.getByText('正文\n\n1.正文列表\n继续正文', { normalizer: text => text })).toBeVisible();
    expect(getPrompts()).toEqual(before);
    const button = screen.getByRole('button', { name: '确认追加导入 (1条)' });
    expect(button).toBeDisabled();
    fireEvent.click(screen.getByLabelText('我已核对标题边界和完整正文'));
    fireEvent.click(button);
    expect(getPrompts().at(-1)).toMatchObject({ title: '测试标题', content: '正文\n\n1.正文列表\n继续正文' });
    expect(screen.getByRole('status')).toHaveTextContent('成功导入 1 条');
  });

  it('shows suspect source lines and clears confirmation on every text or mode edit', async () => {
    const input = openImport();
    const source = '1、测试标题：\n正文\n\n1、注意事项：\n说明';
    fireEvent.change(input, { target: { value: source } });
    expect(screen.getByRole('alert')).toHaveTextContent('第 4 行');
    fireEvent.click(screen.getByLabelText('我已核对标题边界和完整正文'));
    fireEvent.change(input, { target: { value: source.replace('1、注意事项：', '（1）注意事项：') } });
    expect(screen.queryByRole('alert')).not.toBeInTheDocument();
    expect(screen.getByRole('button', { name: '确认追加导入 (1条)' })).toBeDisabled();
    fireEvent.change(input, { target: { value: source } });
    expect(screen.getByLabelText('我已核对标题边界和完整正文')).not.toBeChecked();
    fireEvent.click(screen.getByLabelText('我已核对标题边界和完整正文'));
    await userEvent.selectOptions(screen.getByLabelText('导入格式'), 'compatibility');
    expect(screen.getByLabelText('我已核对标题边界和完整正文')).not.toBeChecked();
  });

  it('allows explicit confirmation of legitimate skipped headings and deduplicates real storage', () => {
    const input = openImport();
    fireEvent.change(input, { target: { value: '1、钢人论证：\n新增正文\n\n3、钢人论证：\n另一段正文' } });
    expect(screen.getByRole('alert')).toHaveTextContent('第 4 行');
    fireEvent.click(screen.getByLabelText('我已核对标题边界和完整正文'));
    fireEvent.click(screen.getByRole('button', { name: '确认追加导入 (2条)' }));
    expect(getPrompts().slice(-2).map(p => p.title)).toEqual(['钢人论证 (2)', '钢人论证 (3)']);
  });

  it('does not write on cancellation and requires fresh confirmation on reopening', () => {
    const input = openImport();
    const before = getPrompts();
    fireEvent.change(input, { target: { value: '1、测试：\n正文' } });
    fireEvent.click(screen.getByLabelText('我已核对标题边界和完整正文'));
    fireEvent.click(screen.getByRole('button', { name: '取消' }));
    expect(getPrompts()).toEqual(before);
    fireEvent.click(screen.getByText('导入 TXT'));
    expect(screen.getByLabelText('我已核对标题边界和完整正文')).not.toBeChecked();
  });

  it('does not silently fall back; supports old titles only after mode selection', async () => {
    const input = openImport();
    fireEvent.change(input, { target: { value: '1. 旧标题\n正文' } });
    expect(screen.getByText(/未找到标准标题/)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: '确认追加导入 (0条)' })).toBeDisabled();
    await userEvent.selectOptions(screen.getByLabelText('导入格式'), 'compatibility');
    expect(screen.getByText('兼容模式可能把正文编号识别成标题，请逐条核对预览。')).toBeInTheDocument();
    fireEvent.click(screen.getByLabelText('我已核对标题边界和完整正文'));
    fireEvent.click(screen.getByRole('button', { name: '确认追加导入 (1条)' }));
    expect(getPrompts().at(-1)).toMatchObject({ title: '旧标题', content: '正文' });
  });

  it('reads a real TXT File with FileReader and shares the paste parser', async () => {
    openImport();
    const source = '\uFEFF1、文件标题：\r\n正文\r\n\r\n1.保留列表';
    await userEvent.upload(screen.getByLabelText('选择 TXT 文件导入'), new File([source], 'prompts.txt', { type: 'text/plain' }));
    await waitFor(() => expect(screen.getByLabelText('导入原文')).toHaveValue(source.replace(/^\uFEFF/, '').replace(/\r\n/g, '\n')));
    expect(screen.getByRole('button', { name: '确认追加导入 (1条)' })).toBeDisabled();
    fireEvent.click(screen.getByLabelText('我已核对标题边界和完整正文'));
    fireEvent.click(screen.getByRole('button', { name: '确认追加导入 (1条)' }));
    expect(getPrompts().at(-1)).toMatchObject({ title: '文件标题', content: '正文\n\n1.保留列表' });
  });

  it('blocks stale confirmation while reading and cancels pending reads when closed', async () => {
    const input = openImport();
    const before = getPrompts();
    fireEvent.change(input, { target: { value: '1、旧内容：\n正文' } });
    fireEvent.click(screen.getByLabelText('我已核对标题边界和完整正文'));
    fireEvent.change(screen.getByLabelText('选择 TXT 文件导入'), { target: { files: [new File(['1、新文件：\n新正文'], 'new.txt', { type: 'text/plain' })] } });
    expect(screen.getByText('正在读取文件，请稍候。')).toBeInTheDocument();
    fireEvent.click(screen.getByLabelText('我已核对标题边界和完整正文'));
    expect(screen.getByRole('button', { name: '确认追加导入 (1条)' })).toBeDisabled();
    fireEvent.click(screen.getByRole('button', { name: '取消' }));
    fireEvent.click(screen.getByText('导入 TXT'));
    expect(screen.getByLabelText('导入原文')).toHaveValue('1、旧内容：\n正文');
    expect(getPrompts()).toEqual(before);
  });
});
