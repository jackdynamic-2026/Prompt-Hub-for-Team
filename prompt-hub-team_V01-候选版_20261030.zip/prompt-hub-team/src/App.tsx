import { useState, useMemo, useEffect, useRef } from 'react';
import { Search, Copy, ChevronLeft, Plus, Star, Menu, Clock, Download, Trash2, X, Upload, Pencil, Sun, Moon, FileUp } from 'lucide-react';
import { getPrompts, toggleFavorite, getHistory, logHistory, deletePrompt, appendPrompts, savePrompt } from './utils/storage';
import { extractVariables, applyVariables, analyzeTxtImport, formatPromptsToTxt } from './utils/parser';
import type { ImportMode } from './utils/parser';
import { copyToClipboard } from './utils/clipboard';
import type { Prompt } from './data/defaultPrompts';
import './index.css';

function App() {
  const [prompts, setPrompts] = useState<Prompt[]>(getPrompts);
  const [historyIds, setHistoryIds] = useState<string[]>(getHistory);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPrompt, setSelectedPrompt] = useState<Prompt | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  
  // Variables state for the active prompt detail
  const [variables, setVariables] = useState<Record<string, string>>({});

  // Import Modal State
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [importText, setImportText] = useState('');
  const [importMode, setImportMode] = useState<ImportMode>('standard');
  const [importReviewed, setImportReviewed] = useState(false);
  const [importMessage, setImportMessage] = useState('');
  const [fileError, setFileError] = useState('');
  const [fileLoading, setFileLoading] = useState(false);
  const importReader = useRef<FileReader | null>(null);

  useEffect(() => () => { importReader.current?.abort(); }, []);
  
  // Create Modal State
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [newPromptTitle, setNewPromptTitle] = useState('');
  const [newPromptContent, setNewPromptContent] = useState('');

  // Manual Copy Fallback Modal State
  const [isManualCopyOpen, setIsManualCopyOpen] = useState(false);
  const [manualCopyText, setManualCopyText] = useState('');

  // Edit Mode State
  const [isEditing, setIsEditing] = useState(false);
  const [editTitle, setEditTitle] = useState('');
  const [editContent, setEditContent] = useState('');

  // Theme State
  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    if (typeof window !== 'undefined') {
      return (localStorage.getItem('prompt-hub-theme') as 'dark' | 'light') || 'dark';
    }
    return 'dark';
  });

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('prompt-hub-theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(prev => prev === 'dark' ? 'light' : 'dark');
  };

  const refreshPrompts = () => {
    setPrompts(getPrompts());
  };

  const filteredPrompts = useMemo(() => {
    return prompts
      .filter(p => 
        p.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
        p.content.toLowerCase().includes(searchQuery.toLowerCase())
      )
      .sort((a, b) => {
        if (a.isFavorite && !b.isFavorite) return -1;
        if (!a.isFavorite && b.isFavorite) return 1;
        return 0;
      });
  }, [prompts, searchQuery]);

  const historyPrompts = useMemo(() => {
    return historyIds
      .map(id => prompts.find(p => p.id === id))
      .filter((p): p is Prompt => p !== undefined);
  }, [historyIds, prompts]);

  const handleSelectPrompt = (prompt: Prompt) => {
    setSelectedPrompt(prompt);
    setIsEditing(false);
    const extracted = extractVariables(prompt.content);
    const initialVars: Record<string, string> = {};
    extracted.forEach(v => { initialVars[v] = ''; });
    setVariables(initialVars);
    setIsSidebarOpen(false);
  };

  const handleToggleFavorite = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    toggleFavorite(id);
    refreshPrompts();
    if (selectedPrompt?.id === id) {
      setSelectedPrompt(p => p ? { ...p, isFavorite: !p.isFavorite } : null);
    }
  };

  const handleDelete = (id: string) => {
    if (window.confirm('确定要删除此提示词吗？此操作不可恢复。')) {
      deletePrompt(id);
      refreshPrompts();
      if (selectedPrompt?.id === id) {
        setSelectedPrompt(null);
      }
    }
  };

  const handleCopy = async () => {
    if (!selectedPrompt) return;
    const finalContent = applyVariables(selectedPrompt.content, variables);
    
    const result = await copyToClipboard(finalContent);
    
    if (result.success && !result.isFallback) {
      if (navigator.vibrate) navigator.vibrate(50);
      logHistory(selectedPrompt.id);
      setHistoryIds(getHistory());
      alert('已复制到剪贴板！');
    } else {
      // 只要触发了降级策略（或是全线失败），均展示明确的兜底弹窗
      logHistory(selectedPrompt.id);
      setHistoryIds(getHistory());
      setManualCopyText(finalContent);
      setIsManualCopyOpen(true);
    }
  };

  const handleShare = async () => {
    if (!selectedPrompt) return;
    const finalContent = applyVariables(selectedPrompt.content, variables);
    if (navigator.share) {
      try {
        await navigator.share({
          title: selectedPrompt.title,
          text: finalContent,
        });
      } catch (err) {
        console.error('Share failed:', err);
      }
    } else {
      alert('您的浏览器不支持原生分享功能，请直接复制内容。');
    }
  };

  const importReport = useMemo(() => analyzeTxtImport(importText, importMode), [importText, importMode]);
  const parsedImportPrompts = importReport.entries;

  const updateImportText = (text: string) => {
    importReader.current?.abort();
    importReader.current = null;
    setFileLoading(false);
    setImportText(text);
    setImportReviewed(false);
    setFileError('');
  };

  const closeImport = () => {
    importReader.current?.abort();
    importReader.current = null;
    setFileLoading(false);
    setIsImportModalOpen(false);
    setImportReviewed(false);
  };

  const handleConfirmImport = () => {
    if (parsedImportPrompts.length === 0 || !importReviewed || fileError || fileLoading) return;
    const existingTitles = new Set(prompts.map(p => p.title));
    const deduped = parsedImportPrompts.map(p => {
      let title = p.title!;
      if (existingTitles.has(title)) {
        let suffix = 2;
        while (existingTitles.has(`${p.title} (${suffix})`)) {
          suffix++;
        }
        title = `${p.title} (${suffix})`;
      }
      existingTitles.add(title);
      return { id: p.id, title, content: p.content, tags: p.tags, isFavorite: p.isFavorite };
    });
    appendPrompts(deduped);
    refreshPrompts();
    closeImport();
    updateImportText('');
    const renamedCount = deduped.filter((d, i) => d.title !== parsedImportPrompts[i].title).length;
    const msg = renamedCount > 0
      ? `成功导入 ${deduped.length} 条！其中 ${renamedCount} 条因标题重复已自动重命名。`
      : `成功导入 ${deduped.length} 条提示词！`;
    setImportMessage(msg);
  };

  const handleFileImport = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      e.target.value = '';
      if (!file) return;
      importReader.current?.abort();
      setFileError('');
      setFileLoading(true);
      setImportReviewed(false);
      const reader = new FileReader();
      importReader.current = reader;
      reader.onload = (ev) => {
        if (importReader.current !== reader) return;
        importReader.current = null;
        const text = ev.target?.result as string;
        updateImportText(text || '');
      };
      reader.onerror = () => {
        if (importReader.current !== reader) return;
        importReader.current = null;
        setFileLoading(false);
        setFileError('文件读取失败，请重试或粘贴原文。');
      };
      reader.readAsText(file, 'utf-8');
  };

  const handleSaveNewPrompt = () => {
    if (!newPromptTitle.trim() || !newPromptContent.trim()) return;
    savePrompt({
      id: '',
      title: newPromptTitle.trim(),
      content: newPromptContent.trim(),
      tags: ['自定义'],
      isFavorite: false
    });
    refreshPrompts();
    setIsCreateModalOpen(false);
    setNewPromptTitle('');
    setNewPromptContent('');
  };

  const handleExport = async () => {
    if (prompts.length === 0) return;
    const txtContent = formatPromptsToTxt(prompts);
    const blob = new Blob([txtContent], { type: 'text/plain;charset=utf-8' });
    const defaultName = `PromptHub_Export_${new Date().toISOString().split('T')[0]}.txt`;

    // 尝试使用 File System Access API 弹出保存对话框
    if ('showSaveFilePicker' in window) {
      try {
        const handle = await (window as any).showSaveFilePicker({
          suggestedName: defaultName,
          types: [{
            description: 'Text Files',
            accept: { 'text/plain': ['.txt'] },
          }],
        });
        const writable = await handle.createWritable();
        await writable.write(blob);
        await writable.close();
        alert('导出成功！');
        return;
      } catch (err: any) {
        if (err?.name === 'AbortError') return;
        console.warn('showSaveFilePicker failed, falling back:', err);
      }
    }

    // 降级：传统下载方式
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = defaultName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleEditClick = () => {
    if (!selectedPrompt) return;
    setIsEditing(true);
    setEditTitle(selectedPrompt.title);
    setEditContent(selectedPrompt.content);
  };

  const handleSaveEdit = () => {
    if (!selectedPrompt || !editTitle.trim() || !editContent.trim()) return;
    
    const updatedPrompt = {
      ...selectedPrompt,
      title: editTitle.trim(),
      content: editContent.trim()
    };
    
    savePrompt(updatedPrompt);
    refreshPrompts();
    setSelectedPrompt(updatedPrompt);
    setIsEditing(false);
    
    // 重新提取变量，并尽可能保留已有输入
    const newVars = extractVariables(updatedPrompt.content);
    const newVariablesState: Record<string, string> = {};
    newVars.forEach(v => {
      newVariablesState[v] = variables[v] || '';
    });
    setVariables(newVariablesState);
  };

  return (
    <>
      <div className="ambient-bg">
        <div className="blob-1"></div>
        <div className="blob-2"></div>
      </div>

      <div className="app-container">
        {/* Sidebar */}
        <aside className={`sidebar ${isSidebarOpen ? 'open' : ''}`}>
          <div className="brand-container">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div className="brand">Prompt Hub</div>
                <a href="/team/">进入提示词与技能分享库</a>
              <button className="theme-toggle" onClick={toggleTheme} aria-label="切换主题">
                {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
              </button>
            </div>
            <div className="brand-subtitle">
              致敬数字生命卡兹克，璀璨的火花启发了思维。<br />
              <span className="author">--by 非常无言</span>
            </div>
          </div>
          
          <div className="nav-section">
            <h3><Clock size={14} style={{display: 'inline', marginRight: 4}}/> 使用历史</h3>
            <ul className="history-list">
              {historyPrompts.length === 0 && <li className="history-empty">暂无使用记录</li>}
              {historyPrompts.map(p => (
                <li key={p.id} className="history-item" onClick={() => handleSelectPrompt(p)}>
                  <div className="history-dot" />
                  {p.title}
                </li>
              ))}
            </ul>
          </div>

          <div className="nav-section" style={{marginTop: 'auto'}}>
            <ul className="history-list">
              <li className="history-item" onClick={() => { setIsImportModalOpen(true); setImportReviewed(false); setImportMessage(''); setIsSidebarOpen(false); }}>
                <Download size={16} /> 导入 TXT
              </li>
              <li className="history-item" onClick={() => { handleExport(); setIsSidebarOpen(false); }}>
                <Upload size={16} /> 导出 TXT
              </li>
            </ul>
          </div>
        </aside>

        {/* Overlay for mobile sidebar */}
        {isSidebarOpen && (
          <div className="sidebar-overlay" onClick={() => setIsSidebarOpen(false)}></div>
        )}

        {/* Main Content */}
        <main className="main-content">
          {importMessage && <p role="status" className="import-status">{importMessage}</p>}
          {!selectedPrompt ? (
            <>
              <header className="mobile-header">
                <button className="icon-btn" onClick={() => setIsSidebarOpen(true)}>
                  <Menu size={24} />
                </button>
                <div className="brand" style={{fontSize: '1.2rem'}}>Prompt Hub</div>
                <button className="theme-toggle" onClick={toggleTheme} aria-label="切换主题" style={{width: 36, height: 36}}>
                  {theme === 'dark' ? <Sun size={16} /> : <Moon size={16} />}
                </button>
              </header>
              
              <div className="search-wrapper">
                <Search className="search-icon" size={20} />
                <input 
                  type="text" 
                  className="search-input" 
                  placeholder="搜索提示词名称或内容..." 
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>

              <div className="grid">
                {filteredPrompts.map(prompt => (
                  <div 
                    key={prompt.id} 
                    className="card"
                    onClick={() => handleSelectPrompt(prompt)}
                  >
                    <div className="card-header">
                      <div className="card-title">{prompt.title}</div>
                      <button 
                        className={`icon-btn star-btn ${prompt.isFavorite ? 'active' : ''}`}
                        onClick={(e) => handleToggleFavorite(e, prompt.id)}
                      >
                        <Star size={18} fill={prompt.isFavorite ? 'currentColor' : 'none'} />
                      </button>
                    </div>
                    <div className="card-content">{prompt.content}</div>
                    <div className="tags">
                      {prompt.tags.map(tag => (
                        <span key={tag} className="tag">{tag}</span>
                      ))}
                    </div>
                  </div>
                ))}
                {filteredPrompts.length === 0 && (
                  <div style={{ color: 'var(--text-muted)' }}>没有找到匹配的提示词</div>
                )}
              </div>
              
              <button className="fab" aria-label="新建提示词" onClick={() => setIsCreateModalOpen(true)}>
                <Plus size={24} />
              </button>
            </>
          ) : (
            <div className="detail-view card">
              <div style={{ padding: '24px', borderBottom: '1px solid var(--glass-border)' }}>
                <button className="back-button" onClick={() => setSelectedPrompt(null)}>
                  <ChevronLeft size={20} /> 返回
                </button>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginTop: '16px', gap: '16px' }}>
                  {isEditing ? (
                    <input 
                      type="text"
                      className="search-input"
                      style={{ flex: 1, fontSize: '1.2rem', padding: '8px 12px' }}
                      value={editTitle}
                      onChange={e => setEditTitle(e.target.value)}
                    />
                  ) : (
                    <h2 style={{ fontSize: '1.5rem', fontWeight: 600, flex: 1 }}>{selectedPrompt.title}</h2>
                  )}
                  <div style={{ display: 'flex', gap: '12px' }}>
                    {isEditing ? (
                      <>
                        <button className="btn-secondary" onClick={() => setIsEditing(false)}>取消</button>
                        <button 
                          className="btn-primary" 
                          disabled={!editTitle.trim() || !editContent.trim()}
                          onClick={handleSaveEdit}
                        >保存修改</button>
                      </>
                    ) : (
                      <>
                        <button className="icon-btn" onClick={handleShare}>
                          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="18" cy="5" r="3"></circle><circle cx="6" cy="12" r="3"></circle><circle cx="18" cy="19" r="3"></circle><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"></line><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"></line></svg>
                        </button>
                        <button 
                          className={`icon-btn star-btn ${selectedPrompt.isFavorite ? 'active' : ''}`}
                          onClick={(e) => handleToggleFavorite(e, selectedPrompt.id)}
                        >
                          <Star size={24} fill={selectedPrompt.isFavorite ? 'currentColor' : 'none'} />
                        </button>
                        <button className="icon-btn" aria-label="编辑提示词" onClick={handleEditClick}>
                          <Pencil size={24} />
                        </button>
                        <button className="icon-btn" style={{color: '#ef4444'}} onClick={() => handleDelete(selectedPrompt.id)}>
                          <Trash2 size={24} />
                          <span style={{marginLeft: 4, fontSize: '0.85rem'}}>删除此提示词</span>
                        </button>
                      </>
                    )}
                  </div>
                </div>
              </div>

              {isEditing ? (
                <div style={{ padding: '24px' }}>
                  <label style={{ display: 'block', marginBottom: '8px', color: 'var(--text-muted)' }}>正文内容（支持【变量】）</label>
                  <textarea 
                    className="modal-textarea"
                    style={{ minHeight: '300px' }}
                    placeholder="输入提示词正文..."
                    value={editContent}
                    onChange={e => setEditContent(e.target.value)}
                  />
                </div>
              ) : (
                <>
                  {Object.keys(variables).length > 0 && (
                    <div className="variables-form">
                      <h4>请填写以下变量：</h4>
                      {Object.keys(variables).map(key => (
                        <div className="form-group" key={key}>
                          <label>{key}</label>
                          <input 
                            type="text" 
                            value={variables[key]} 
                            onChange={(e) => setVariables({ ...variables, [key]: e.target.value })}
                            placeholder={`请输入 ${key}`}
                          />
                        </div>
                      ))}
                    </div>
                  )}

                  <div className="preview-section" style={{ borderTop: '1px solid var(--glass-border)' }}>
                    <h4 style={{ marginBottom: '12px', color: 'var(--text-muted)' }}>预览：</h4>
                    <div className="preview-content">
                      {applyVariables(selectedPrompt.content, variables)}
                    </div>
                    <button className="copy-button" onClick={handleCopy}>
                      <Copy size={20} /> 复制生成结果
                    </button>
                  </div>
                </>
              )}
            </div>
          )}
        </main>
      </div>

      {/* Import Modal */}
      {isImportModalOpen && (
        <div className="modal-overlay">
          <div className="modal-content">
            <div className="modal-header">
              <h2>批量导入提示词</h2>
              <button className="icon-btn" aria-label="关闭导入" onClick={closeImport}>
                <X size={24} />
              </button>
            </div>
            <div className="modal-body">
              <p style={{color: 'var(--text-muted)', fontSize: '0.9rem'}}>
                标准标题格式为“编号、标题：”，独占一行，标题前留空行（文件开头除外）。同名提示词将自动重命名。
              </p>
              <label className="btn-secondary import-file-label">
                <FileUp size={18} /> 选择 TXT 文件导入
                <input className="import-file-input" type="file" accept=".txt,text/plain" aria-label="选择 TXT 文件导入" onChange={handleFileImport} />
              </label>
              <div style={{textAlign: 'center', color: 'var(--text-muted)', fontSize: '0.8rem'}}>— 或直接粘贴内容 —</div>
              <label className="import-mode">导入格式
                <select aria-label="导入格式" value={importMode} onChange={e => { setImportMode(e.target.value as ImportMode); setImportReviewed(false); }}>
                  <option value="standard">标准格式（推荐）</option>
                  <option value="compatibility">旧格式（点号或无冒号）</option>
                </select>
              </label>
              {importMode === 'compatibility' && <p className="import-note">兼容模式可能把正文编号识别成标题，请逐条核对预览。</p>}
              <textarea 
                aria-label="导入原文"
                className="modal-textarea"
                placeholder={"请粘贴您的 txt。例如：\n1、小红书文案专家：\n你是一个小红书爆款文案专家...\n2. 翻译官\n请帮我把以下英文翻译成中文...\n"}
                value={importText}
                onChange={e => updateImportText(e.target.value)}
              />
              {fileError && <p role="alert">{fileError}</p>}
              {fileLoading && <p className="import-note">正在读取文件，请稍候。</p>}
              {importText.trim() && parsedImportPrompts.length === 0 && <p className="import-note">
                {importMode === 'standard' ? '未找到标准标题。示例：1、标题：，下一行填写正文。旧格式请主动选择兼容模式。' : '未找到标题。示例：1. 标题，下一行填写正文，标题前留空行。'}
              </p>}
              {importReport.issues.length > 0 && parsedImportPrompts.length > 0 && <div role="alert" className="import-warning">
                <strong>请修改原文，或确认以下行确实为标题及可忽略的文字：</strong>
                <ul>{importReport.issues.map((issue, i) => <li key={i}>
                  第 {issue.line} 行：{issue.raw}<br />{issue.message}
                </li>)}</ul>
                <p>若某行属于正文，请将编号改为“（2）注意事项：”这样的格式，再核对预览。</p>
              </div>}
              {parsedImportPrompts.length > 0 && (
                <div>
                  <h4 style={{marginBottom: 8, color: 'var(--primary)'}}>待导入列表 (预览)</h4>
                  <ul className="preview-list">
                    {parsedImportPrompts.map((p, i) => (
                      <li key={p.id}><details>
                        <summary>{i+1}. {p.title} <span className="import-line">（第 {p.sourceLine} 行）</span></summary>
                        <pre className="import-body-preview">{p.content || '（正文为空）'}</pre>
                      </details></li>
                    ))}
                  </ul>
                </div>
              )}
              {parsedImportPrompts.length > 0 && <>
                <p className="import-note">请核对标题边界和完整正文；正文中的同格式编号也可能被识别为标题。</p>
                <label className="import-review"><input type="checkbox" disabled={fileLoading || !!fileError} checked={importReviewed} onChange={e => setImportReviewed(e.target.checked)} />我已核对标题边界和完整正文</label>
              </>}
            </div>
            <div className="modal-footer">
              <button className="btn-secondary" onClick={closeImport}>取消</button>
              <button 
                className="btn-primary" 
                disabled={parsedImportPrompts.length === 0 || !importReviewed || !!fileError || fileLoading}
                onClick={handleConfirmImport}
              >
                确认追加导入 ({parsedImportPrompts.length}条)
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Create Modal */}
      {isCreateModalOpen && (
        <div className="modal-overlay">
          <div className="modal-content">
            <div className="modal-header">
              <h2>新建单个提示词</h2>
              <button className="icon-btn" onClick={() => setIsCreateModalOpen(false)}>
                <X size={24} />
              </button>
            </div>
            <div className="modal-body">
              <div className="form-group">
                <label>标题</label>
                <input 
                  type="text" 
                  placeholder="给您的提示词起个名字..." 
                  value={newPromptTitle}
                  onChange={e => setNewPromptTitle(e.target.value)}
                />
              </div>
              <div className="form-group">
                <label>内容</label>
                <textarea 
                  className="modal-textarea"
                  style={{minHeight: '200px'}}
                  placeholder="正文内容（支持【变量】语法）..." 
                  value={newPromptContent}
                  onChange={e => setNewPromptContent(e.target.value)}
                />
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn-secondary" onClick={() => setIsCreateModalOpen(false)}>取消</button>
              <button 
                className="btn-primary" 
                disabled={!newPromptTitle.trim() || !newPromptContent.trim()}
                style={{opacity: (!newPromptTitle.trim() || !newPromptContent.trim()) ? 0.5 : 1}}
                onClick={handleSaveNewPrompt}
              >
                保存提示词
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Manual Copy Fallback Modal */}
      {isManualCopyOpen && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ maxWidth: '90vw', width: '400px' }}>
            <div className="modal-header">
              <h2 style={{ color: 'var(--primary)' }}>手动复制兜底</h2>
              <button className="icon-btn" onClick={() => setIsManualCopyOpen(false)}>
                <X size={24} />
              </button>
            </div>
            <div className="modal-body">
              <div style={{
                background: 'rgba(239, 68, 68, 0.1)',
                color: '#ef4444',
                padding: '12px',
                borderRadius: '8px',
                fontSize: '0.9rem',
                marginBottom: '16px',
                lineHeight: 1.5
              }}>
                受当前环境或宿主 App 安全限制，自动复制已被阻断。请长按下方蓝框，点击【复制】即可。
              </div>
              <textarea
                className="modal-textarea"
                style={{
                  minHeight: '200px',
                  backgroundColor: 'rgba(59, 130, 246, 0.05)',
                  border: '1px solid var(--primary)',
                  color: 'var(--text-color)'
                }}
                readOnly
                value={manualCopyText}
                ref={(el) => {
                  if (el) {
                    el.focus();
                    el.select();
                  }
                }}
              />
            </div>
            <div className="modal-footer">
              <button className="btn-primary" onClick={() => setIsManualCopyOpen(false)}>
                我已复制完毕
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

export default App;
